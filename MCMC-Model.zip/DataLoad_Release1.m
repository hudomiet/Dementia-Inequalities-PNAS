function Data = DataLoad_Release1()
%%% Loading and formatting data for estimation

fprintf('*** Loading the data...');
% Loading the data
rawdata_ids         = csvread('data_ids.txt');
rawdata_health      = csvread('data_health.txt');
rawdata_demog       = csvread('data_demog.txt');
rawdata_ages        = csvread('data_ages.txt');
rawdata_adams       = csvread('data_adams.txt');
rawdata_cogaggscore = csvread('data_cogaggvars.txt');
rawdata_cogindscore = csvread('data_cogindvars.txt');
rawdata_demogflags  = csvread('data_demogflag.txt');
rawdata_healthflags = csvread('data_healthflag.txt');
rawdata_cogaggflags = csvread('data_cogaggflags.txt');
rawdata_cogindflags = csvread('data_cogindflags.txt');

% Parameters
NSize  = size(rawdata_ids,1);  % Total (long) sample size
NSizet = 13;                   % Time periods: Need to adjust manually
NSizex = NSize/NSizet;         % Number of people

% Renaming/storing data
XRaceBalanced    = rawdata_demog(:,3);  % Race (1-4)
XEducBalanced    = rawdata_demog(:,4);  % Education (1-4)
XForbornBalanced = rawdata_demog(:,5);  % Foreign born (0-1)
XHsscBalanced    = rawdata_demog(:,9);  % Household social security income (1-4)
XSingleBalanced  = rawdata_demog(:,7);  % Single (0-1)
XFemaleBalanced  = rawdata_demog(:,8);  % Gender (0-1)
XStrokeBalanced  = rawdata_health(:,3); % Ever had a stroke (0-1)

MisXRaceBalanced    = rawdata_demogflags(:,3)>0.5;  % Missing Race
MisXEducBalanced    = rawdata_demogflags(:,4)>0.5;  % Missing Education
MisXForbornBalanced = rawdata_demogflags(:,5)>0.5;  % Missing Foreign born
MisXHsscBalanced    = rawdata_demogflags(:,6)>0.5;  % Missing Household social security income
MisXSingleBalanced  = rawdata_demogflags(:,7)>0.5;  % Missing Single
MisXStrokeBalanced  = rawdata_healthflags(:,3)>0.5; % Missing Ever had stroke

AgeBalanced          = rawdata_ages(:,3);  % Age
AgeBalanced_Min      = rawdata_ages(:,4);  % Age, lowest possible value
AgeBalanced_Max      = rawdata_ages(:,5);  % Age, lowest possible value
DeathAgeBalanced     = rawdata_ages(:,6);  % Age at death
DeathAgeBalanced_min = rawdata_ages(:,7);  % Age at death, lowest possible value
DeathAgeBalanced_max = rawdata_ages(:,8);  % Age at death, highest possible value
WavesBalanced        = rawdata_ids(:,3);   % Survey wave
XBirthYearBalanced   = (rawdata_ids(:,14)-1930)/10;  % Birth year (decades after 1930)
IAdamsSelectedBalanced   = rawdata_ids(:,6)>0.5;     % Indicator for selection into ADAMS
IAdamsSurvivedBalanced   = rawdata_ids(:,7)>0.5;     % Indicator for surviving to ADAMS interview
IAdamsRespondentBalanced = rawdata_ids(:,8)>0.5;     % Indicator for responding to ADAMS interview
PriorWaveAdamsBalanced   = rawdata_ids(:,4);         % Identifying the survey wave prior to ADAMS 
IHRSCoreBalanced         = rawdata_ids(:,5)>0.5;     % Indicator of a core HRS interview
IProxyAllBalanced        = rawdata_ids(:,10)>0.5;    % Indicator of a proxy HRS interview
ISelfAllBalanced         = rawdata_ids(:,11)>0.5;    % Indicator of a self HRS interview
IAdamsEligibleBalanced   = rawdata_ids(:,9)>0.5;     % Indicator of ADAMS eligibility
FirstSelfBalanced        = rawdata_ids(:,12)>0.5;    % Indicator of a first self interview in the HRS
WeightsBalanced          = rawdata_ids(:,13);        % Survey weights

% Various cognitive measures in the HRS (availalbe in all, proxy, or self interviews) 
YCogAllBalanced    = rawdata_cogaggscore(:,3);
YCogSelf1Balanced  = rawdata_cogindscore(:,3);  
YCogSelf2Balanced  = rawdata_cogindscore(:,4);  
YCogSelf3Balanced  = rawdata_cogindscore(:,5);  
YCogSelf4Balanced  = rawdata_cogindscore(:,6);  
YCogProxy1Balanced = rawdata_cogindscore(:,7);  
YCogProxy2Balanced = rawdata_cogindscore(:,8);  

% Indicators of missing values in the cognitive measures
MisYAllBalanced    = rawdata_cogaggflags(:,3)>0.5;
MisYSelf1Balanced  = rawdata_cogindflags(:,3)>0.5;
MisYSelf2Balanced  = rawdata_cogindflags(:,4)>0.5;
MisYSelf3Balanced  = rawdata_cogindflags(:,5)>0.5;
MisYSelf4Balanced  = rawdata_cogindflags(:,6)>0.5;
MisYProxy1Balanced = rawdata_cogindflags(:,7)>0.5;
MisYProxy2Balanced = rawdata_cogindflags(:,8)>0.5;

% Indicators of cognitive status in the ADAMS
DementedBalanced         = rawdata_adams(:,3) == 1;
CindBalanced             = rawdata_adams(:,3) == 2;
NormalcBalanced          = rawdata_adams(:,3) == 3;

% Selection strata in ADAMS
XAdamsSelfBalanced       = [ones(NSize,1),rawdata_adams(1:NSize,5:14)];
XAdamsProxyBalanced      = [ones(NSize,1),rawdata_adams(1:NSize,16:21)];

% Making the left-out category of the caregorical variables zero
XRaceBalanced = XRaceBalanced-1;
XEducBalanced_orig = XEducBalanced;
XEducBalanced(XEducBalanced_orig==2) = 0;
XEducBalanced(XEducBalanced_orig==3) = 2;
XEducBalanced(XEducBalanced_orig==4) = 3;
XHsscBalanced_orig = XHsscBalanced;
XHsscBalanced(XHsscBalanced_orig==2)=0;
XHsscBalanced(XHsscBalanced_orig==3)=2;
XHsscBalanced(XHsscBalanced_orig==4)=3;

% Making missing time-invariant covariates consistent over time 
% (even if the person did not participate in the wave)
MisXRaceWide    = reshape(MisXRaceBalanced,NSizet,NSizex)';
MisXEducWide    = reshape(MisXEducBalanced,NSizet,NSizex)';
MisXForbornWide = reshape(MisXForbornBalanced,NSizet,NSizex)';
MisXHsscWide    = reshape(MisXHsscBalanced,NSizet,NSizex)';

MisXRace    = MisXRaceWide(:,1);
MisXEduc    = MisXEducWide(:,1);
MisXForborn = MisXForbornWide(:,1);
MisXHssc    = MisXHsscWide(:,1);

MisXRaceWide    = MisXRace*ones(1,NSizet);
MisXEducWide    = MisXEduc*ones(1,NSizet);
MisXForbornWide = MisXForborn*ones(1,NSizet);
MisXHsscWide    = MisXHssc*ones(1,NSizet);

MisXRaceBalanced    = reshape(MisXRaceWide',NSize,1);
MisXEducBalanced    = reshape(MisXEducWide',NSize,1);
MisXForbornBalanced = reshape(MisXForbornWide',NSize,1);
MisXHsscBalanced    = reshape(MisXHsscWide',NSize,1);

% Indicators of waves 5 & 6 
Wave5  = WavesBalanced==5;
Wave6  = WavesBalanced==6;

% Simple transformations of the indicator variables (Long, Wide, Shifted back, etc.)
IAdamsNonRespondentBalanced = (IAdamsSelectedBalanced>0.5) & (IAdamsRespondentBalanced<0.5);
IAdamsSelectedWide = reshape(IAdamsSelectedBalanced, NSizet, NSizex)';
IAdamsSelectedAny  = max(IAdamsSelectedWide,[],2);

IAdamsSelectedBalancedWA = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==21);
IAdamsSelectedBalancedWB = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==22); 
IAdamsSelectedBalancedWC = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==23); 
IAdamsSelectedBalancedWD = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==24); 
IAdamsSelectedShiftedWA  = [IAdamsSelectedBalancedWA(2:NSize);0]>0.5;

PriorWaveAdamsBalancedWA6 = PriorWaveAdamsBalanced==6 & WavesBalanced==21;
PriorWaveAdamsWideWA6 = reshape(PriorWaveAdamsBalancedWA6,NSizet,NSizex)';
W6WA         = max(PriorWaveAdamsWideWA6,[],2);
W6WAWide     = W6WA*ones(1,NSizet);
W6WABalanced = reshape(W6WAWide',NSize,1);

IHRSAllBalanced   = IHRSCoreBalanced | IAdamsSelectedBalanced;

IProxyCoreBalanced = IProxyAllBalanced;  
IProxyCoreBalanced(IAdamsSelectedBalanced) = 0; 
ISelfCoreBalanced  = ISelfAllBalanced;  
ISelfCoreBalanced(IAdamsSelectedBalanced)  = 0; 
IHRSCoreBalanced   = IProxyCoreBalanced | ISelfCoreBalanced;
IProxyCoreForward = [0;IProxyCoreBalanced(1:NSize-1)];
ISelfCoreForward  = [0;ISelfCoreBalanced(1:NSize-1)];

% ADAMS selection: Separately for waves 5 & 6 (Only consider W6 if not selected for W5)
Wave5Forward = [0;Wave5(1:NSize-1)]>0.5;
Wave6Forward = [0;Wave6(1:NSize-1)]>0.5;
IProxyAllBalancedW5 = Wave5Forward & IAdamsEligibleBalanced & IProxyCoreForward & AgeBalanced>0.5;
IProxyAllBalancedW6 = Wave6Forward & IAdamsEligibleBalanced & IProxyCoreForward & AgeBalanced>0.5;
ISelfAllBalancedW5  = Wave5Forward & IAdamsEligibleBalanced & ISelfCoreForward  & AgeBalanced>0.5;
ISelfAllBalancedW6  = Wave6Forward & IAdamsEligibleBalanced & ISelfCoreForward  & AgeBalanced>0.5;

XAdamsSelfBalancedW5  = XAdamsSelfBalanced(ISelfAllBalancedW5,:);
XAdamsSelfBalancedW6  = XAdamsSelfBalanced(ISelfAllBalancedW6,:);
XAdamsProxyBalancedW5 = XAdamsProxyBalanced(IProxyAllBalancedW5,:);
XAdamsProxyBalancedW6 = XAdamsProxyBalanced(IProxyAllBalancedW6,:);

IAdamsSelectedSelfW5  = IAdamsSelectedBalanced(ISelfAllBalancedW5);
IAdamsSelectedSelfW6  = IAdamsSelectedBalanced(ISelfAllBalancedW6);
IAdamsSelectedProxyW5 = IAdamsSelectedBalanced(IProxyAllBalancedW5);
IAdamsSelectedProxyW6 = IAdamsSelectedBalanced(IProxyAllBalancedW6);

% Wave indicators
Waves2Balanced = WavesBalanced;
Waves2Balanced(IAdamsSelectedBalanced>0.5) = PriorWaveAdamsBalanced(IAdamsSelectedBalanced>0.5);
WaveDummies = zeros(NSize,8);
WaveDummies(:,1) = Waves2Balanced==6;
WaveDummies(:,2) = Waves2Balanced==7;
WaveDummies(:,3) = Waves2Balanced==8;
WaveDummies(:,4) = Waves2Balanced==9;
WaveDummies(:,5) = Waves2Balanced==10;
WaveDummies(:,6) = Waves2Balanced==11;
WaveDummies(:,7) = Waves2Balanced==12;
WaveDummies(:,8) = Waves2Balanced>=13;


%%% Variables in survival 
DeadBalanced     = DeathAgeBalanced>-0.5; % People who are dead and we have precise age at death information

% Wide format
DeathAgeWide      = reshape(DeathAgeBalanced, NSizet, NSizex)';  
DeathAgeWide_min  = reshape(DeathAgeBalanced_min, NSizet, NSizex)';
DeathAgeWide_max  = reshape(DeathAgeBalanced_max, NSizet, NSizex)';
DeadWide          = reshape(DeadBalanced, NSizet, NSizex)';

% Cross-sectional format
DeathAgeX     = DeathAgeWide(:,1);
DeathAgeX_min = DeathAgeWide_min(:,1);
DeathAgeX_max = DeathAgeWide_max(:,1);
DeadX         = DeadWide(:,1);
DeathObservedX = (DeadX | DeathAgeX_max>0 & DeathAgeX_max<10) & (DeathAgeX>0.5 | DeathAgeX_min>0.5); % People who are know to be dead
DeathMis = DeadX < 0.5 & DeathObservedX>0.5; % People who are known to be dead, but we do not have precise age at death information

% Ages various times before death
NumDeads = sum(DeathObservedX);
DeathAgeGrids = zeros(NumDeads,6);
DeathAgeGrids(:,6) = DeathAgeX(DeathObservedX);
DeathAgeGrids(DeathMis(DeathObservedX),6) = (DeathAgeX_min(DeathMis) + DeathAgeX_max(DeathMis))/2;
DeathAgeGrids(:,5) = DeathAgeGrids(:,6) - 0.05; 
DeathAgeGrids(:,4) = DeathAgeGrids(:,6) - 0.1; 
DeathAgeGrids(:,3) = DeathAgeGrids(:,6) - 0.2; 
DeathAgeGrids(:,2) = DeathAgeGrids(:,6) - 0.3; 
DeathAgeGrids(:,1) = DeathAgeGrids(:,6) - 0.5; 


BaseAgeAdamsWA   = AgeBalanced(IAdamsSelectedShiftedWA);
BaseAgeShiftedWA = zeros(NSize,1);
BaseAgeShiftedWA(IAdamsSelectedShiftedWA) = BaseAgeAdamsWA;

IHRSSelect1Wide = zeros(NSizex,NSizet)>0.5;
IHRSSelect1Wide(:,1) = 1;
IHRSSelect1Balanced = reshape(IHRSSelect1Wide',NSize,1);


%Variables in ADAMS interview timing
%WA
NAdamsWA = size(BaseAgeAdamsWA,1);
IWTimeWA = zeros(NSize,1);
IWTimeWA(IAdamsSelectedBalancedWA) = log(rawdata_ages(IAdamsSelectedBalancedWA,3) - BaseAgeShiftedWA(IAdamsSelectedShiftedWA));
XAdamsTimeDemWA = [ones(NAdamsWA,1), W6WABalanced(IAdamsSelectedShiftedWA,1)];
XXAgeA          = AgeBalanced(IAdamsSelectedShiftedWA,:);
XAdamsTimeAgeWA = [XXAgeA, XXAgeA.*W6WABalanced(IAdamsSelectedShiftedWA,1)];
XAdamsTimeWA = [XAdamsTimeDemWA, XAdamsTimeAgeWA];

%WB
AgeWA = zeros(NSizex,1);
AgeWA(IAdamsSelectedAny) = AgeBalanced(IAdamsSelectedBalancedWA,1);
AgeWAWide = AgeWA*ones(1,NSizet);
AgeWABalanced = reshape(AgeWAWide',NSize,1);

NAdamsWB = sum(IAdamsSelectedBalancedWB);
IWTimeWB = zeros(NSize,1);
IWTimeWB(IAdamsSelectedBalancedWB) = log(AgeBalanced(IAdamsSelectedBalancedWB,1) - AgeWABalanced(IAdamsSelectedBalancedWB));
XAdamsTimeDemWB = [ones(NAdamsWB,1), W6WABalanced(IAdamsSelectedBalancedWB)];
XXAgeB          = AgeWABalanced(IAdamsSelectedBalancedWB);
XAdamsTimeAgeWB = [XXAgeB, XXAgeB.*W6WABalanced(IAdamsSelectedBalancedWB,1)];
XAdamsTimeWB = [XAdamsTimeDemWB, XAdamsTimeAgeWB];

%WC
NAdamsWC = sum(IAdamsSelectedBalancedWC);
IWTimeWC = zeros(NSize,1);
IWTimeWC(IAdamsSelectedBalancedWC) = log(AgeBalanced(IAdamsSelectedBalancedWC,1) - AgeWABalanced(IAdamsSelectedBalancedWC));
XAdamsTimeDemWC = [ones(NAdamsWC,1), W6WABalanced(IAdamsSelectedBalancedWC)];
XXAgeC          = AgeWABalanced(IAdamsSelectedBalancedWC);
XAdamsTimeAgeWC = [XXAgeC, XXAgeC.*W6WABalanced(IAdamsSelectedBalancedWC,1)];
XAdamsTimeWC = [XAdamsTimeDemWC, XAdamsTimeAgeWC];

%WD
NAdamsWD = sum(IAdamsSelectedBalancedWD);
IWTimeWD = zeros(NSize,1);
IWTimeWD(IAdamsSelectedBalancedWD) = log(AgeBalanced(IAdamsSelectedBalancedWD,1) - AgeWABalanced(IAdamsSelectedBalancedWD));
XAdamsTimeDemWD = [ones(NAdamsWD,1), W6WABalanced(IAdamsSelectedBalancedWD)];
XXAgeD          = AgeWABalanced(IAdamsSelectedBalancedWD);
XAdamsTimeAgeWD = [XXAgeD, XXAgeD.*W6WABalanced(IAdamsSelectedBalancedWD,1)];
XAdamsTimeWD = [XAdamsTimeDemWD, XAdamsTimeAgeWD];


%Variables in ADAMS response
NAdamsSurvWA = sum(IAdamsSurvivedBalanced & WavesBalanced==21);
NAdamsSurvWB = sum(IAdamsSurvivedBalanced & WavesBalanced==22);
NAdamsSurvWC = sum(IAdamsSurvivedBalanced & WavesBalanced==23);
NAdamsSurvWD = sum(IAdamsSurvivedBalanced & WavesBalanced==24);
IAdamsSurvivedBalancedWA = IAdamsSurvivedBalanced & WavesBalanced==21;
IAdamsSurvivedBalancedWB = IAdamsSurvivedBalanced & WavesBalanced==22;
IAdamsSurvivedBalancedWC = IAdamsSurvivedBalanced & WavesBalanced==23;
IAdamsSurvivedBalancedWD = IAdamsSurvivedBalanced & WavesBalanced==24;
XAdamsRespDemWA = ones(NAdamsSurvWA,1);
XAdamsRespDemWB = ones(NAdamsSurvWB,1);
XAdamsRespDemWC = ones(NAdamsSurvWC,1);
XAdamsRespDemWD = ones(NAdamsSurvWD,1);
XAdamsRespAgeWA = AgeBalanced(IAdamsSurvivedBalancedWA,:);
XAdamsRespAgeWB = AgeBalanced(IAdamsSurvivedBalancedWB,:);
XAdamsRespAgeWC = AgeBalanced(IAdamsSurvivedBalancedWC,:);
XAdamsRespAgeWD = AgeBalanced(IAdamsSurvivedBalancedWD,:);


% Wave-by-wave change in age (or since age 65 in period 1)
AgeWide       = reshape(AgeBalanced, NSizet, NSizex)';
DAgeWide      = zeros(NSizex,NSizet);
DAgeWide(:,1) = AgeWide(:,1);
for i=2:NSizet
    DAgeWide(:,i) = AgeWide(:,i) - AgeWide(:,i-1);
end
DAgeWide(DAgeWide<0.01) = 0.01;
DAgeBalanced = reshape(DAgeWide',NSize,1);

% Age is excatly 65 (to model missing mental status)
Age65Balanced = AgeBalanced<0.1;

% Storing all data in a structure
Data.NSize    = NSize;
Data.NSizet   = NSizet;
Data.NSizex   = NSizex;

Data.WavesBalanced = WavesBalanced;
Data.WaveDummies   = WaveDummies;
Data.W6WAWide      = W6WAWide;
Data.W6WABalanced  = W6WABalanced;

Data.AgeBalanced     = AgeBalanced;
Data.Age65Balanced   = Age65Balanced;
Data.DAgeWide        = DAgeWide ;
Data.DAgeBalanced    = DAgeBalanced;
Data.AgeWABalanced   = AgeWABalanced;
Data.DeathAgeX       = DeathAgeX;
Data.DeathAgeX_min   = DeathAgeX_min;
Data.DeathAgeX_max   = DeathAgeX_max;
Data.DeadX           = DeadX;
Data.AgeBalanced_Min = AgeBalanced_Min;
Data.AgeBalanced_Max = AgeBalanced_Max;

Data.DeathObservedX = DeathObservedX;
Data.DeathMis       = DeathMis;
Data.NumDeads       = NumDeads;
Data.DeathAgeGrids  = DeathAgeGrids;

Data.XRaceBalanced      = XRaceBalanced;
Data.XEducBalanced      = XEducBalanced;
Data.XForbornBalanced   = XForbornBalanced;
Data.XHsscBalanced      = XHsscBalanced;
Data.XSingleBalanced    = XSingleBalanced;
Data.XFemaleBalanced    = XFemaleBalanced;
Data.XStrokeBalanced    = XStrokeBalanced;
Data.FirstSelfBalanced  = FirstSelfBalanced;
Data.WeightsBalanced    = WeightsBalanced;
Data.XBirthYearBalanced = XBirthYearBalanced;

Data.MisXRaceBalanced    = MisXRaceBalanced;
Data.MisXEducBalanced    = MisXEducBalanced;
Data.MisXForbornBalanced = MisXForbornBalanced;
Data.MisXHsscBalanced    = MisXHsscBalanced;
Data.MisXSingleBalanced  = MisXSingleBalanced;
Data.MisXStrokeBalanced  = MisXStrokeBalanced;

Data.XAdamsTimeWA = XAdamsTimeWA;
Data.XAdamsTimeWB = XAdamsTimeWB;
Data.XAdamsTimeWC = XAdamsTimeWC;
Data.XAdamsTimeWD = XAdamsTimeWD;
Data.XAdamsRespDemWA = XAdamsRespDemWA;
Data.XAdamsRespDemWB = XAdamsRespDemWB;
Data.XAdamsRespDemWC = XAdamsRespDemWC;
Data.XAdamsRespDemWD = XAdamsRespDemWD;
Data.XAdamsRespAgeWA = XAdamsRespAgeWA;
Data.XAdamsRespAgeWB = XAdamsRespAgeWB;
Data.XAdamsRespAgeWC = XAdamsRespAgeWC;
Data.XAdamsRespAgeWD = XAdamsRespAgeWD;

Data.DementedBalanced = DementedBalanced;
Data.CindBalanced     = CindBalanced;
Data.NormalcBalanced  = NormalcBalanced;

Data.YCogAllBalanced    = YCogAllBalanced;
Data.YCogSelf1Balanced  = YCogSelf1Balanced ;
Data.YCogSelf2Balanced  = YCogSelf2Balanced ;
Data.YCogSelf3Balanced  = YCogSelf3Balanced ;
Data.YCogSelf4Balanced  = YCogSelf4Balanced ;
Data.YCogProxy1Balanced = YCogProxy1Balanced;
Data.YCogProxy2Balanced = YCogProxy2Balanced;

Data.MisYAllBalanced    = MisYAllBalanced;
Data.MisYSelf1Balanced  = MisYSelf1Balanced;
Data.MisYSelf2Balanced  = MisYSelf2Balanced;
Data.MisYSelf3Balanced  = MisYSelf3Balanced;
Data.MisYSelf4Balanced  = MisYSelf4Balanced;
Data.MisYProxy1Balanced = MisYProxy1Balanced;
Data.MisYProxy2Balanced = MisYProxy2Balanced;

Data.IProxyAllBalanced  = IProxyAllBalanced;
Data.IHRSAllBalanced    = IHRSAllBalanced;
Data.IProxyCoreBalanced = IProxyCoreBalanced;
Data.ISelfCoreBalanced  = ISelfCoreBalanced;
Data.IHRSCoreBalanced   = IHRSCoreBalanced;
Data.IHRSSelect1Balanced = IHRSSelect1Balanced;

Data.IAdamsSurvivedBalanced   = IAdamsSurvivedBalanced;
Data.IAdamsRespondentBalanced = IAdamsRespondentBalanced;
Data.IAdamsNonRespondentBalanced = IAdamsNonRespondentBalanced;
Data.IAdamsSelectedBalanced   = IAdamsSelectedBalanced;
Data.IAdamsSelectedShiftedWA  = IAdamsSelectedShiftedWA;

Data.IProxyAllBalancedW5 = IProxyAllBalancedW5;
Data.IProxyAllBalancedW6 = IProxyAllBalancedW6;
Data.ISelfAllBalancedW5  = ISelfAllBalancedW5;
Data.ISelfAllBalancedW6  = ISelfAllBalancedW6;

Data.XAdamsSelfBalancedW5  = XAdamsSelfBalancedW5;
Data.XAdamsSelfBalancedW6  = XAdamsSelfBalancedW6;
Data.XAdamsProxyBalancedW5 = XAdamsProxyBalancedW5;
Data.XAdamsProxyBalancedW6 = XAdamsProxyBalancedW6;

Data.IAdamsSelectedSelfW5  = IAdamsSelectedSelfW5;
Data.IAdamsSelectedSelfW6  = IAdamsSelectedSelfW6;
Data.IAdamsSelectedProxyW5 = IAdamsSelectedProxyW5;
Data.IAdamsSelectedProxyW6 = IAdamsSelectedProxyW6;

Data.IWTimeWA = IWTimeWA;
Data.IWTimeWB = IWTimeWB;
Data.IWTimeWC = IWTimeWC;
Data.IWTimeWD = IWTimeWD;
fprintf(' data loaded ***\n');