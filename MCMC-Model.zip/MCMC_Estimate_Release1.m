function Results = MCMC_Estimate_Release1(Data)
% Estimating the model with MCMC 

% Initializing the random number generator
rng('shuffle');
%rng(12345);

% Simulation draws
TotalDraws    = 2000;
BurnedDraws   = floor(TotalDraws/10);  % Burn the first 10%
UsedDraws     = TotalDraws - BurnedDraws + 1;
Thinning      = 10; % Only a thinned version of the simulation draws are saved to save space. (But we use all simulation draws for inference.)
PrevThinning  = 10; % The prevalence simulations are thinned to save space. I only save every Xth simulation draws
UsedThinDraws = floor((UsedDraws-1)/PrevThinning) + 1;
IndThinning   = 20; % The individual cognition simulations are thinned to save space. I only save every Xth simulation draws
UsedIndDraws  = floor((UsedDraws-1)/IndThinning) + 1;
DrawsNotify   = round(TotalDraws/20); % Write the progress of the estimation on the screen


% Reading the data from the structure
NSize    = Data.NSize;  % Total sample size (long)
NSizet   = Data.NSizet; % Number of periods (HRS and ADAMS waves)
NSizex   = Data.NSizex; % Number of people

WavesBalanced = Data.WavesBalanced; % Interview waves
WaveDummies   = Data.WaveDummies;   % Wave indicator dummies
W6WABalanced  = Data.W6WABalanced;  % ... same in long format

AgeBalanced     = Data.AgeBalanced;     % Age
Age65Balanced   = Data.Age65Balanced;   % Indicator if age is exactly 65 (predictor of missing mental status)
AgeWABalanced   = Data.AgeWABalanced;   % Age at ADAMS WA
DeathAgeX       = Data.DeathAgeX;       % Age at death of each person
DeathAgeX_min   = Data.DeathAgeX_min;   % lowest possible age at death
DeathAgeX_max   = Data.DeathAgeX_max;   % lowest possible age at death
DeadX           = Data.DeadX;           % Identifying people who are observed to die in the HRS
AgeBalanced_Min = Data.AgeBalanced_Min; % Lower boundary of possible ages at ADAMS interview (non-responders)
AgeBalanced_Max = Data.AgeBalanced_Max; % Upper boundary of possible ages at ADAMS interview (non-responders)

DeathObservedX = Data.DeathObservedX;   % Identifying the sample who are observed to die at age 70 or older
DeathMis       = Data.DeathMis;         % Identifies the sample with only partially observed death ages
NumDeads       = Data.NumDeads;         % The size of the sample observed to die
DeathAgeGrids  = Data.DeathAgeGrids;    % Ages at which cognition is estimated before death 

XFemaleBalanced    = Data.XFemaleBalanced;    % Female
XRaceBalanced      = Data.XRaceBalanced;      % Race
XEducBalanced      = Data.XEducBalanced;      % Education
XForbornBalanced   = Data.XForbornBalanced;   % Foreign born
XHsscBalanced      = Data.XHsscBalanced;      % Household social security income
XSingleBalanced    = Data.XSingleBalanced;    % Single
XStrokeBalanced    = Data.XStrokeBalanced;    % Ever had a stroke (self-reported)
MisXRaceBalanced   = Data.MisXRaceBalanced>0.5;    % Missing Race
MisXEducBalanced   = Data.MisXEducBalanced>0.5;    % Missing Education
MisXForbornBalanced= Data.MisXForbornBalanced>0.5; % Missing Foreign born
MisXHsscBalanced   = Data.MisXHsscBalanced>0.5;    % Missing Household social security income
MisXSingleBalanced = Data.MisXSingleBalanced>0.5;  % Missing Single
MisXStrokeBalanced = Data.MisXStrokeBalanced>0.5;  % Missing Ever had a stroke (self-reported)
FirstSelfBalanced  = Data.FirstSelfBalanced;  % Identifies the person's first self interview in the HRS (not necessarily in our sample) 
WeightsBalanced    = Data.WeightsBalanced;    % Survey weights to estimate weighted prevalence
XBirthYearBalanced = Data.XBirthYearBalanced; % Birthyear
XAdamsTimeWA  = Data.XAdamsTimeWA;            % Covariates in ADAMS WA interview timing
XAdamsTimeWB  = Data.XAdamsTimeWB;            % Covariates in ADAMS WB interview timing
XAdamsTimeWC  = Data.XAdamsTimeWC;            % Covariates in ADAMS WC interview timing
XAdamsTimeWD  = Data.XAdamsTimeWD;            % Covariates in ADAMS WD interview timing
XAdamsRespDemWA  = Data.XAdamsRespDemWA;      % Covariates other than age in ADAMS WA response status
XAdamsRespDemWB  = Data.XAdamsRespDemWB;      % Covariates other than age in ADAMS WB response status
XAdamsRespDemWC  = Data.XAdamsRespDemWC;      % Covariates other than age in ADAMS WC response status
XAdamsRespDemWD  = Data.XAdamsRespDemWD;      % Covariates other than age in ADAMS WD response status
XAdamsRespAgeWA  = Data.XAdamsRespAgeWA;      % Age in ADAMS WA response status
XAdamsRespAgeWB  = Data.XAdamsRespAgeWB;      % Age in ADAMS WB response status
XAdamsRespAgeWC  = Data.XAdamsRespAgeWC;      % Age in ADAMS WC response status
XAdamsRespAgeWD  = Data.XAdamsRespAgeWD;      % Age in ADAMS WD response status

DementedBalanced = Data.DementedBalanced;  % Dementia diagnosis in ADAMS
CindBalanced     = Data.CindBalanced;      % CIND diagnosis in ADAMS
NormalcBalanced  = Data.NormalcBalanced;   % Normal cognitive status diagnosis in ADAMS

YCogAllBalanced    = Data.YCogAllBalanced;    % The HRS cognitive measure available in all interviews
YCogSelf1Balanced  = Data.YCogSelf1Balanced ; % The HRS cognitive measure in self interviews
YCogSelf2Balanced  = Data.YCogSelf2Balanced ; % The HRS cognitive measure in self interviews
YCogSelf3Balanced  = Data.YCogSelf3Balanced ; % The HRS cognitive measure in self interviews
YCogSelf4Balanced  = Data.YCogSelf4Balanced ; % The HRS cognitive measure in self interviews
YCogProxy1Balanced = Data.YCogProxy1Balanced; % The HRS cognitive measure in proxy interviews
YCogProxy2Balanced = Data.YCogProxy2Balanced; % The HRS cognitive measure in proxy interviews

MisYAllBalanced    = Data.MisYAllBalanced;    % Missing flags for cognitive measure available in all interviews
MisYSelf1Balanced  = Data.MisYSelf1Balanced;  % Missing flags for cognitive measure available in self interviews
MisYSelf2Balanced  = Data.MisYSelf2Balanced;  % Missing flags for cognitive measure available in self interviews
MisYSelf3Balanced  = Data.MisYSelf3Balanced;  % Missing flags for cognitive measure available in self interviews
MisYSelf4Balanced  = Data.MisYSelf4Balanced;  % Missing flags for cognitive measure available in self interviews
MisYProxy1Balanced = Data.MisYProxy1Balanced; % Missing flags for cognitive measure available in proxy interviews
MisYProxy2Balanced = Data.MisYProxy2Balanced; % Missing flags for cognitive measure available in proxy interviews

IHRSAllBalanced    = Data.IHRSAllBalanced;     % Identifying HRS and ADAMS interviews 
IProxyCoreBalanced = Data.IProxyCoreBalanced;  % Identifying HRS core proxy interviews 
ISelfCoreBalanced  = Data.ISelfCoreBalanced;   % Identifying HRS core self interviews 
IHRSCoreBalanced   = Data.IHRSCoreBalanced;    % Identifying HRS core interviews 
IHRSSelect1Balanced = Data.IHRSSelect1Balanced; % Identifying the first waves of each observation

IAdamsSurvivedBalanced   = Data.IAdamsSurvivedBalanced;   % Identifying survivors to ADAMS interviews 
IAdamsRespondentBalanced = Data.IAdamsRespondentBalanced; % Identifying ADAMS respondents 
IAdamsNonRespondentBalanced = Data.IAdamsNonRespondentBalanced; % Identifying ADAMS non-respondents (dead or refused) 
IAdamsSelectedBalanced   = Data.IAdamsSelectedBalanced;  % Identifying those selected for ADAMS 
IAdamsSelectedShiftedWA  = Data.IAdamsSelectedShiftedWA; % Identifying those selected for ADAMS WA

IProxyAllBalancedW5 = Data.IProxyAllBalancedW5; % Identifying proxy interviews in HRS wave 5
IProxyAllBalancedW6 = Data.IProxyAllBalancedW6; % Identifying proxy interviews in HRS wave 6
ISelfAllBalancedW5  = Data.ISelfAllBalancedW5;  % Identifying self interviews in HRS wave 5
ISelfAllBalancedW6  = Data.ISelfAllBalancedW6;  % Identifying self interviews in HRS wave 6

XAdamsSelfBalancedW5  = Data.XAdamsSelfBalancedW5; %Covariates in ADAMS selection...
XAdamsSelfBalancedW6  = Data.XAdamsSelfBalancedW6;
XAdamsProxyBalancedW5 = Data.XAdamsProxyBalancedW5;
XAdamsProxyBalancedW6 = Data.XAdamsProxyBalancedW6;

IAdamsSelectedSelfW5  = Data.IAdamsSelectedSelfW5; % Identifying the sample selected fro ADAMS
IAdamsSelectedSelfW6  = Data.IAdamsSelectedSelfW6;
IAdamsSelectedProxyW5 = Data.IAdamsSelectedProxyW5;
IAdamsSelectedProxyW6 = Data.IAdamsSelectedProxyW6;

IWTimeWA = Data.IWTimeWA; %ADAMS interview times...
IWTimeWB = Data.IWTimeWB;
IWTimeWC = Data.IWTimeWC;
IWTimeWD = Data.IWTimeWD;


% The upper and lower bounds of the cognition scores and the ordered probit
% variable
YSelf2LowValue  = 0;
YSelf3LowValue  = 0;
YSelf3HighValue = 5;
YSelf4HighValue = 9;
YProxy2LowValue  = 0;
YProxy2HighValue = 4;

ICogSelf2LowBalanced   = YCogSelf2Balanced<=YSelf2LowValue&ISelfCoreBalanced==1&MisYSelf2Balanced==0;
ICogSelf3LowBalanced   = YCogSelf3Balanced<=YSelf3LowValue&ISelfCoreBalanced==1&MisYSelf3Balanced==0;
ICogSelf3HighBalanced  = YCogSelf3Balanced>=YSelf3HighValue&ISelfCoreBalanced==1&MisYSelf3Balanced==0;
ICogSelf4HighBalanced  = YCogSelf4Balanced>=YSelf4HighValue&ISelfCoreBalanced==1&MisYSelf4Balanced==0;
ICogProxy2LowBalanced  = YCogProxy2Balanced<=YProxy2LowValue&IProxyCoreBalanced==1&MisYProxy2Balanced==0;
ICogProxy2HighBalanced = YCogProxy2Balanced>=YProxy2HighValue&IProxyCoreBalanced==1&MisYProxy2Balanced==0;

ICogProxy1CatsBalanced = YCogProxy1Balanced;
ICogProxy1CatsCoreProxy = ICogProxy1CatsBalanced(IProxyCoreBalanced);
YCogProxy1Balanced(ICogProxy1CatsBalanced==0) = -1;
YCogProxy1Balanced(ICogProxy1CatsBalanced==1) = 0.5;
YCogProxy1Balanced(ICogProxy1CatsBalanced==2) = 2;

% Reshaping the data to wide
IProxyCoreWide       = reshape(IProxyCoreBalanced,NSizet,NSizex)';
ISelfCoreWide        = reshape(ISelfCoreBalanced,NSizet,NSizex)';
IHRSAllWide          = reshape(IHRSAllBalanced,NSizet,NSizex)';
IHRSCoreWide         = reshape(IHRSCoreBalanced,NSizet, NSizex)';
IAdamsRespondentWide = reshape(IAdamsRespondentBalanced,NSizet, NSizex)';
IAdamsSelectedWide   = reshape(IAdamsSelectedBalanced,NSizet, NSizex)';  % ADAMS selection in wide format
YCogAllWide    = reshape(YCogAllBalanced, NSizet,NSizex)'; % HRS cognitive measures in all iws
XBirthYearWide = reshape(XBirthYearBalanced, NSizet,NSizex)'; % Birth year
XFemaleWide     = reshape(XFemaleBalanced,NSizet,NSizex)';     % Gender
XRaceWide       = reshape(XRaceBalanced,NSizet,NSizex)';       % Race
XEducWide       = reshape(XEducBalanced,NSizet,NSizex)';       % Education
XForbornWide    = reshape(XForbornBalanced,NSizet,NSizex)';    % Foreign born
XHsscWide       = reshape(XHsscBalanced,NSizet,NSizex)';       % Household social security income
XSingleWide     = reshape(XSingleBalanced,NSizet,NSizex)';     % Single
XStrokeWide     = reshape(XStrokeBalanced,NSizet,NSizex)';     % Ever had a stroke (self-reported)
MisXRaceWide    = reshape(MisXRaceBalanced,NSizet,NSizex)'>0.5;    % Missing Race
MisXEducWide    = reshape(MisXEducBalanced,NSizet,NSizex)'>0.5;    % Missing Education
MisXForbornWide = reshape(MisXForbornBalanced,NSizet,NSizex)'>0.5; % Missing Foreign born
MisXHsscWide    = reshape(MisXHsscBalanced,NSizet,NSizex)'>0.5;    % Missing Household social security income
MisXSingleWide  = reshape(MisXSingleBalanced,NSizet,NSizex)'>0.5;  % Missing Single
MisXStrokeWide  = reshape(MisXStrokeBalanced,NSizet,NSizex)'>0.5;  % Missing Ever had a stroke (self-reported)

MisXRace    = MisXRaceWide(:,1)>0.5;     % Missing Race in cross-section
MisXEduc    = MisXEducWide(:,1)>0.5;     % Missing Education in cross-section
MisXForborn = MisXForbornWide(:,1)>0.5 ; % Missing Foreign born in cross-section
MisXHssc    = MisXHsscWide(:,1)>0.5 ;    % Missing Household social security income in cross-section
MisXSingleAny = sum(MisXSingleWide,2)>0.5; % Any missing marital status in cross-section
MisXStrokeAny = sum(MisXStrokeWide,2)>0.5; % Any missing stroke status in cross-section
MisXAny     =  MisXRace | MisXEduc | MisXForborn | MisXHssc | MisXSingleAny | MisXStrokeAny; % Any missing covariate
MisXAnyWide = MisXAny*ones(1,NSizet);
MisXAnyBalanced = reshape(MisXAnyWide', NSize,1)>0.5;

% First periods
XBirthYear = XBirthYearWide(:,1);
XFemale    = XFemaleWide(:,1);
XRace      = XRaceWide(:,1);
XEduc      = XEducWide(:,1);
XForborn   = XForbornWide(:,1);
XHssc      = XHsscWide(:,1);


% Creating the interactions with the ADAMS waves
IAdamsSelectedBalancedWA = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==21);
IAdamsSelectedBalancedWB = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==22); 
IAdamsSelectedBalancedWC = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==23); 
IAdamsSelectedBalancedWD = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==24); 

IAdamsSurvivedBalancedWA = IAdamsSurvivedBalanced & WavesBalanced==21;
IAdamsSurvivedBalancedWB = IAdamsSurvivedBalanced & WavesBalanced==22;
IAdamsSurvivedBalancedWC = IAdamsSurvivedBalanced & WavesBalanced==23;
IAdamsSurvivedBalancedWD = IAdamsSurvivedBalanced & WavesBalanced==24;

IAdamsNonRespondentBalancedWA = IAdamsNonRespondentBalanced & IAdamsSelectedBalancedWA;
IAdamsNonRespondentBalancedWB = IAdamsNonRespondentBalanced & IAdamsSelectedBalancedWB;
IAdamsNonRespondentBalancedWC = IAdamsNonRespondentBalanced & IAdamsSelectedBalancedWC;
IAdamsNonRespondentBalancedWD = IAdamsNonRespondentBalanced & IAdamsSelectedBalancedWD;

IAdamsRespondentBalancedWA = IAdamsRespondentBalanced & WavesBalanced==21;
IAdamsRespondentBalancedWB = IAdamsRespondentBalanced & WavesBalanced==22;
IAdamsRespondentBalancedWC = IAdamsRespondentBalanced & WavesBalanced==23;
IAdamsRespondentBalancedWD = IAdamsRespondentBalanced & WavesBalanced==24;

DementedAdams = DementedBalanced(IAdamsRespondentBalanced);  
CindAdams     = CindBalanced(IAdamsRespondentBalanced);      
NormalcAdams  = NormalcBalanced(IAdamsRespondentBalanced);   


%%% Creating other important indicator variables
% Missing cognition measures among core, self/proxy interviews.
MisYAllCore = MisYAllBalanced(IHRSCoreBalanced);
MisYSelf1Core = MisYSelf1Balanced(ISelfCoreBalanced);
MisYSelf2Core = MisYSelf2Balanced(ISelfCoreBalanced);
MisYSelf3Core = MisYSelf3Balanced(ISelfCoreBalanced);
MisYSelf4Core = MisYSelf4Balanced(ISelfCoreBalanced);
MisYProxy1Core = MisYProxy1Balanced(IProxyCoreBalanced);
MisYProxy2Core = MisYProxy2Balanced(IProxyCoreBalanced);

IHRSCoreAdamsNonRespWide = (IHRSCoreWide>0.5) | ((IAdamsSelectedWide>0.5) & (IAdamsRespondentWide<0.5));  % Total sample minus ADAMS responders
IHRSCoreAdamsNonRespBalanced = reshape(IHRSCoreAdamsNonRespWide',NSize,1)>0.5;

IAdamsSurvNonRespWA = IAdamsSurvivedBalanced(IAdamsNonRespondentBalanced & WavesBalanced==21); % ADAMS survivors among non-responders
IAdamsSurvNonRespWB = IAdamsSurvivedBalanced(IAdamsNonRespondentBalanced & WavesBalanced==22);
IAdamsSurvNonRespWC = IAdamsSurvivedBalanced(IAdamsNonRespondentBalanced & WavesBalanced==23);
IAdamsSurvNonRespWD = IAdamsSurvivedBalanced(IAdamsNonRespondentBalanced & WavesBalanced==24);

IAdamsNonRespondentShiftedWA  = [IAdamsNonRespondentBalancedWA(2:NSize);0]>0.5; % Identifying lags of ADAMS non-respondents 
IAdamsNonRespondentShiftedWB  = [IAdamsNonRespondentBalancedWB(2:NSize);0]>0.5;
IAdamsNonRespondentShiftedWC  = [IAdamsNonRespondentBalancedWC(2:NSize);0]>0.5;
IAdamsNonRespondentShiftedWD  = [IAdamsNonRespondentBalancedWD(2:NSize);0]>0.5;

IAdamsRespondentSurvWA = IAdamsRespondentBalanced(IAdamsSurvivedBalanced& WavesBalanced==21); % ADAMS respondents among survivors
IAdamsRespondentSurvWB = IAdamsRespondentBalanced(IAdamsSurvivedBalanced& WavesBalanced==22);
IAdamsRespondentSurvWC = IAdamsRespondentBalanced(IAdamsSurvivedBalanced& WavesBalanced==23);
IAdamsRespondentSurvWD = IAdamsRespondentBalanced(IAdamsSurvivedBalanced& WavesBalanced==24);

IProxyCore = IProxyCoreBalanced(IHRSCoreBalanced); % Proxy interviews among core interviews

aux1 = ones(NSize,1)*(-100);
aux1(IAdamsSelectedBalancedWB) = 1;
aux2 = reshape(aux1,NSizet,NSizex);
IAnyAdamsSelectedWBX = max(aux2)'; % Any WB interviews
IAnyAdamsSelectedWBWide     = IAnyAdamsSelectedWBX*ones(1,NSizet);
IAnyAdamsSelectedWBBalanced = reshape(IAnyAdamsSelectedWBWide',NSize,1)>0.5;

aux1 = ones(NSize,1)*(-100);
aux1(IAdamsSelectedBalancedWC) = 1;
aux2 = reshape(aux1,NSizet,NSizex);
IAnyAdamsSelectedWCX = max(aux2)'; % Any WC interviews
IAnyAdamsSelectedWCWide     = IAnyAdamsSelectedWCX*ones(1,NSizet);
IAnyAdamsSelectedWCBalanced = reshape(IAnyAdamsSelectedWCWide',NSize,1)>0.5;

aux1 = ones(NSize,1)*(-100);
aux1(IAdamsSelectedBalancedWD) = 1;
aux2 = reshape(aux1,NSizet,NSizex);
IAnyAdamsSelectedWDX = max(aux2)'; % Any WD interviews
IAnyAdamsSelectedWDWide     = IAnyAdamsSelectedWDX*ones(1,NSizet);
IAnyAdamsSelectedWDBalanced = reshape(IAnyAdamsSelectedWDWide',NSize,1)>0.5;

Ind2THRSAllWide = [zeros(NSizex,1), IHRSAllWide(:,2:NSizet)]; % Identifies all HRS observations except the first one (used for modeling changes in the time-varying predictor (marital status & stroke))
Ind2THRSAllBalanced = reshape(Ind2THRSAllWide',NSize,1)>0.5;  % Same in long format
Ind1T1HRSAllBalanced = [Ind2THRSAllBalanced(2:NSize);0]>0.5;  % Same in shifted back one period to have values from period 1 to T-1


% The right hand side variables
CenterAge = 1;
[XCogDemBalanced, XCogAgeBalanced, XCogBalanced, XProxyBalanced, XHRSSurv, XVarsBalanced, XVarsMisBalanced] = XVarsLoad(XRaceBalanced, XEducBalanced, XForbornBalanced, XHsscBalanced, XSingleBalanced, XFemaleBalanced, AgeBalanced, CenterAge, XStrokeBalanced, WaveDummies, XBirthYearBalanced, IHRSSelect1Balanced, NSizex, NSize);

%Indicators for selected groups to store interesting prevalence estimates
AgeGroups = -ones(NSize,1);
AgeGroups(AgeBalanced>=0&AgeBalanced<1) = 0;
AgeGroups(AgeBalanced>=1&AgeBalanced<2) = 1;
AgeGroups(AgeBalanced>=2&AgeBalanced<50) = 2;

DimPrevGroupsCompare = 12; % Number of groups to compare to the literature
IndPrevsCompare = zeros(NSize,DimPrevGroupsCompare)>0.5;
IndPrevsCompare(:,1)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6;
IndPrevsCompare(:,2)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & XFemaleBalanced==0;
IndPrevsCompare(:,3)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & XFemaleBalanced==1;
IndPrevsCompare(:,4)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & AgeBalanced<1.5;
IndPrevsCompare(:,5)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & AgeBalanced<1.5 & XFemaleBalanced==0;
IndPrevsCompare(:,6)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & AgeBalanced<1.5 & XFemaleBalanced==1;
IndPrevsCompare(:,7)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=1.5 & AgeBalanced<2.5;
IndPrevsCompare(:,8)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=1.5 & AgeBalanced<2.5 & XFemaleBalanced==0;
IndPrevsCompare(:,9)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=1.5 & AgeBalanced<2.5 & XFemaleBalanced==1;
IndPrevsCompare(:,10) = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=2.5;
IndPrevsCompare(:,11) = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=2.5 & XFemaleBalanced==0;
IndPrevsCompare(:,12) = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=2.5 & XFemaleBalanced==1;

[IndPrevsGender , DimPrevGroupsGender]   = IndPrevsInitG1(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, NSize);                   % Indicators for all waves and gender 
[IndPrevsAge    , DimPrevGroupsAge]      = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, AgeGroups       , NSize); % Indicators for all waves, gender, and age groups
[IndPrevsRace   , DimPrevGroupsRace]     = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XRaceBalanced   , NSize); % Indicators for all waves, gender, and race
[IndPrevsForborn, DimPrevGroupsForborn]  = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XForbornBalanced, NSize); % Indicators for all waves, gender, and foreign born status
[IndPrevsEduc   , DimPrevGroupsEduc]     = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XEducBalanced   , NSize); % Indicators for all waves, gender, and education
[IndPrevsHssc   , DimPrevGroupsHssc]     = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XHsscBalanced   , NSize); % Indicators for all waves, gender, and wealth

WeightedIndsCompare = WeightIndInit(IndPrevsCompare, WeightsBalanced, DimPrevGroupsCompare, NSize); % Normalized survey weights
WeightedIndsGender  = WeightIndInit(IndPrevsGender , WeightsBalanced, DimPrevGroupsGender , NSize); % Normalized survey weights
WeightedIndsAge     = WeightIndInit(IndPrevsAge    , WeightsBalanced, DimPrevGroupsAge    , NSize); % Normalized survey weights
WeightedIndsRace    = WeightIndInit(IndPrevsRace   , WeightsBalanced, DimPrevGroupsRace   , NSize); % Normalized survey weights
WeightedIndsForborn = WeightIndInit(IndPrevsForborn, WeightsBalanced, DimPrevGroupsForborn, NSize); % Normalized survey weights
WeightedIndsEduc    = WeightIndInit(IndPrevsEduc   , WeightsBalanced, DimPrevGroupsEduc   , NSize); % Normalized survey weights
WeightedIndsHssc    = WeightIndInit(IndPrevsHssc   , WeightsBalanced, DimPrevGroupsHssc   , NSize); % Normalized survey weights


% Matrix, vector and scalar sizes
DimXCog   = size(XCogBalanced,2); % Number of variables in the cognition equation
DimXCogDem = size(XCogDemBalanced,2);
DimXCogAge = size(XCogAgeBalanced,2);
DimXVarsProxy = size(XVarsBalanced,2) + 1;
DimXVarsSelf  = size(XVarsBalanced,2) + 2;
DimXVarsSelf2 = size(XVarsBalanced,2) + 3;
DimXVarsMisProxy = size(XVarsMisBalanced,2) + 9;
DimXVarsMisSelf  = size(XVarsMisBalanced,2) + 10;
DimXVarsMisSelf2 = size(XVarsMisBalanced,2) + 12;
DimXVarsMisSelf4 = size(XVarsMisBalanced,2) + 11;
DimXProxyDem = size(XProxyBalanced,2)-3;
DimXProxyAge = 3;
DimXProxy = DimXProxyDem + DimXProxyAge + 9;

DimXRace    = max(XRaceBalanced);    % Number of race categories minus 1
DimXEduc    = max(XEducBalanced);    % Number of education categories minus 1
DimXHssc    = max(XHsscBalanced);    % Number of Social Security income categories minus 1

DimXIAdamsProxyW5Vars = size(XAdamsProxyBalancedW5,2);
DimXIAdamsProxyW6Vars = size(XAdamsProxyBalancedW6,2);
DimXIAdamsSelfW5Vars  = size(XAdamsSelfBalancedW5,2);
DimXIAdamsSelfW6Vars  = size(XAdamsSelfBalancedW6,2);

DimXAdamsTimeVars = size(XAdamsTimeWA,2) + 2;
DimXSurv = size(XHRSSurv,2) + 2;
DimXAdamsRespDemVars = size(XAdamsRespDemWA,2);
DimXAdamsRespAgeVars = size(XAdamsRespAgeWA,2);
DimXAdamsRespVars    = DimXAdamsRespDemVars + DimXAdamsRespAgeVars + 1;

NTotHRS       = sum(IHRSAllBalanced>0.5);
NTotProxyCore = sum(IProxyCoreBalanced);
NTotSelfCore  = sum(ISelfCoreBalanced);
NTotHRSCore   = NTotSelfCore + NTotProxyCore; 

NMisAll    = sum(MisYAllBalanced);
NMisSelf1  = sum(MisYSelf1Balanced);
NMisSelf2  = sum(MisYSelf2Balanced);
NMisSelf3  = sum(MisYSelf3Balanced);
NMisSelf4  = sum(MisYSelf4Balanced);
NMisProxy2 = sum(MisYProxy2Balanced);

NTotDemented = sum(DementedBalanced);
NTotCind     = sum(CindBalanced);
NTotNormalc  = sum(NormalcBalanced);

NAdamsWA = sum(IAdamsSelectedBalancedWA);
NAdamsWB = sum(IAdamsSelectedBalancedWB);
NAdamsWC = sum(IAdamsSelectedBalancedWC);
NAdamsWD = sum(IAdamsSelectedBalancedWD);

NAdamsRespondentTot = sum(IAdamsRespondentBalanced);

NIHRSCoreAdamsNonRespWide = sum(IHRSCoreAdamsNonRespWide);
NIHRSCoreAdamsNonRespTot  = sum(NIHRSCoreAdamsNonRespWide);

NProxyW5 = sum(IProxyAllBalancedW5);
NProxyW6 = sum(IProxyAllBalancedW6);
NSelfW5  = sum(ISelfAllBalancedW5);
NSelfW6  = sum(ISelfAllBalancedW6);

NAdamsNonRespondentWA = sum(IAdamsNonRespondentBalancedWA);
NAdamsNonRespondentWB = sum(IAdamsNonRespondentBalancedWB);
NAdamsNonRespondentWC = sum(IAdamsNonRespondentBalancedWC);
NAdamsNonRespondentWD = sum(IAdamsNonRespondentBalancedWD);

NMisXRace    = sum(MisXRace);     % # missing Race 
NMisXEduc    = sum(MisXEduc);     % # missing Education
NMisXForborn = sum(MisXForborn) ; % # missing Foreign born
NMisXHssc    = sum(MisXHssc);     % # missing Household social


% Allocate space to save the MCMC simulation draws
BetaCogSim    = zeros(TotalDraws,DimXCog);    % Coefficients in cognition
SdCogUSim     = ones(TotalDraws,2);           % Sd of cognition random effects
CorrCogUSim   = ones(TotalDraws,1)*0.1;       % Correlation between cognition random effects
ThetaCogMSim  = ones(TotalDraws,1);           % Precision of random walk innovation in cognition

BetaProxySim = zeros(TotalDraws,DimXProxy);    % Coefficients in proxy selection

BetaYAllSim     = ones(TotalDraws,DimXVarsProxy,1)*0.01; % Coefficients in linear cognition scores available in all interviews
ThetaYAllSim    = ones(TotalDraws,1);                    % Precision in all interviews
BetaYSelf1Sim   = ones(TotalDraws,DimXVarsSelf,1)*0.01;  % Coefficients in linear non-proxy interviews #1
ThetaYSelf1Sim  = ones(TotalDraws,1);                    % Precision in non-proxy interviews #1
BetaYSelf2Sim   = ones(TotalDraws,DimXVarsSelf2,1)*0.01; % Coefficients in linear non-proxy interviews #2
ThetaYSelf2Sim  = ones(TotalDraws,1);                    % Precision in non-proxy interviews #2
BetaYSelf3Sim   = ones(TotalDraws,DimXVarsSelf,1)*0.01;  % Coefficients in linear non-proxy interviews #3
ThetaYSelf3Sim  = ones(TotalDraws,1);                    % Precision in non-proxy interviews #3
BetaYSelf4Sim   = ones(TotalDraws,DimXVarsSelf,1)*0.01;  % Coefficients in linear non-proxy interviews #4
ThetaYSelf4Sim  = ones(TotalDraws,1);                    % Precision in non-proxy interviews #4
BetaYProxy1Sim  = ones(TotalDraws,DimXVarsProxy,1)*0.01; % Coefficients in linear proxy interviews #1
ThetaYProxy1Sim = ones(TotalDraws,1);                    % Precision in proxy interviews #1
BetaYProxy2Sim  = ones(TotalDraws,DimXVarsProxy,1)*0.01; % Coefficients in linear proxy interviews #1
ThetaYProxy2Sim = ones(TotalDraws,1);                    % Precision in proxy interviews #1


BetaYAllMisSim    = ones(TotalDraws,DimXVarsMisProxy,1)*0.01;  % Coefficients in missing flags for linear cognition scores available in all interviews
BetaYSelf1MisSim  = ones(TotalDraws,DimXVarsMisSelf,1)*0.01;   % Coefficients in missing flags for linear non-proxy interviews #1
BetaYSelf2MisSim  = ones(TotalDraws,DimXVarsMisSelf2,1)*0.01;  % Coefficients in missing flags for linear non-proxy interviews #2
BetaYSelf3MisSim  = ones(TotalDraws,DimXVarsMisSelf,1)*0.01;   % Coefficients in missing flags for linear non-proxy interviews #3
BetaYSelf4MisSim  = ones(TotalDraws,DimXVarsMisSelf4,1)*0.01;  % Coefficients in missing flags for linear non-proxy interviews #4
BetaYProxy2MisSim = ones(TotalDraws,DimXVarsMisProxy,1)*0.01;  % Coefficients in missing flags for linear proxy interviews #2

BetaIAdamsProxyW5Sim = zeros(TotalDraws,DimXIAdamsProxyW5Vars,1); % Adams selection: W5 proxies
BetaIAdamsProxyW6Sim = zeros(TotalDraws,DimXIAdamsProxyW6Vars,1); % Adams selection: W6 proxies
BetaIAdamsSelfW5Sim  = zeros(TotalDraws,DimXIAdamsSelfW5Vars,1);  % Adams selection: W5 proxies
BetaIAdamsSelfW6Sim  = zeros(TotalDraws,DimXIAdamsSelfW6Vars,1);  % Adams selection: W6 proxies

BetaAdamsTimeWASim  = zeros(TotalDraws,DimXAdamsTimeVars,1); % Adams WA interview timing coefs
ThetaAdamsTimeWASim = ones(TotalDraws,1);                    % Adams WA interview timing precision
BetaAdamsTimeWBSim  = zeros(TotalDraws,DimXAdamsTimeVars,1); % Adams WB interview timing coefs
ThetaAdamsTimeWBSim = ones(TotalDraws,1);                    % Adams WB interview timing precision
BetaAdamsTimeWCSim  = zeros(TotalDraws,DimXAdamsTimeVars,1); % Adams WC interview timing coefs
ThetaAdamsTimeWCSim = ones(TotalDraws,1);                    % Adams WC interview timing precision
BetaAdamsTimeWDSim  = zeros(TotalDraws,DimXAdamsTimeVars,1); % Adams WD interview timing coefs
ThetaAdamsTimeWDSim = ones(TotalDraws,1);                    % Adams WD interview timing precision

GammaScaleSim    = ones(TotalDraws,1)*0.1;     % The scale parameter of survival
LnGammaShapeSim  = zeros(TotalDraws,DimXSurv); % Coefficients in the shape parameter of survival

BetaAdamsRespWASim  = zeros(TotalDraws,DimXAdamsRespVars,1); % Adams WA respondent coefs
BetaAdamsRespWBSim  = zeros(TotalDraws,DimXAdamsRespVars,1); % Adams WB respondent coefs
BetaAdamsRespWCSim  = zeros(TotalDraws,DimXAdamsRespVars,1); % Adams WC respondent coefs
BetaAdamsRespWDSim  = zeros(TotalDraws,DimXAdamsRespVars,1); % Adams WD respondent coefs

PRaceSim = ones(TotalDraws,DimXRace)/(DimXRace+1); % Racial distribution
PEducSim = ones(TotalDraws,DimXEduc)/(DimXEduc+1); % Education distribution
PForbornSim = ones(TotalDraws,1)*0.5;              % Fraction foreign born
PHsscSim = ones(TotalDraws,DimXHssc)/(DimXHssc+1); % SS income distribution
PSingleSim = ones(TotalDraws,3,1)*0.5;             % 1. Fraction single in period 1; 2. rate of change (n = lamda01 + lamda10); 3. ratio of married-> single change (lamda01/(lamda01 + lamda10)))
PStrokeSim = ones(TotalDraws,3,1)*0.5;             % 1. Fraction had stroke in period 1; 2. rate of change (n = lamda01 + lamda10); 3. ratio of no stroke->stroke change (lamda01/(lamda01 + lamda10)))

PrevGroupsCompare = zeros(UsedThinDraws,DimPrevGroupsCompare);
PrevGroupsGender  = zeros(UsedThinDraws,DimPrevGroupsGender);
PrevGroupsAge     = zeros(UsedThinDraws,DimPrevGroupsAge);
PrevGroupsRace    = zeros(UsedThinDraws,DimPrevGroupsRace);
PrevGroupsForborn = zeros(UsedThinDraws,DimPrevGroupsForborn);
PrevGroupsEduc    = zeros(UsedThinDraws,DimPrevGroupsEduc);
PrevGroupsHssc    = zeros(UsedThinDraws,DimPrevGroupsHssc);

CogStore = zeros(NTotHRS,UsedIndDraws);

% Diffuse prior values for the mean and variance terms
Tau0 = 0.001;
A0  = 0.001;  B0 = 0.001;
T02 = eye(2)*Tau0;

% Initial values of cognition. (Trying to fill-in reasonable values)
fprintf('*** Finding good initial values...');
CogSimBalanced = ones(NSize,1);
CogSimBalanced(DementedBalanced) = -1;
CogSimBalanced(CindBalanced)     = 0.5;
CogSimBalanced(NormalcBalanced)  = 2;

AgeCentBalanced  = AgeBalanced - CenterAge;
AgeCentBalanced2 = AgeCentBalanced.^2;
AgeCentBalanced3 = AgeCentBalanced.^3;

AgeWide  = reshape(AgeBalanced,NSizet,NSizex)'; 

CC = CogSimBalanced(IAdamsRespondentBalanced);
YAW = YCogAllWide;
for j=2:NSizet
    YAW(YAW(:,j)==-100,j) = YAW(YAW(:,j)==-100,j-1);
end
YAB = reshape(YAW',NSize,1);
YYT = [ones(NSize,1), YAB];
YY = YYT(IAdamsRespondentBalanced,:);
b = regress(CC,YY);
CogSimBalanced = YYT*b + randn(NSize,1)*0.2;
CogSimBalanced(DementedBalanced) = -1;
CogSimBalanced(CindBalanced)     = 0.5;
CogSimBalanced(NormalcBalanced)  = 2;

CogSimWide = reshape(CogSimBalanced,NSizet,NSizex)';

% Initial values of the random effects terms using a built-in MATLAB mixed effect model
IDWide = ones(NSizex,NSizet);
for j=2:NSizex
   IDWide(j,:) = IDWide(j-1,:) + 1;
end
IDBalanced = reshape(IDWide',NSize,1);

IndWide0 = zeros(NSizex,2)>0.5; IndWide1 = zeros(NSizex,2)>0.5;
IndWide0(:,1) = 1; IndWide1(:,2) = 1;
IndLong0 = reshape(IndWide0', NSizex*2,1); IndLong1 = reshape(IndWide1', NSizex*2,1);

model = mat2dataset([IDBalanced(IHRSAllBalanced), CogSimBalanced(IHRSAllBalanced), XFemaleBalanced(IHRSAllBalanced), XRaceBalanced(IHRSAllBalanced), XEducBalanced(IHRSAllBalanced), ...
    XForbornBalanced(IHRSAllBalanced), XHsscBalanced(IHRSAllBalanced), AgeCentBalanced(IHRSAllBalanced), AgeCentBalanced2(IHRSAllBalanced), AgeCentBalanced3(IHRSAllBalanced), XBirthYearBalanced(IHRSAllBalanced)]);
model.Properties.VarNames = {'Id', 'C','Female','Race', 'Edu', 'For', 'Hssc', 'Age', 'Age2', 'Age3', 'By'};
model.Female = categorical(model.Female);
model.Race = categorical(model.Race);
model.Edu = categorical(model.Edu);
model.For = categorical(model.For);
model.Hssc = categorical(model.Hssc);
lme = fitlme(model,'C ~ 1 + Female + Race + Edu + For + Hssc + Age + Age2 + Age3 + By + Female*By + Race*By + Edu*By + For*By + Hssc*By + Age*By + Age2*By + Age3*By + (1 + Age|Id)');
[~,~,stats] = randomEffects(lme);
UBs = stats.Estimate;
U0Sim = UBs(IndLong0);
U1Sim = UBs(IndLong1);

U0WideSim      = U0Sim*ones(1,NSizet);
U0WideSim(~IHRSAllWide) = 0;
U0BalancedSim  = reshape(U0WideSim',NSize,1);
U1WideSim      = U1Sim*ones(1,NSizet);
U1WideSim(~IHRSAllWide) = 0;
U1BalancedSim  = reshape(U1WideSim',NSize,1);

T0xCog = eye(DimXCog)*0.001;
[X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore] = X1VarsLoad(XVarsBalanced, XVarsMisBalanced, CogSimBalanced, FirstSelfBalanced, IProxyCoreBalanced, ISelfCoreBalanced, IHRSCoreBalanced, XProxyBalanced, WaveDummies);
XHRSSurv1 = [XHRSSurv, U0Sim, U1Sim];

Age1Alive = AgeWide(DeadX<0.5,1);
DeathAgeAlive_min = DeathAgeX_min(DeadX<0.5);
DeathAgeAlive_max = DeathAgeX_min(DeadX<0.5);
    
% Other variables for proxy selection
XBProxyCore     = X1ProxyCore*BetaProxySim(1,:)';
YProxySimCore = MyProbitDraw(XBProxyCore,IProxyCore);
YProxySimBalanced = zeros(NSize,1);
YProxySimBalanced(IHRSCoreBalanced) = YProxySimCore;


% Variables for the HRS cognition score regressions
T0xProxy = eye(DimXVarsProxy)*0.001;
T0xSelf  = eye(DimXVarsSelf)*0.001;
T0xSelf2 = eye(DimXVarsSelf2)*0.001;

T0xMisProxy = eye(DimXVarsMisProxy)*0.001;
T0xMisSelf  = eye(DimXVarsMisSelf)*0.001;
T0xMisSelf2 = eye(DimXVarsMisSelf2)*0.001;
T0xMisSelf4 = eye(DimXVarsMisSelf4)*0.001;


% Other variables for ADAMS selection
XBIAdamsProxyW5 = zeros(NProxyW5,1);
XBIAdamsProxyW6 = zeros(NProxyW6,1);
XBIAdamsSelfW5  = zeros(NSelfW5,1);
XBIAdamsSelfW6  = zeros(NSelfW6,1);

XXIAdamsProxyW5     = XAdamsProxyBalancedW5'*XAdamsProxyBalancedW5 + eye(DimXIAdamsProxyW5Vars)*Tau0;
cholXXIAdamsProxyW5 = chol(inv(XXIAdamsProxyW5));
XXIAdamsProxyW6     = XAdamsProxyBalancedW6'*XAdamsProxyBalancedW6 + eye(DimXIAdamsProxyW6Vars)*Tau0;
cholXXIAdamsProxyW6 = chol(inv(XXIAdamsProxyW6));
XXIAdamsSelfW5      = XAdamsSelfBalancedW5'*XAdamsSelfBalancedW5 + eye(DimXIAdamsSelfW5Vars)*Tau0;
cholXXIAdamsSelfW5  = chol(inv(XXIAdamsSelfW5));
XXIAdamsSelfW6      = XAdamsSelfBalancedW6'*XAdamsSelfBalancedW6 + eye(DimXIAdamsSelfW6Vars)*Tau0;
cholXXIAdamsSelfW6  = chol(inv(XXIAdamsSelfW6));

% Other variables for ADAMS interview timing
XBAdamsTimeBalanced   = zeros(NSize,1);
XBAdamsTimeBalancedWA = zeros(NSize,1);
XBAdamsTimeBalancedWB = zeros(NSize,1);
XBAdamsTimeBalancedWC = zeros(NSize,1);
XBAdamsTimeBalancedWD = zeros(NSize,1);
IWTimeBalanced = zeros(NSize,1);
IWTimeBalanced(IAdamsSelectedBalancedWA) = IWTimeWA(IAdamsSelectedBalancedWA);
IWTimeBalanced(IAdamsSelectedBalancedWB) = IWTimeWB(IAdamsSelectedBalancedWB);
IWTimeBalanced(IAdamsSelectedBalancedWC) = IWTimeWC(IAdamsSelectedBalancedWC);
IWTimeBalanced(IAdamsSelectedBalancedWD) = IWTimeWD(IAdamsSelectedBalancedWD);
PropSdIWWA  = ones(1,1);
PropSdIWWB  = ones(1,1);
PropSdIWWC  = ones(1,1);
PropSdIWWD  = ones(1,1);
MeanAcceptIW = zeros(TotalDraws-1,4);

aux1 = ones(NSize,1)*(-100);
aux1(IAdamsSelectedBalancedWA,:) = CogSimBalanced(IAdamsSelectedBalancedWA,:);
aux2 = reshape(aux1,NSizet,NSizex);
aux3 = max(aux2)';
CogWAWide = aux3*ones(1,NSizet);
CogWABalanced = reshape(CogWAWide',NSize,1);

XAdamsTimeWA1 = [XAdamsTimeWA, CogSimBalanced(IAdamsSelectedShiftedWA,:), CogSimBalanced(IAdamsSelectedShiftedWA).*W6WABalanced(IAdamsSelectedBalancedWA)];
XAdamsTimeWB1 = [XAdamsTimeWB, CogWABalanced(IAdamsSelectedBalancedWB,:), CogWABalanced(IAdamsSelectedBalancedWB).*W6WABalanced(IAdamsSelectedBalancedWB)];
XAdamsTimeWC1 = [XAdamsTimeWC, CogWABalanced(IAdamsSelectedBalancedWC,:), CogWABalanced(IAdamsSelectedBalancedWC).*W6WABalanced(IAdamsSelectedBalancedWC)];
XAdamsTimeWD1 = [XAdamsTimeWD, CogWABalanced(IAdamsSelectedBalancedWD,:), CogWABalanced(IAdamsSelectedBalancedWD).*W6WABalanced(IAdamsSelectedBalancedWD)];
IWTimeBalancedCand = zeros(NSize,1);

% Other variables for survival
AcceptGammaShape = zeros(TotalDraws,DimXSurv);
PropGammaShape   = ones(DimXSurv,1);
AcceptGammaScale = zeros(TotalDraws,1);
PropGammaScale   = ones(1,1);
NHRSAlive = sum(DeadX<0.5);

PropCogU       = [1; 1];
MeanAcceptCogU = zeros(TotalDraws-1,2);

% Other variables for ADAMS response
YAdamsRespBalanced = zeros(NSize,1);
XBAdamsRespBalanced = zeros(NSize,1);

XAdamsRespWA = [XAdamsRespDemWA, XAdamsRespAgeWA];
XAdamsRespWB = [XAdamsRespDemWB, XAdamsRespAgeWB];
XAdamsRespWC = [XAdamsRespDemWC, XAdamsRespAgeWC];
XAdamsRespWD = [XAdamsRespDemWD, XAdamsRespAgeWD];

XAdamsRespWA1 = [XAdamsRespWA, CogSimBalanced(IAdamsSurvivedBalancedWA)];
XAdamsRespWB1 = [XAdamsRespWB, CogSimBalanced(IAdamsSurvivedBalancedWB)];
XAdamsRespWC1 = [XAdamsRespWC, CogSimBalanced(IAdamsSurvivedBalancedWC)];
XAdamsRespWD1 = [XAdamsRespWD, CogSimBalanced(IAdamsSurvivedBalancedWD)];

XBAdamsRespWA = XAdamsRespWA1*BetaAdamsRespWASim(1,:)';
XBAdamsRespWB = XAdamsRespWB1*BetaAdamsRespWBSim(1,:)';
XBAdamsRespWC = XAdamsRespWC1*BetaAdamsRespWCSim(1,:)';
XBAdamsRespWD = XAdamsRespWD1*BetaAdamsRespWDSim(1,:)';

YAdamsRespWA = MyProbitDraw(XBAdamsRespWA,IAdamsRespondentSurvWA);
YAdamsRespWB = MyProbitDraw(XBAdamsRespWB,IAdamsRespondentSurvWB);
YAdamsRespWC = MyProbitDraw(XBAdamsRespWC,IAdamsRespondentSurvWC);
YAdamsRespWD = MyProbitDraw(XBAdamsRespWD,IAdamsRespondentSurvWD);

YAdamsRespBalanced(IAdamsSurvivedBalancedWA) = YAdamsRespWA;
YAdamsRespBalanced(IAdamsSurvivedBalancedWB) = YAdamsRespWB;
YAdamsRespBalanced(IAdamsSurvivedBalancedWC) = YAdamsRespWC;
YAdamsRespBalanced(IAdamsSurvivedBalancedWD) = YAdamsRespWD;


% Other variables for the HRS cognitive scores
YCogAllMisBalanced = zeros(NSize,1);
YCogSelf1MisBalanced = zeros(NSize,1);
YCogSelf2MisBalanced = zeros(NSize,1);
YCogSelf3MisBalanced = zeros(NSize,1);
YCogSelf4MisBalanced = zeros(NSize,1);
YCogProxy2MisBalanced = zeros(NSize,1);
XBCogProxy1Core = X1VarsProxyCore*BetaYProxy1Sim(1,:)';


% Death grid and related variable for estimating cognition before death
CogDeathGrids = zeros(NumDeads,6);
FemaleDead    = XFemale(DeathObservedX);
RaceDead      = XRace(DeathObservedX);
EducDead      = XEduc(DeathObservedX);
ForbornDead   = XForborn(DeathObservedX);
HsscDead      = XHssc(DeathObservedX);
BirthYearDead = XBirthYear(DeathObservedX);

CogDeadStore = zeros(NumDeads,6, UsedIndDraws);


% Identifying the last HRS waves before death
IMaxWaveWide = zeros(NSizex,NSizet)>0.5;
for j=1:NSizet-1
    IMaxWaveWide(IHRSCoreWide(:,j) & max(IHRSCoreWide(:,j+1:end),[],2)==0, j) = 1;
end
IMaxWaveWide(IHRSCoreWide(:,NSizet),NSizet) = 1;
IMaxBalanced = reshape(IMaxWaveWide',NSize,1);
DeathObservedWide = DeathObservedX*ones(1,NSizet);
DeathObservedBalanced = reshape(DeathObservedWide',NSize,1);

IndPrevsDead = [ones(NumDeads,1)>0.5, FemaleDead==0, FemaleDead==1, RaceDead==0, RaceDead==1, RaceDead==2, RaceDead==3, EducDead==0, EducDead==1, EducDead==2, EducDead==3, ForbornDead==0, ForbornDead==1, HsscDead==0, HsscDead==1, HsscDead==2, HsscDead==3];
DimPrevGroupsDead = size(IndPrevsDead,2);
WeightsWide = reshape(WeightsBalanced,NSizet,NSizex)';
LastWeight = zeros(NSizex,1);
for j=1:NSizet
    LastWeight(IHRSCoreWide(:,j)) = WeightsWide(IHRSCoreWide(:,j),j);
end
LastWeightDead = LastWeight(DeathObservedX,1);
WeightedIndsDead = WeightIndInit(IndPrevsDead, LastWeightDead, DimPrevGroupsDead, NumDeads); % Normalized survey weights
PrevGroupsDead = zeros(UsedThinDraws,DimPrevGroupsDead*6);

% Other variables
WaveDummiesCore  = WaveDummies(IHRSCoreBalanced,:);
WaveDummiesProxy = WaveDummies(IProxyCoreBalanced,:);
WaveDummiesSelf  = WaveDummies(ISelfCoreBalanced,:);

PropPSingleSim   = ones(1,2);
AcceptPSingleSim = zeros(TotalDraws-1,2);
PropPStrokeSim   = ones(1,2);
AcceptPStrokeSim = zeros(TotalDraws-1,2);
TotPostX  = B0 + NSizex;


% Initializing the main results: dementia probabilities and other cognitive
% measures
ExpCog    = zeros(NTotHRS,1);
ExpCog2   = zeros(NTotHRS,1);
PrDement  = zeros(NTotHRS,1);
PrCind    = zeros(NTotHRS,1);
PrNormal  = zeros(NTotHRS,1);
ExpCog0   = zeros(NTotHRS,1);
ExpCog02  = zeros(NTotHRS,1);
ExpCogR   = zeros(NTotHRS,1);
ExpCogR2  = zeros(NTotHRS,1);
ExpCogU0  = zeros(NTotHRS,1);
ExpCogU02 = zeros(NTotHRS,1);
ExpCogU1  = zeros(NTotHRS,1);
ExpCogU12 = zeros(NTotHRS,1);
ExpDeath  = zeros(NSizex,1);
ExpDeath2 = zeros(NSizex,1);
ExpShape  = zeros(NSizex,1);
ExpShape2 = zeros(NSizex,1);
ExpCogDead   = zeros(NumDeads,6);
ExpCogDead2  = zeros(NumDeads,6);
PrDementDead = zeros(NumDeads,6);

% Finding good initial values of some coefficients to improve the initial
% imputations. Typically using non-missing observations
X1VarsSelf2Balanced = [XVarsBalanced, FirstSelfBalanced, YCogSelf1Balanced, CogSimBalanced];

[BetaYAllSim(1,:), ~, ~, ~, stats] = regress(YCogAllBalanced(IHRSCoreBalanced & MisYAllBalanced<0.5), X1VarsProxyBalanced(IHRSCoreBalanced&MisYAllBalanced<0.5,:));
ThetaYAllSim(1,1) = 1/stats(4);
[BetaYSelf1Sim(1,:), ~, ~, ~, stats] = regress(YCogSelf1Balanced(ISelfCoreBalanced & MisYSelf1Balanced<0.5), X1VarsSelfBalanced(ISelfCoreBalanced&MisYSelf1Balanced<0.5,:));
ThetaYSelf1Sim(1,1) = 1/stats(4);
[BetaYSelf2Sim(1,:), ~, ~, ~, stats] = regress(YCogSelf2Balanced(ISelfCoreBalanced & MisYSelf2Balanced<0.5), X1VarsSelf2Balanced(ISelfCoreBalanced&MisYSelf2Balanced<0.5,:));
ThetaYSelf2Sim(1,1) = 1/stats(4);
[BetaYSelf3Sim(1,:), ~, ~, ~, stats] = regress(YCogSelf3Balanced(ISelfCoreBalanced & MisYSelf3Balanced<0.5), X1VarsSelfBalanced(ISelfCoreBalanced&MisYSelf3Balanced<0.5,:));
ThetaYSelf3Sim(1,1) = 1/stats(4);
[BetaYSelf4Sim(1,:), ~, ~, ~, stats] = regress(YCogSelf4Balanced(ISelfCoreBalanced & MisYSelf4Balanced<0.5), X1VarsSelfBalanced(ISelfCoreBalanced&MisYSelf4Balanced<0.5,:));
ThetaYSelf4Sim(1,1) = 1/stats(4);
[BetaYProxy2Sim(1,:), ~, ~, ~, stats] = regress(YCogProxy2Balanced(IProxyCoreBalanced & MisYProxy2Balanced<0.5), X1VarsProxyBalanced(IProxyCoreBalanced&MisYProxy2Balanced<0.5,:));
ThetaYProxy2Sim(1,1) = 1/stats(4);

[BetaAdamsTimeWASim(1,:), ~, ~, ~, stats] = regress(IWTimeBalanced(IAdamsRespondentBalancedWA), XAdamsTimeWA1(IAdamsRespondentBalancedWA(IAdamsSelectedBalancedWA),:));
ThetaAdamsTimeWASim(1,1) = 1/stats(4);
[BetaAdamsTimeWBSim(1,:), ~, ~, ~, stats] = regress(IWTimeBalanced(IAdamsRespondentBalancedWB), XAdamsTimeWB1(IAdamsRespondentBalancedWB(IAdamsSelectedBalancedWB),:));
ThetaAdamsTimeWBSim(1,1) = 1/stats(4);
[BetaAdamsTimeWCSim(1,:), ~, ~, ~, stats] = regress(IWTimeBalanced(IAdamsRespondentBalancedWC), XAdamsTimeWC1(IAdamsRespondentBalancedWC(IAdamsSelectedBalancedWC),:));
ThetaAdamsTimeWCSim(1,1) = 1/stats(4);
[BetaAdamsTimeWDSim(1,:), ~, ~, ~, stats] = regress(IWTimeBalanced(IAdamsRespondentBalancedWD), XAdamsTimeWD1(IAdamsRespondentBalancedWD(IAdamsSelectedBalancedWD),:));
ThetaAdamsTimeWDSim(1,1) = 1/stats(4);

options = optimset('MaxFunEvals', 10000, 'MaxIter', 10000, 'Display', 'off');
[phat, ~, e] = fminsearch(@(betas)SurvivalNLike(betas, DeathAgeX, XHRSSurv1, AgeWide(:,1), DeathAgeX_min, DeathAgeX_max, DeadX),[GammaScaleSim(1), LnGammaShapeSim(1,:)], options);
GammaScaleSim(1)     = phat(1);
LnGammaShapeSim(1,:) = phat(2:DimXSurv+1);
LnGammaShape = XHRSSurv1*LnGammaShapeSim(1,:)';
GammaShape   = exp(LnGammaShape);
fprintf(' done ***\n');
if e==0
    fprintf('   !!!The initial survival model did not converge!!!\n');
end

VarU  = cov([U0Sim, U1Sim]);
SdCogUSim(1,1) = sqrt(VarU(1,1));
SdCogUSim(1,2) = sqrt(VarU(2,2));
CorrCogUSim(1,1) = VarU(1,2)/SdCogUSim(1,1)/SdCogUSim(1,2);

DetVarU     = det(VarU);
InvVarU     = inv(VarU);
CholInvVarU = chol(InvVarU);
CholVarU    = chol(VarU);

PropScaleVarU = 1000;
AcceptVarU = zeros(TotalDraws,1);

NQSim = 7;
[QuadPoints,QuadWeights] = GaussHermite(NQSim);
QuadPoints = QuadPoints*sqrt(2);
QuadWeights = QuadWeights/sqrt(pi);
[m,n] = ndgrid(QuadPoints,QuadPoints);
NormSim = [m(:),n(:)];
[m,n] = ndgrid(QuadWeights,QuadWeights);
QuadWeightsS = prod([m(:),n(:)],2);
QuadWeightsSX = QuadWeightsS*ones(1,NSizex);

FNormSim = NormSim*CholVarU;
   
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Running the Gibbs sampler %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('*** The Gibbs sampler started ***\n');
tic;
for i=2:TotalDraws
    %%% Step 1: Running the regression of HRS cognition measures 
    %%% linear cognition scores available in all interviews
    % The cholesky decompositions
    XXVarsAll = X1VarsAllCore'*X1VarsAllCore  + T0xProxy;
    cholXXVarsAll = chol(inv(XXVarsAll));
    
    % Drawing missing values
    XBCogAllBalanced = X1VarsProxyBalanced*BetaYAllSim(i-1,:)';
    YCogAllBalanced(MisYAllBalanced) = XBCogAllBalanced(MisYAllBalanced) + randn(NMisAll,1)/sqrt(ThetaYAllSim(i-1,1));
    YCogAllCore = YCogAllBalanced(IHRSCoreBalanced,:);
    YCogAllWide = reshape(YCogAllBalanced, NSizet,NSizex)';
    
    %Running the regression
    BetaYAllSim(i,:) = MyBayesOLS(X1VarsAllCore,YCogAllCore, ThetaYAllSim(i-1,1),XXVarsAll,cholXXVarsAll);
    XBCogAllBalanced = X1VarsProxyBalanced*BetaYAllSim(i,:)';
    
    
    %%% linear self-interviews 1
    % The cholesky decompositions
    XXVarsSelf = X1VarsSelfCore'*X1VarsSelfCore  + T0xSelf;
    cholXXVarsSelf = chol(inv(XXVarsSelf));
    
    % Drawing missing values: The values are predictors of Y2Self and Y2Self missing
    XBCogSelf1Balanced = X1VarsSelfBalanced*BetaYSelf1Sim(i-1,:)';
    X1VarsSelf2Balanced = [XVarsBalanced, FirstSelfBalanced, YCogSelf1Balanced, CogSimBalanced];
    XBCogSelf2Balanced = X1VarsSelf2Balanced*BetaYSelf2Sim(i-1,:)';
    X1VarsMisSelf2Balanced = [XVarsMisBalanced, FirstSelfBalanced, YCogSelf1Balanced, MisYSelf1Balanced, CogSimBalanced, WaveDummies.*(CogSimBalanced*ones(1,8))];
    XBCogSelf2MisBalanced  = X1VarsMisSelf2Balanced*BetaYSelf2MisSim(i-1,:)';
    
    T_Prior  = ThetaYSelf1Sim(i-1,1);
    T_Data1  = ThetaYSelf2Sim(i-1)*(BetaYSelf2Sim(i-1,DimXVarsSelf2-1)^2);
    T_Data2  = (BetaYSelf2MisSim(i-1,DimXVarsMisSelf2-2)^2);
    Mu_Prior = XBCogSelf1Balanced(MisYSelf1Balanced);
    Mu_Data1 = (YCogSelf2Balanced(MisYSelf1Balanced)    - XBCogSelf2Balanced(MisYSelf1Balanced))/BetaYSelf2Sim(i-1,DimXVarsSelf2-1)          + YCogSelf1Balanced(MisYSelf1Balanced);
    Mu_Data2 = (YCogSelf2MisBalanced(MisYSelf1Balanced) - XBCogSelf2MisBalanced(MisYSelf1Balanced))/BetaYSelf2MisSim(i-1,DimXVarsMisSelf2-2) + YCogSelf1Balanced(MisYSelf1Balanced);
    
    TT = T_Prior + T_Data1 + T_Data2;
    MC = (T_Prior*Mu_Prior + T_Data1*Mu_Data1 + T_Data2*Mu_Data2)/TT;
    
    YCogSelf1Balanced(MisYSelf1Balanced) = MC + randn(NMisSelf1,1)/sqrt(TT);
    YCogSelf1Core = YCogSelf1Balanced(ISelfCoreBalanced,:);
    YCogSelf1Wide = reshape(YCogSelf1Balanced, NSizet,NSizex)';
    
    % Running the regression
    BetaYSelf1Sim(i,:) = MyBayesOLS(X1VarsSelfCore,YCogSelf1Core, ThetaYSelf1Sim(i-1,1),XXVarsSelf,cholXXVarsSelf);
    XBCogSelf1Balanced = X1VarsSelfBalanced*BetaYSelf1Sim(i,:)';
    
    
    %%% linear self-interviews 2 (Note: it has an extra covariate: y1)
    % Updating the predictor variable 
    X1VarsSelf2Balanced = [XVarsBalanced, FirstSelfBalanced, YCogSelf1Balanced, CogSimBalanced];
    X1VarsSelf2Core  = X1VarsSelf2Balanced(ISelfCoreBalanced,:);
    
    % The cholesky decompositions
    XXVarsSelf2 = X1VarsSelf2Core'*X1VarsSelf2Core  + T0xSelf2;
    cholXXVarsSelf2 = chol(inv(XXVarsSelf2));
    
    % Drawing the missing and censored values
    XBCogSelf2Balanced = X1VarsSelf2Balanced*BetaYSelf2Sim(i-1,:)';
    YCogSelf2Balanced(MisYSelf2Balanced) = XBCogSelf2Balanced(MisYSelf2Balanced) + randn(NMisSelf2,1)/sqrt(ThetaYSelf2Sim(i-1,1));
    YCogSelf2Balanced(ICogSelf2LowBalanced) = MyTobitDraw(XBCogSelf2Balanced,ThetaYSelf2Sim(i-1,1),ICogSelf2LowBalanced,YSelf2LowValue,zeros(NSize,1),0); % drawing new values for the censored cases
    YCogSelf2Core = YCogSelf2Balanced(ISelfCoreBalanced);
    YCogSelf2Wide = reshape(YCogSelf2Balanced, NSizet,NSizex)';
    
    % Running the regression
    BetaYSelf2Sim(i,:) = MyBayesOLS(X1VarsSelf2Core,YCogSelf2Core, ThetaYSelf2Sim(i-1,1),XXVarsSelf2,cholXXVarsSelf2);
    XBCogSelf2Balanced = X1VarsSelf2Balanced*BetaYSelf2Sim(i,:)';
    
    
    %%% linear self-interviews 3
    % Drawing the missing and censored values
    XBCogSelf3Balanced = X1VarsSelfBalanced*BetaYSelf3Sim(i-1,:)';
    YCogSelf3Balanced(MisYSelf3Balanced) = XBCogSelf3Balanced(MisYSelf3Balanced) + randn(NMisSelf3,1)/sqrt(ThetaYSelf3Sim(i-1,1));
    YCogSelf3Balanced(ICogSelf3LowBalanced|ICogSelf3HighBalanced) = MyTobitDraw(XBCogSelf3Balanced,ThetaYSelf3Sim(i-1,1),ICogSelf3LowBalanced,YSelf3LowValue,ICogSelf3HighBalanced,YSelf3HighValue); % drawing new values for the censored cases
    YCogSelf3Core = YCogSelf3Balanced(ISelfCoreBalanced);
    YCogSelf3Wide = reshape(YCogSelf3Balanced, NSizet,NSizex)';
    
    % Running the regression
    BetaYSelf3Sim(i,:) = MyBayesOLS(X1VarsSelfCore,YCogSelf3Core, ThetaYSelf3Sim(i-1,1),XXVarsSelf,cholXXVarsSelf);
    XBCogSelf3Balanced = X1VarsSelfBalanced*BetaYSelf3Sim(i,:)';
    
    
    %%% linear self-interviews 4
    % Drawing the missing and censored values
    XBCogSelf4Balanced = X1VarsSelfBalanced*BetaYSelf4Sim(i-1,:)';
    YCogSelf4Balanced(MisYSelf4Balanced) = XBCogSelf4Balanced(MisYSelf4Balanced) + randn(NMisSelf4,1)/sqrt(ThetaYSelf4Sim(i-1,1));
    YCogSelf4Balanced(ICogSelf4HighBalanced) = MyTobitDraw(XBCogSelf4Balanced,ThetaYSelf4Sim(i-1,1),zeros(NSize,1),0,ICogSelf4HighBalanced,YSelf4HighValue); % drawing new values for the censored cases
    YCogSelf4Core = YCogSelf4Balanced(ISelfCoreBalanced);
    YCogSelf4Wide = reshape(YCogSelf4Balanced, NSizet,NSizex)';
    
    % Running the regression
    BetaYSelf4Sim(i,:) = MyBayesOLS(X1VarsSelfCore,YCogSelf4Core, ThetaYSelf4Sim(i-1,1),XXVarsSelf,cholXXVarsSelf);
    XBCogSelf4Balanced = X1VarsSelfBalanced*BetaYSelf4Sim(i,:)';

        
    %%% linear proxy interviews 1
    % The cholesky decompositions
    XXVarsProxy = X1VarsProxyCore'*X1VarsProxyCore  + T0xProxy;
    cholXXVarsProxy = chol(inv(XXVarsProxy));
    
    % Drawing the missing and latent values
    XBCogProxy1Core = X1VarsProxyCore*BetaYProxy1Sim(i-1,:)';
    YCogProxy1Core = MyOProbit3Draw(XBCogProxy1Core,ThetaYProxy1Sim(i-1,1),ICogProxy1CatsCoreProxy,MisYProxy1Core); % drawing new values for the latent variable
    YCogProxy1Balanced(IProxyCoreBalanced) = YCogProxy1Core;
    YCogProxy1Wide = reshape(YCogProxy1Balanced, NSizet,NSizex)';
    
    % Running the regression
    BetaYProxy1Sim(i,:) = MyBayesOLS(X1VarsProxyCore,YCogProxy1Core, ThetaYProxy1Sim(i-1,1),XXVarsProxy,cholXXVarsProxy);
    XBCogProxy1Balanced = X1VarsProxyBalanced*BetaYProxy1Sim(i,:)';
    
    
    %%% linear proxy interviews 2
    % Drawing the missing and censored values
    XBCogProxy2Balanced = X1VarsProxyBalanced*BetaYProxy2Sim(i-1,:)';
    YCogProxy2Balanced(MisYProxy2Balanced) = XBCogProxy2Balanced(MisYProxy2Balanced) + randn(NMisProxy2,1)/sqrt(ThetaYProxy2Sim(i-1,1));
    YCogProxy2Balanced(ICogProxy2LowBalanced|ICogProxy2HighBalanced) = MyTobitDraw(XBCogProxy2Balanced,ThetaYProxy2Sim(i-1,1),ICogProxy2LowBalanced,YProxy2LowValue,ICogProxy2HighBalanced,YProxy2HighValue); % drawing new values for the censored cases
    YCogProxy2Core = YCogProxy2Balanced(IProxyCoreBalanced);
    YCogProxy2Wide = reshape(YCogProxy2Balanced, NSizet,NSizex)';
    
    % Running the regression
    BetaYProxy2Sim(i,:) = MyBayesOLS(X1VarsProxyCore,YCogProxy2Core, ThetaYProxy2Sim(i-1,1),XXVarsProxy,cholXXVarsProxy);
    XBCogProxy2Balanced = X1VarsProxyBalanced*BetaYProxy2Sim(i,:)';
        
    
    %%% Step 2: Selection equation for missing HRS cognitive scores 
    %%% linear cognition scores available in all interviews
    % The cholesky decompositions
    XXVarsMisAll = X1VarsMisAllCore'*X1VarsMisAllCore  + T0xMisProxy;
    cholXXVarsMisAll = chol(inv(XXVarsMisAll));
    
    % Drawing latent values
    XBCogAllMisCore = X1VarsMisAllCore*BetaYAllMisSim(i-1,:)';
    YCogAllMisCore = MyProbitDraw(XBCogAllMisCore,MisYAllCore);
    YCogAllMisBalanced(IHRSCoreBalanced,:) = YCogAllMisCore;
    YCogAllMisWide = reshape(YCogAllMisBalanced, NSizet,NSizex)';
    
    %Running the regression
    BetaYAllMisSim(i,:) = MyBayesOLS(X1VarsMisAllCore,YCogAllMisCore, 1,XXVarsMisAll,cholXXVarsMisAll);
    XBCogMisAllBalanced = X1VarsMisProxyBalanced*BetaYAllMisSim(i,:)';
    BAMisAllBalanced    = BetaYAllMisSim(i,DimXVarsMisProxy-8) + WaveDummies*BetaYAllMisSim(i,DimXVarsMisProxy-7:DimXVarsMisProxy)';
    
    
    %%% linear cognition scores available in self interviews 1
    % The cholesky decompositions
    XXVarsMisSelf = X1VarsMisSelfCore'*X1VarsMisSelfCore  + T0xMisSelf;
    cholXXVarsMisSelf = chol(inv(XXVarsMisSelf));
    
    % Drawing latent values
    XBCogSelf1MisCore = X1VarsMisSelfCore*BetaYSelf1MisSim(i-1,:)';
    YCogSelf1MisCore = MyProbitDraw(XBCogSelf1MisCore,MisYSelf1Core);
    YCogSelf1MisBalanced(ISelfCoreBalanced,:) = YCogSelf1MisCore;
    YCogSelf1MisWide = reshape(YCogSelf1MisBalanced, NSizet,NSizex)';
    
    %Running the regression
    BetaYSelf1MisSim(i,:) = MyBayesOLS(X1VarsMisSelfCore,YCogSelf1MisCore, 1,XXVarsMisSelf,cholXXVarsMisSelf);
    XBCogMisSelf1Balanced = X1VarsMisSelfBalanced*BetaYSelf1MisSim(i,:)';
    BAMisSelf1Balanced    = BetaYSelf1MisSim(i,DimXVarsMisSelf-8) + WaveDummies*BetaYSelf1MisSim(i,DimXVarsMisSelf-7:DimXVarsMisSelf)';
    
    %%% linear cognition scores available in self interviews 2 (Note: it has two extra covariates: y1, and y1 missing)
    % Updating the predictor variable 
    X1VarsMisSelf2Balanced = [XVarsMisBalanced, FirstSelfBalanced, YCogSelf1Balanced, MisYSelf1Balanced, CogSimBalanced, WaveDummies.*(CogSimBalanced*ones(1,8))];
    X1VarsMisSelf2Core     = X1VarsMisSelf2Balanced(ISelfCoreBalanced,:);
    
    % The cholesky decompositions
    XXVarsMisSelf2 = X1VarsMisSelf2Core'*X1VarsMisSelf2Core  + T0xMisSelf2;
    cholXXVarsMisSelf2 = chol(inv(XXVarsMisSelf2));
    
    % Drawing latent values
    XBCogSelf2MisCore = X1VarsMisSelf2Core*BetaYSelf2MisSim(i-1,:)';
    YCogSelf2MisCore = MyProbitDraw(XBCogSelf2MisCore,MisYSelf2Core);
    YCogSelf2MisBalanced(ISelfCoreBalanced,:) = YCogSelf2MisCore;
    YCogSelf2MisWide = reshape(YCogSelf2MisBalanced, NSizet,NSizex)';
    
    %Running the regression
    BetaYSelf2MisSim(i,:) = MyBayesOLS(X1VarsMisSelf2Core,YCogSelf2MisCore, 1,XXVarsMisSelf2,cholXXVarsMisSelf2);
    XBCogMisSelf2Balanced = X1VarsMisSelf2Balanced*BetaYSelf2MisSim(i,:)';
    BAMisSelf2Balanced    = BetaYSelf2MisSim(i,DimXVarsMisSelf2-8) + WaveDummies*BetaYSelf2MisSim(i,DimXVarsMisSelf2-7:DimXVarsMisSelf2)';
    
    %%% linear cognition scores available in self interviews 3
    % Drawing latent values
    XBCogSelf3MisCore = X1VarsMisSelfCore*BetaYSelf3MisSim(i-1,:)';
    YCogSelf3MisCore = MyProbitDraw(XBCogSelf3MisCore,MisYSelf3Core);
    YCogSelf3MisBalanced(ISelfCoreBalanced,:) = YCogSelf3MisCore;
    YCogSelf3MisWide = reshape(YCogSelf3MisBalanced, NSizet,NSizex)';
    
    %Running the regression
    BetaYSelf3MisSim(i,:) = MyBayesOLS(X1VarsMisSelfCore,YCogSelf3MisCore, 1,XXVarsMisSelf,cholXXVarsMisSelf);
    XBCogMisSelf3Balanced = X1VarsMisSelfBalanced*BetaYSelf3MisSim(i,:)';
    BAMisSelf3Balanced    = BetaYSelf3MisSim(i,DimXVarsMisSelf-8) + WaveDummies*BetaYSelf3MisSim(i,DimXVarsMisSelf-7:DimXVarsMisSelf)';
    
    %%% linear cognition scores available in self interviews 4
    % Updating the predictor variable 
    X1VarsMisSelf4Balanced = [XVarsMisBalanced, FirstSelfBalanced, Age65Balanced, CogSimBalanced, WaveDummies.*(CogSimBalanced*ones(1,8))];
    X1VarsMisSelf4Core     = X1VarsMisSelf4Balanced(ISelfCoreBalanced,:);
    
    % The cholesky decompositions
    XXVarsMisSelf4 = X1VarsMisSelf4Core'*X1VarsMisSelf4Core  + T0xMisSelf4;
    cholXXVarsMisSelf4 = chol(inv(XXVarsMisSelf4));
    
    % Drawing latent values
    XBCogSelf4MisCore = X1VarsMisSelf4Core*BetaYSelf4MisSim(i-1,:)';
    YCogSelf4MisCore = MyProbitDraw(XBCogSelf4MisCore,MisYSelf4Core);
    YCogSelf4MisBalanced(ISelfCoreBalanced,:) = YCogSelf4MisCore;
    YCogSelf4MisWide = reshape(YCogSelf4MisBalanced, NSizet,NSizex)';
    
    %Running the regression
    BetaYSelf4MisSim(i,:) = MyBayesOLS(X1VarsMisSelf4Core,YCogSelf4MisCore, 1,XXVarsMisSelf4,cholXXVarsMisSelf4);
    XBCogMisSelf4Balanced = X1VarsMisSelf4Balanced*BetaYSelf4MisSim(i,:)';
    BAMisSelf4Balanced    = BetaYSelf4MisSim(i,DimXVarsMisSelf4-8) + WaveDummies*BetaYSelf4MisSim(i,DimXVarsMisSelf4-7:DimXVarsMisSelf4)';
    
    %%% linear cognition scores available in proxy interviews 2
    % The cholesky decompositions
    XXVarsMisProxy = X1VarsMisProxyCore'*X1VarsMisProxyCore  + T0xMisProxy;
    cholXXVarsMisProxy = chol(inv(XXVarsMisProxy));
    
    % Drawing latent values
    XBCogProxy2MisCore = X1VarsMisProxyCore*BetaYProxy2MisSim(i-1,:)';
    YCogProxy2MisCore = MyProbitDraw(XBCogProxy2MisCore,MisYProxy2Core);
    YCogProxy2MisBalanced(IProxyCoreBalanced,:) = YCogProxy2MisCore;
    YCogProxy2MisWide = reshape(YCogProxy2MisBalanced, NSizet,NSizex)';
    
    %Running the regression
    BetaYProxy2MisSim(i,:) = MyBayesOLS(X1VarsMisProxyCore,YCogProxy2MisCore, 1,XXVarsMisProxy,cholXXVarsMisProxy);
    XBCogMisProxy2Balanced = X1VarsMisProxyBalanced*BetaYProxy2MisSim(i,:)';
    BAMisProxy2Balanced    = BetaYProxy2MisSim(i,DimXVarsMisProxy-8) + WaveDummies*BetaYProxy2MisSim(i,DimXVarsMisProxy-7:DimXVarsMisProxy)';
    
    
    %%% Step 3: Running the regression of Proxy selection
    % linear self-interviews
    XBProxyCore   = X1ProxyCore*BetaProxySim(i-1,:)';
    YProxySimCore = MyProbitDraw(XBProxyCore,IProxyCore);
    YProxySimBalanced(IHRSCoreBalanced) = YProxySimCore;
    YProxySimWide = reshape(YProxySimBalanced,NSizet,NSizex)'; 
    
    BetaProxySim(i,:) = MyBayesOLS(X1ProxyCore,YProxySimCore, 1);
    XBProxyBalanced   = X1ProxyBalanced*BetaProxySim(i,:)';
    BAPROXYBalanced   = BetaProxySim(i,DimXProxy-8) + WaveDummies*BetaProxySim(i,DimXProxy-7:DimXProxy)';
    
    
    %%% Step 4: Running the cognition regression 
    CogSimBalancedNetU = CogSimBalanced - U0BalancedSim - U1BalancedSim.*AgeCentBalanced;
    XCogHRSBalanced    = XCogBalanced(IHRSAllBalanced,:);
    XXCog              = XCogHRSBalanced'*XCogHRSBalanced + T0xCog;
    cholXXCog          = chol(inv(XXCog));
    
    BetaCogSim(i,:) = MyBayesOLS(XCogHRSBalanced,CogSimBalancedNetU(IHRSAllBalanced), ThetaCogMSim(i-1),XXCog,cholXXCog);
    XBCogBalanced   = XCogBalanced*BetaCogSim(i,:)';
    
    
    %%% Step 5: ADAMS selection
    % drawing new latent variables
    YIAdamsProxyW5 = MyProbitDraw(XBIAdamsProxyW5,IAdamsSelectedProxyW5);
    YIAdamsProxyW6 = MyProbitDraw(XBIAdamsProxyW6,IAdamsSelectedProxyW6);
    YIAdamsSelfW5  = MyProbitDraw(XBIAdamsSelfW5 ,IAdamsSelectedSelfW5);
    YIAdamsSelfW6  = MyProbitDraw(XBIAdamsSelfW6 ,IAdamsSelectedSelfW6);
    
    %running the selection regressions
    BetaIAdamsProxyW5Sim(i,:) = MyBayesOLS(XAdamsProxyBalancedW5,YIAdamsProxyW5, 1, XXIAdamsProxyW5, cholXXIAdamsProxyW5);
    XBIAdamsProxyW5 = XAdamsProxyBalancedW5*BetaIAdamsProxyW5Sim(i,:)';
    
    BetaIAdamsProxyW6Sim(i,:) = MyBayesOLS(XAdamsProxyBalancedW6,YIAdamsProxyW6, 1, XXIAdamsProxyW6, cholXXIAdamsProxyW6);
    XBIAdamsProxyW6 = XAdamsProxyBalancedW6*BetaIAdamsProxyW6Sim(i,:)';
    
    BetaIAdamsSelfW5Sim(i,:) = MyBayesOLS(XAdamsSelfBalancedW5,YIAdamsSelfW5, 1, XXIAdamsSelfW5, cholXXIAdamsSelfW5);
    XBIAdamsSelfW5 = XAdamsSelfBalancedW5*BetaIAdamsSelfW5Sim(i,:)';
    
    BetaIAdamsSelfW6Sim(i,:) = MyBayesOLS(XAdamsSelfBalancedW6,YIAdamsSelfW6, 1, XXIAdamsSelfW6, cholXXIAdamsSelfW6);
    XBIAdamsSelfW6 = XAdamsSelfBalancedW6*BetaIAdamsSelfW6Sim(i,:)';   
    
    
    %%% Step 6: ADAMS interview timing
    %Drawing missing values (dead & non-respondent) in all four waves: Need to factor the effect on age and cognition.    
    %%% WA
    AgeBalancedCand = AgeBalanced;
    XBAdamsTimeBalancedWA(IAdamsSelectedBalancedWA,:)  = XAdamsTimeWA1*BetaAdamsTimeWASim(i-1,:)';
    XBAdamsTimeBalanced(IAdamsSelectedBalancedWA,:)    = XBAdamsTimeBalancedWA(IAdamsSelectedBalancedWA,:);
    IWTimeBalancedCand(IAdamsNonRespondentBalancedWA)  = IWTimeBalanced(IAdamsNonRespondentBalancedWA) + randn(NAdamsNonRespondentWA,1)*PropSdIWWA;
    AgeBalancedCand(IAdamsNonRespondentBalancedWA)     = AgeBalanced(IAdamsNonRespondentShiftedWA) + exp(IWTimeBalancedCand(IAdamsNonRespondentBalancedWA));
    
    [AgeBalanced, IWTimeBalanced, IWTimeAdamsWA, XCogBalanced, XBCogBalanced, PropSdIWWA, MeanAcceptIW(i-1,1)] = MyAdamsIWTimingUpdate(AgeBalanced, AgeBalancedCand, ...
           AgeBalanced_Min, AgeBalanced_Max, CenterAge, IWTimeBalanced, IWTimeBalancedCand, XBAdamsTimeBalanced, IAdamsSelectedBalancedWA, IAdamsRespondentBalancedWA, ...
           IAdamsNonRespondentBalancedWA, IAdamsSurvivedBalancedWA, IAdamsSurvNonRespWA, NAdamsNonRespondentWA, PropSdIWWA, XCogBalanced, BetaCogSim(i,:), ...
           CogSimBalanced, U0BalancedSim, U1BalancedSim, XBCogBalanced, XBirthYearBalanced, ThetaCogMSim(i-1,1), YAdamsRespBalanced, ...
           BetaAdamsRespWASim(i-1,:), XAdamsRespWA, ThetaAdamsTimeWASim(i-1,1), NSize, DimXCogDem, DimXCogAge, DimXAdamsRespDemVars, BurnedDraws, i); 
        
    %%% WB
    AgeBalancedCand = AgeBalanced;
    XBAdamsTimeBalancedWB(IAdamsSelectedBalancedWB,:)  = XAdamsTimeWB1*BetaAdamsTimeWBSim(i-1,:)';
    XBAdamsTimeBalanced(IAdamsSelectedBalancedWB,:)    = XBAdamsTimeBalancedWB(IAdamsSelectedBalancedWB,:);
    IWTimeBalancedCand(IAdamsNonRespondentBalancedWB)  = IWTimeBalanced(IAdamsNonRespondentBalancedWB) + randn(NAdamsNonRespondentWB,1)*PropSdIWWB;
    AgeBalancedCand(IAdamsNonRespondentBalancedWB) = AgeWABalanced(IAdamsNonRespondentShiftedWB)   + exp(IWTimeBalancedCand(IAdamsNonRespondentBalancedWB));
    
    [AgeBalanced, IWTimeBalanced, IWTimeAdamsWB, XCogBalanced, XBCogBalanced, PropSdIWWB, MeanAcceptIW(i-1,2)] = MyAdamsIWTimingUpdate(AgeBalanced, AgeBalancedCand, ...
           AgeBalanced_Min, AgeBalanced_Max, CenterAge, IWTimeBalanced, IWTimeBalancedCand, XBAdamsTimeBalanced, IAdamsSelectedBalancedWB, IAdamsRespondentBalancedWB, ...
           IAdamsNonRespondentBalancedWB, IAdamsSurvivedBalancedWB, IAdamsSurvNonRespWB, NAdamsNonRespondentWB, PropSdIWWB, XCogBalanced, BetaCogSim(i,:), ...
           CogSimBalanced, U0BalancedSim, U1BalancedSim, XBCogBalanced, XBirthYearBalanced, ThetaCogMSim(i-1,1), YAdamsRespBalanced, ...
           BetaAdamsRespWBSim(i-1,:), XAdamsRespWB, ThetaAdamsTimeWBSim(i-1,1), NSize, DimXCogDem, DimXCogAge, DimXAdamsRespDemVars, BurnedDraws, i);
        
    %%% WC
    AgeBalancedCand = AgeBalanced;
    XBAdamsTimeBalancedWC(IAdamsSelectedBalancedWC,:)  = XAdamsTimeWC1*BetaAdamsTimeWCSim(i-1,:)';
    XBAdamsTimeBalanced(IAdamsSelectedBalancedWC,:)    = XBAdamsTimeBalancedWC(IAdamsSelectedBalancedWC,:);
    IWTimeBalancedCand(IAdamsNonRespondentBalancedWC)  = IWTimeBalanced(IAdamsNonRespondentBalancedWC) + randn(NAdamsNonRespondentWC,1)*PropSdIWWC;
    AgeBalancedCand(IAdamsNonRespondentBalancedWC) = AgeWABalanced(IAdamsNonRespondentShiftedWC)   + exp(IWTimeBalancedCand(IAdamsNonRespondentBalancedWC));
    
    [AgeBalanced, IWTimeBalanced, IWTimeAdamsWC, XCogBalanced, XBCogBalanced, PropSdIWWC, MeanAcceptIW(i-1,3)] = MyAdamsIWTimingUpdate(AgeBalanced, AgeBalancedCand, ...
           AgeBalanced_Min, AgeBalanced_Max, CenterAge, IWTimeBalanced, IWTimeBalancedCand, XBAdamsTimeBalanced, IAdamsSelectedBalancedWC, IAdamsRespondentBalancedWC, ...
           IAdamsNonRespondentBalancedWC, IAdamsSurvivedBalancedWC, IAdamsSurvNonRespWC, NAdamsNonRespondentWC, PropSdIWWC, XCogBalanced, BetaCogSim(i,:), ...
           CogSimBalanced, U0BalancedSim, U1BalancedSim, XBCogBalanced, XBirthYearBalanced, ThetaCogMSim(i-1,1), YAdamsRespBalanced, ...
           BetaAdamsRespWCSim(i-1,:), XAdamsRespWC, ThetaAdamsTimeWCSim(i-1,1), NSize, DimXCogDem, DimXCogAge, DimXAdamsRespDemVars, BurnedDraws, i);
           
    %%% WD
    AgeBalancedCand = AgeBalanced;
    XBAdamsTimeBalancedWD(IAdamsSelectedBalancedWD,:)  = XAdamsTimeWD1*BetaAdamsTimeWDSim(i-1,:)';
    XBAdamsTimeBalanced(IAdamsSelectedBalancedWD,:)    = XBAdamsTimeBalancedWD(IAdamsSelectedBalancedWD,:);
    IWTimeBalancedCand(IAdamsNonRespondentBalancedWD)  = IWTimeBalanced(IAdamsNonRespondentBalancedWD) + randn(NAdamsNonRespondentWD,1)*PropSdIWWD;
    AgeBalancedCand(IAdamsNonRespondentBalancedWD) = AgeWABalanced(IAdamsNonRespondentShiftedWD)   + exp(IWTimeBalancedCand(IAdamsNonRespondentBalancedWD));
    
    [AgeBalanced, IWTimeBalanced, IWTimeAdamsWD, XCogBalanced, XBCogBalanced, PropSdIWWD, MeanAcceptIW(i-1,4)] = MyAdamsIWTimingUpdate(AgeBalanced, AgeBalancedCand, ...
           AgeBalanced_Min, AgeBalanced_Max, CenterAge, IWTimeBalanced, IWTimeBalancedCand, XBAdamsTimeBalanced, IAdamsSelectedBalancedWD, IAdamsRespondentBalancedWD, ...
           IAdamsNonRespondentBalancedWD, IAdamsSurvivedBalancedWD, IAdamsSurvNonRespWD, NAdamsNonRespondentWD, PropSdIWWD, XCogBalanced, BetaCogSim(i,:), ...
           CogSimBalanced, U0BalancedSim, U1BalancedSim, XBCogBalanced, XBirthYearBalanced, ThetaCogMSim(i-1,1), YAdamsRespBalanced, ...
           BetaAdamsRespWDSim(i-1,:), XAdamsRespWD, ThetaAdamsTimeWDSim(i-1,1), NSize, DimXCogDem, DimXCogAge, DimXAdamsRespDemVars, BurnedDraws, i);  
    
    % Saving some variables cross sectionally
    IWTimeAdamsWBBalanced = MyXSecMax(IWTimeAdamsWB,IAdamsSelectedBalancedWB,NSize,NSizex,NSizet);
    IWTimeAdamsWCBalanced = MyXSecMax(IWTimeAdamsWC,IAdamsSelectedBalancedWC,NSize,NSizex,NSizet);
    IWTimeAdamsWDBalanced = MyXSecMax(IWTimeAdamsWD,IAdamsSelectedBalancedWD,NSize,NSizex,NSizet);
    
    % Running the regressions on interview timings
    BetaAdamsTimeWASim(i,:) = MyBayesOLS(XAdamsTimeWA1,IWTimeAdamsWA, ThetaAdamsTimeWASim(i-1));
    XBAdamsTimeBalancedWA(IAdamsSelectedBalancedWA,:) = XAdamsTimeWA1*BetaAdamsTimeWASim(i,:)';
    
    BetaAdamsTimeWBSim(i,:) = MyBayesOLS(XAdamsTimeWB1,IWTimeAdamsWB, ThetaAdamsTimeWBSim(i-1));
    XBAdamsTimeBalancedWB(IAdamsSelectedBalancedWB,:) = XAdamsTimeWB1*BetaAdamsTimeWBSim(i,:)';
    
    BetaAdamsTimeWCSim(i,:) = MyBayesOLS(XAdamsTimeWC1,IWTimeAdamsWC, ThetaAdamsTimeWCSim(i-1));
    XBAdamsTimeBalancedWC(IAdamsSelectedBalancedWC,:) = XAdamsTimeWC1*BetaAdamsTimeWCSim(i,:)';
    
    BetaAdamsTimeWDSim(i,:) = MyBayesOLS(XAdamsTimeWD1,IWTimeAdamsWD, ThetaAdamsTimeWDSim(i-1));
    XBAdamsTimeBalancedWD(IAdamsSelectedBalancedWD,:) = XAdamsTimeWD1*BetaAdamsTimeWDSim(i,:)';
    
    % Saving some variables cross sectionally
    XBAdamsTimeBalancedAnyWB = MyXSecMax(XBAdamsTimeBalancedWB(IAdamsSelectedBalancedWB,:),IAdamsSelectedBalancedWB,NSize,NSizex,NSizet);
    XBAdamsTimeBalancedAnyWC = MyXSecMax(XBAdamsTimeBalancedWC(IAdamsSelectedBalancedWC,:),IAdamsSelectedBalancedWC,NSize,NSizex,NSizet);
    XBAdamsTimeBalancedAnyWD = MyXSecMax(XBAdamsTimeBalancedWD(IAdamsSelectedBalancedWD,:),IAdamsSelectedBalancedWD,NSize,NSizex,NSizet);
    
    %Overwriting Adams age with the new values
    AgeBalancedNR  = AgeBalanced(IAdamsNonRespondentBalanced);
    AuxNR = [(AgeBalancedNR - CenterAge), (AgeBalancedNR - CenterAge).^2,(AgeBalancedNR - CenterAge).^3];
    X1ProxyBalanced(IAdamsNonRespondentBalanced,DimXProxyDem+1:DimXProxyDem+DimXProxyAge) = AuxNR;
    XBCogWide  = reshape(XBCogBalanced, NSizet, NSizex)';
    AgeWide  = reshape(AgeBalanced,NSizet,NSizex)'; 
    AgeWide(~IHRSAllWide) = 0;
    AgeCentWide = AgeWide - CenterAge;
    AgeCentWide(~IHRSAllWide) = 0;
    AgeCentBalanced  = (AgeBalanced - CenterAge);
        

    %%% Step 7: Survival
    % Updating the coefficients in the shape parameter
    for j = 1:DimXSurv
        DGCand = randn*PropGammaShape(j);
        GCand  = LnGammaShapeSim(i-1,j) + DGCand;
        LnGammaShapeCand = LnGammaShape + DGCand*XHRSSurv1(:,j);
        GammaShapeCand   = exp(LnGammaShapeCand); 
        
        LnLike     = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleSim(i-1), GammaShape);
        LnLikeCand = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleSim(i-1), GammaShapeCand);

        LnPrior     = - (LnGammaShapeSim(i-1,j)).^2/2*Tau0;
        LnPriorCand = - (GCand                 ).^2/2*Tau0;

        Accept = log(rand) < sum(LnLikeCand - LnLike) + LnPriorCand - LnPrior;
        
        LnGammaShapeSim(i,j) = LnGammaShapeSim(i-1,j);
        if Accept==1
            LnGammaShapeSim(i,j) = GCand;
            LnGammaShape = LnGammaShapeCand;
            GammaShape = GammaShapeCand;
            
            AcceptGammaShape(i,j) = 1;
        end
        
        if (i>100) && (i<BurnedDraws) && (i==floor(i/100)*100)
            PropGammaShape(j) = ProposalDensityUpdate(PropGammaShape(j), mean(AcceptGammaShape(i-100:i,j)), 0.001, 1, 0.2, 0.4);
        end
    end    
        
    % Updating the scale parameter
    LnGammaScaleCand = log(GammaScaleSim(i-1)) + randn*PropGammaScale;
    GammaScaleCand   = exp(LnGammaScaleCand);

    LnLike     = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleSim(i-1), GammaShape);
    LnLikeCand = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleCand    , GammaShape);

    LnPrior     = - log(GammaScaleSim(i-1))^2/2*Tau0;
    LnPriorCand = - LnGammaScaleCand^2/2*Tau0;

    AcceptGammaScale(i-1,1) = log(rand) < sum(LnLikeCand - LnLike) + LnPriorCand - LnPrior;

    GammaScaleSim(i) = GammaScaleSim(i-1) ;
    if AcceptGammaScale(i-1,1)==1
        GammaScaleSim(i) = GammaScaleCand;
    end

    %Updating the proposal density
    if (i>100) && (i<BurnedDraws) && (i==floor(i/100)*100)
        PropGammaScale(1,1) = ProposalDensityUpdate(PropGammaScale(1,1),mean(AcceptGammaScale(i-100:i,1)), 0.001, 1, 0.2, 0.4);
    end
    
    
    %%% Step 8: ADAMS non-response
    %WA
    [BetaAdamsRespWASim, YAdamsRespBalanced, XAdamsRespWA, XBAdamsRespBalanced] = MyAdamsRespUpdate(YAdamsRespBalanced, AgeBalanced, IAdamsSurvivedBalancedWA, IAdamsRespondentSurvWA, CogSimBalanced, XAdamsRespWA, XBAdamsRespBalanced, BetaAdamsRespWASim, DimXAdamsRespDemVars, i);
    
    %WB
    [BetaAdamsRespWBSim, YAdamsRespBalanced, XAdamsRespWB, XBAdamsRespBalanced] = MyAdamsRespUpdate(YAdamsRespBalanced, AgeBalanced, IAdamsSurvivedBalancedWB, IAdamsRespondentSurvWB, CogSimBalanced, XAdamsRespWB, XBAdamsRespBalanced, BetaAdamsRespWBSim, DimXAdamsRespDemVars, i);

    %WC
    [BetaAdamsRespWCSim, YAdamsRespBalanced, XAdamsRespWC, XBAdamsRespBalanced] = MyAdamsRespUpdate(YAdamsRespBalanced, AgeBalanced, IAdamsSurvivedBalancedWC, IAdamsRespondentSurvWC, CogSimBalanced, XAdamsRespWC, XBAdamsRespBalanced, BetaAdamsRespWCSim, DimXAdamsRespDemVars, i);

    %WD
    [BetaAdamsRespWDSim, YAdamsRespBalanced, XAdamsRespWD, XBAdamsRespBalanced] = MyAdamsRespUpdate(YAdamsRespBalanced, AgeBalanced, IAdamsSurvivedBalancedWD, IAdamsRespondentSurvWD, CogSimBalanced, XAdamsRespWD, XBAdamsRespBalanced, BetaAdamsRespWDSim, DimXAdamsRespDemVars, i);
    
    
    %%% Step 9: Drawing cognition
    CogResidWide = CogSimWide-XBCogWide;
    CogResidWide(IHRSAllWide<0.5) = 0;
        
    %%% The random effects
    % The random effect constant
    CondV = VarU(1,1) - VarU(1,2)/VarU(2,2)*VarU(2,1);
    CondM = U1Sim/VarU(2,2)*VarU(2,1);
    
    U0Cand     = U0Sim + randn(NSizex,1)*PropCogU(1);
    U0WideCand = U0Cand*ones(1,NSizet);
    U0WideCand(~IHRSAllWide) = 0;
    
    LnGammaShapeCand = LnGammaShape + LnGammaShapeSim(i,DimXSurv-1).*(U0Cand - U0Sim);
    GammaShapeCand   = exp(LnGammaShapeCand);
    
    LnPrior     = - (U0Sim  - CondM).^2/2/CondV;
    LnPriorCand = - (U0Cand - CondM).^2/2/CondV;
    
    LnLikeSurv     = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, 0, GammaScaleSim(i), GammaShape);
    LnLikeSurvCand = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, 0, GammaScaleSim(i), GammaShapeCand);
    
    LnLikeCog     = - sum(0.5*(CogResidWide - U0WideSim  - U1WideSim.*AgeCentWide).^2*ThetaCogMSim(i-1),2);
    LnLikeCogCand = - sum(0.5*(CogResidWide - U0WideCand - U1WideSim.*AgeCentWide).^2*ThetaCogMSim(i-1),2);
    
    Accept = log(rand(NSizex,1)) < LnLikeSurvCand - LnLikeSurv + LnLikeCogCand - LnLikeCog + LnPriorCand - LnPrior;
    
    U0Sim(Accept) = U0Cand(Accept);
    U0WideSim = U0Sim*ones(1,NSizet);
    U0WideSim(~IHRSAllWide) = 0;
    U0BalancedSim = reshape(U0WideSim',NSize,1);
    
    XHRSSurv1(:,DimXSurv-1) = U0Sim;
    LnGammaShape = XHRSSurv1*LnGammaShapeSim(i,:)';
    GammaShape   = exp(LnGammaShape);
    
    %Updating the proposal density
    MeanAcceptCogU(i-1,1) = mean(Accept);
    if (i>200) && (i<BurnedDraws)
        PropCogU(1) = ProposalDensityUpdate(PropCogU(1),MeanAcceptCogU(i-1,1), 0.1, 3, 0.15, 0.35);
    end
    
    
    % The random effect term interacted with age
    CondV = VarU(2,2) - VarU(2,1)/VarU(1,1)*VarU(1,2);
    CondM = U0Sim/VarU(1,1)*VarU(1,2);
    
    U1Cand     = U1Sim + randn(NSizex,1)*PropCogU(2);
    U1WideCand = U1Cand*ones(1,NSizet);
    U1WideCand(~IHRSAllWide) = 0;
    
    LnGammaShapeCand = LnGammaShape + LnGammaShapeSim(i,DimXSurv).*(U1Cand - U1Sim);
    GammaShapeCand   = exp(LnGammaShapeCand);
    
    LnPrior     = - (U1Sim  - CondM).^2/2/CondV;
    LnPriorCand = - (U1Cand - CondM).^2/2/CondV;
    
    LnLikeSurv     = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, 0, GammaScaleSim(i), GammaShape);
    LnLikeSurvCand = LnSurvLike(DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, 0, GammaScaleSim(i), GammaShapeCand);
    
    LnLikeCog     = - sum(0.5*(CogResidWide - U0WideSim - U1WideSim.*AgeCentWide).^2*ThetaCogMSim(i-1),2);
    LnLikeCogCand = - sum(0.5*(CogResidWide - U0WideSim - U1WideCand.*AgeCentWide).^2*ThetaCogMSim(i-1),2);

    Accept = log(rand(NSizex,1)) < LnLikeSurvCand - LnLikeSurv + LnLikeCogCand - LnLikeCog + LnPriorCand - LnPrior;
    
    U1Sim(Accept) = U1Cand(Accept);
    U1WideSim = U1Sim*ones(1,NSizet);
    U1WideSim(~IHRSAllWide) = 0;
    U1BalancedSim = reshape(U1WideSim',NSize,1);
    
    XHRSSurv1(:,DimXSurv) = U1Sim;
    LnGammaShape = XHRSSurv1*LnGammaShapeSim(i,:)';
    GammaShape   = exp(LnGammaShape);
    
    %Updating the proposal density
    MeanAcceptCogU(i-1,2) = mean(Accept);
    if (i>200) && (i<BurnedDraws)
        PropCogU(2) = ProposalDensityUpdate(PropCogU(2),MeanAcceptCogU(i-1,2), 0.1, 3, 0.15, 0.35);
    end
        
    XBUCogBalanced  = XBCogBalanced + U0BalancedSim + U1BalancedSim.*AgeCentBalanced;
    CogNoiseBalanced = CogSimBalanced - XBUCogBalanced;
    CogNoiseBalanced(~IHRSAllBalanced) = 0;
       
    %%% The noise term in cognition
    %Initializing the precision and some mean terms
    T_Prior         = zeros(NSize,1);
    T_DataAll       = zeros(NSize,1);
    T_DataSelf1     = zeros(NSize,1);
    T_DataSelf2     = zeros(NSize,1);
    T_DataSelf3     = zeros(NSize,1);
    T_DataSelf4     = zeros(NSize,1);
    T_DataProxy1    = zeros(NSize,1);
    T_DataProxy2    = zeros(NSize,1);
    T_DataMisAll    = zeros(NSize,1);
    T_DataMisSelf1  = zeros(NSize,1);
    T_DataMisSelf2  = zeros(NSize,1);
    T_DataMisSelf3  = zeros(NSize,1);
    T_DataMisSelf4  = zeros(NSize,1);
    T_DataMisProxy2 = zeros(NSize,1);
    T_ProxySel      = zeros(NSize,1);
    T_AdamsTimeWA   = zeros(NSize,1);
    T_AdamsTimeWB   = zeros(NSize,1);
    T_AdamsTimeWC   = zeros(NSize,1);
    T_AdamsTimeWD   = zeros(NSize,1);
    T_AdamsResp     = zeros(NSize,1);
    
    Mu_AdamsTimeWA  = zeros(NSize,1);
    Mu_AdamsTimeWB  = zeros(NSize,1);
    Mu_AdamsTimeWC  = zeros(NSize,1);
    Mu_AdamsTimeWD  = zeros(NSize,1);
    Mu_AdamsResp    = zeros(NSize,1);

    % The prior
    T_Prior(IHRSAllBalanced) = ThetaCogMSim(i-1);
    Mu_Prior = zeros(NSize,1);
    
    %The HRS cognition scores and non-response
    T_DataAll(IHRSCoreBalanced)      = ThetaYAllSim(i-1)*(BetaYAllSim(i,DimXVarsProxy)^2);
    T_DataSelf1(ISelfCoreBalanced)   = ThetaYSelf1Sim(i-1)*(BetaYSelf1Sim(i,DimXVarsSelf)^2);
    T_DataSelf2(ISelfCoreBalanced)   = ThetaYSelf2Sim(i-1)*(BetaYSelf2Sim(i,DimXVarsSelf2)^2);
    T_DataSelf3(ISelfCoreBalanced)   = ThetaYSelf3Sim(i-1)*(BetaYSelf3Sim(i,DimXVarsSelf)^2);
    T_DataSelf4(ISelfCoreBalanced)   = ThetaYSelf4Sim(i-1)*(BetaYSelf4Sim(i,DimXVarsSelf)^2);
    T_DataProxy1(IProxyCoreBalanced) = ThetaYProxy1Sim(i-1)*(BetaYProxy1Sim(i,DimXVarsProxy)^2);
    T_DataProxy2(IProxyCoreBalanced) = ThetaYProxy2Sim(i-1)*(BetaYProxy2Sim(i,DimXVarsProxy)^2);

    T_DataMisAll(IHRSCoreBalanced)      = BAMisAllBalanced(IHRSCoreBalanced).^2;
    T_DataMisSelf1(ISelfCoreBalanced)   = BAMisSelf1Balanced(ISelfCoreBalanced).^2;
    T_DataMisSelf2(ISelfCoreBalanced)   = BAMisSelf2Balanced(ISelfCoreBalanced).^2;
    T_DataMisSelf3(ISelfCoreBalanced)   = BAMisSelf3Balanced(ISelfCoreBalanced).^2;
    T_DataMisSelf4(ISelfCoreBalanced)   = BAMisSelf4Balanced(ISelfCoreBalanced).^2;
    T_DataMisProxy2(IProxyCoreBalanced) = BAMisProxy2Balanced(IProxyCoreBalanced).^2;

    Mu_DataAll    = (YCogAllBalanced    - XBCogAllBalanced)/BetaYAllSim(i,DimXVarsProxy)       + CogNoiseBalanced;
    Mu_DataSelf1  = (YCogSelf1Balanced  - XBCogSelf1Balanced)/BetaYSelf1Sim(i,DimXVarsSelf)    + CogNoiseBalanced;
    Mu_DataSelf2  = (YCogSelf2Balanced  - XBCogSelf2Balanced)/BetaYSelf2Sim(i,DimXVarsSelf2)   + CogNoiseBalanced;
    Mu_DataSelf3  = (YCogSelf3Balanced  - XBCogSelf3Balanced)/BetaYSelf3Sim(i,DimXVarsSelf)    + CogNoiseBalanced;
    Mu_DataSelf4  = (YCogSelf4Balanced  - XBCogSelf4Balanced)/BetaYSelf4Sim(i,DimXVarsSelf)    + CogNoiseBalanced;
    Mu_DataProxy1 = (YCogProxy1Balanced - XBCogProxy1Balanced)/BetaYProxy1Sim(i,DimXVarsProxy) + CogNoiseBalanced;
    Mu_DataProxy2 = (YCogProxy2Balanced - XBCogProxy2Balanced)/BetaYProxy2Sim(i,DimXVarsProxy) + CogNoiseBalanced;

    Mu_DataMisAll    = (YCogAllMisBalanced    - XBCogMisAllBalanced)./BAMisAllBalanced       + CogNoiseBalanced;
    Mu_DataMisSelf1  = (YCogSelf1MisBalanced  - XBCogMisSelf1Balanced)./BAMisSelf1Balanced   + CogNoiseBalanced;
    Mu_DataMisSelf2  = (YCogSelf2MisBalanced  - XBCogMisSelf2Balanced)./BAMisSelf2Balanced   + CogNoiseBalanced;
    Mu_DataMisSelf3  = (YCogSelf3MisBalanced  - XBCogMisSelf3Balanced)./BAMisSelf3Balanced   + CogNoiseBalanced;
    Mu_DataMisSelf4  = (YCogSelf4MisBalanced  - XBCogMisSelf4Balanced)./BAMisSelf4Balanced   + CogNoiseBalanced;
    Mu_DataMisProxy2 = (YCogProxy2MisBalanced - XBCogMisProxy2Balanced)./BAMisProxy2Balanced + CogNoiseBalanced;

    %Proxy selection
    T_ProxySel(IHRSCoreBalanced) = BAPROXYBalanced(IHRSCoreBalanced).^2;
    Mu_ProxySel  = (YProxySimBalanced - XBProxyBalanced)./BAPROXYBalanced + CogNoiseBalanced;

    % ADAMS WA interview time (Depends on cognition at the previous HRS interview)
    BAT = BetaAdamsTimeWASim(i,DimXAdamsTimeVars-1) + BetaAdamsTimeWASim(i,DimXAdamsTimeVars)*W6WABalanced(IAdamsSelectedBalancedWA);
    T_AdamsTimeWA(IAdamsSelectedShiftedWA)  = ThetaAdamsTimeWASim(i-1)*(BAT.^2);
    Mu_AdamsTimeWA(IAdamsSelectedShiftedWA) = (IWTimeBalanced(IAdamsSelectedBalancedWA) - XBAdamsTimeBalancedWA(IAdamsSelectedBalancedWA))./BAT + CogNoiseBalanced(IAdamsSelectedShiftedWA);

    
    % ADAMS WB, WC, WD, interview time (Depends on WA cognition)
    BAT = BetaAdamsTimeWBSim(i,DimXAdamsTimeVars-1) + BetaAdamsTimeWBSim(i,DimXAdamsTimeVars)*W6WABalanced(IAdamsSelectedBalancedWA);
    T_AdamsTimeWB(IAdamsSelectedBalancedWA)  = ThetaAdamsTimeWBSim(i-1)*(BAT.^2);
    T_AdamsTimeWB(~IAnyAdamsSelectedWBBalanced) = 0;
    Mu_AdamsTimeWB(IAdamsSelectedBalancedWA) = (IWTimeAdamsWBBalanced(IAdamsSelectedBalancedWA) - XBAdamsTimeBalancedAnyWB(IAdamsSelectedBalancedWA))./BAT + CogNoiseBalanced(IAdamsSelectedBalancedWA);

    BAT = BetaAdamsTimeWCSim(i,DimXAdamsTimeVars-1) + BetaAdamsTimeWCSim(i,DimXAdamsTimeVars)*W6WABalanced(IAdamsSelectedBalancedWA);
    T_AdamsTimeWC(IAdamsSelectedBalancedWA)  = ThetaAdamsTimeWCSim(i-1)*(BAT.^2);
    T_AdamsTimeWC(~IAnyAdamsSelectedWCBalanced) = 0;
    Mu_AdamsTimeWC(IAdamsSelectedBalancedWA) = (IWTimeAdamsWCBalanced(IAdamsSelectedBalancedWA) - XBAdamsTimeBalancedAnyWC(IAdamsSelectedBalancedWA))./BAT + CogNoiseBalanced(IAdamsSelectedBalancedWA);

    BAT = BetaAdamsTimeWDSim(i,DimXAdamsTimeVars-1) + BetaAdamsTimeWDSim(i,DimXAdamsTimeVars)*W6WABalanced(IAdamsSelectedBalancedWA);
    T_AdamsTimeWD(IAdamsSelectedBalancedWA)  = ThetaAdamsTimeWDSim(i-1)*(BAT.^2);
    T_AdamsTimeWD(~IAnyAdamsSelectedWDBalanced) = 0;
    Mu_AdamsTimeWD(IAdamsSelectedBalancedWA) = (IWTimeAdamsWDBalanced(IAdamsSelectedBalancedWA) - XBAdamsTimeBalancedAnyWD(IAdamsSelectedBalancedWA))./BAT + CogNoiseBalanced(IAdamsSelectedBalancedWA);

    %ADAMS response
    T_AdamsResp(IAdamsSurvivedBalancedWA) = BetaAdamsRespWASim(i,DimXAdamsRespVars).^2;
    T_AdamsResp(IAdamsSurvivedBalancedWB) = BetaAdamsRespWBSim(i,DimXAdamsRespVars).^2;
    T_AdamsResp(IAdamsSurvivedBalancedWC) = BetaAdamsRespWCSim(i,DimXAdamsRespVars).^2;
    T_AdamsResp(IAdamsSurvivedBalancedWD) = BetaAdamsRespWDSim(i,DimXAdamsRespVars).^2;
    Mu_AdamsResp(IAdamsSurvivedBalancedWA) = (YAdamsRespBalanced(IAdamsSurvivedBalancedWA) - XBAdamsRespBalanced(IAdamsSurvivedBalancedWA))./BetaAdamsRespWASim(i,DimXAdamsRespVars) + CogNoiseBalanced(IAdamsSurvivedBalancedWA);
    Mu_AdamsResp(IAdamsSurvivedBalancedWB) = (YAdamsRespBalanced(IAdamsSurvivedBalancedWB) - XBAdamsRespBalanced(IAdamsSurvivedBalancedWB))./BetaAdamsRespWBSim(i,DimXAdamsRespVars) + CogNoiseBalanced(IAdamsSurvivedBalancedWB);
    Mu_AdamsResp(IAdamsSurvivedBalancedWC) = (YAdamsRespBalanced(IAdamsSurvivedBalancedWC) - XBAdamsRespBalanced(IAdamsSurvivedBalancedWC))./BetaAdamsRespWCSim(i,DimXAdamsRespVars) + CogNoiseBalanced(IAdamsSurvivedBalancedWC);
    Mu_AdamsResp(IAdamsSurvivedBalancedWD) = (YAdamsRespBalanced(IAdamsSurvivedBalancedWD) - XBAdamsRespBalanced(IAdamsSurvivedBalancedWD))./BetaAdamsRespWDSim(i,DimXAdamsRespVars) + CogNoiseBalanced(IAdamsSurvivedBalancedWD);

    % The posterior distribution
    TT = T_Prior + T_DataAll + T_DataSelf1 + T_DataSelf2 + T_DataSelf3 + T_DataSelf4 + T_DataProxy1 + T_DataProxy2 + T_DataMisAll + T_DataMisSelf1 + T_DataMisSelf2 + T_DataMisSelf3 + T_DataMisSelf4 + T_DataMisProxy2 + T_ProxySel + T_AdamsTimeWA + T_AdamsTimeWB + T_AdamsTimeWC + T_AdamsTimeWD + T_AdamsResp;
    MC = (T_Prior.*Mu_Prior + T_DataAll.*Mu_DataAll + T_DataSelf1.*Mu_DataSelf1 + T_DataSelf2.*Mu_DataSelf2 + T_DataSelf3.*Mu_DataSelf3 + T_DataSelf4.*Mu_DataSelf4 + T_DataProxy1.*Mu_DataProxy1 + T_DataProxy2.*Mu_DataProxy2 + T_DataMisAll.*Mu_DataMisAll + T_DataMisSelf1.*Mu_DataMisSelf1 + T_DataMisSelf2.*Mu_DataMisSelf2 + T_DataMisSelf3.*Mu_DataMisSelf3 + T_DataMisSelf4.*Mu_DataMisSelf4 + T_DataMisProxy2.*Mu_DataMisProxy2 + T_ProxySel.*Mu_ProxySel + T_AdamsTimeWA.*Mu_AdamsTimeWA + T_AdamsTimeWB.*Mu_AdamsTimeWB + T_AdamsTimeWC.*Mu_AdamsTimeWC + T_AdamsTimeWD.*Mu_AdamsTimeWD + T_AdamsResp.*Mu_AdamsResp)./TT;

    % HRS or ADAMS non-respondent
    CogNoiseBalanced(IHRSCoreAdamsNonRespBalanced)  = MC(IHRSCoreAdamsNonRespBalanced)  + randn(NIHRSCoreAdamsNonRespTot,1)./sqrt(TT(IHRSCoreAdamsNonRespBalanced));


    % ADAMS respondent (bounded distribution)
    XBR = XBUCogBalanced(IAdamsRespondentBalanced);
    MCR = MC(IAdamsRespondentBalanced);
    TTR = TT(IAdamsRespondentBalanced);
    Cut1 = 0.5 * erfc((XBR + MCR).*sqrt(TTR)./sqrt(2));
    Cut2 = 0.5 * erfc((-1 + XBR + MCR).*sqrt(TTR)./sqrt(2));

    Rands = zeros(NAdamsRespondentTot,1);
    Rands(DementedAdams) = rand(NTotDemented,1).*Cut1(DementedAdams);
    Rands(CindAdams)     = Cut1(CindAdams)    + rand(NTotCind,1).*(Cut2(CindAdams)-Cut1(CindAdams));
    Rands(NormalcAdams)  = Cut2(NormalcAdams) + rand(NTotNormalc,1).*(1-Cut2(NormalcAdams));

    Rands(Rands==0) = 0.00000001;
    Rands(Rands==1) = 0.99999999;

    CogNoiseBalanced(IAdamsRespondentBalanced) = MCR - sqrt(2)*erfcinv(2*Rands)./sqrt(TTR);

    % Storing the cognition values
    CogNoiseBalanced(~IHRSAllBalanced) = 0;
    CogSimBalanced = XBUCogBalanced + CogNoiseBalanced;
    CogSimBalanced(~IHRSAllBalanced) = 0;
    CogSimWide     = reshape(CogSimBalanced,NSizet,NSizex)';
    [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsSelf2Core, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore] = X1VarsUpdate1(X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsSelf2Core, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore, WaveDummies, WaveDummiesCore, WaveDummiesProxy, WaveDummiesSelf, CogSimBalanced, IProxyCoreBalanced, ISelfCoreBalanced, IHRSCoreBalanced);

    XBProxyCore     = X1ProxyCore*BetaProxySim(i,:)';
    XBCogAllCore    = X1VarsAllCore*BetaYAllSim(i,:)';
    XBCogSelf1Core  = X1VarsSelfCore *BetaYSelf1Sim(i,:)';
    XBCogSelf2Core  = X1VarsSelf2Core*BetaYSelf2Sim(i,:)';
    XBCogSelf3Core  = X1VarsSelfCore *BetaYSelf3Sim(i,:)';
    XBCogSelf4Core  = X1VarsSelfCore *BetaYSelf4Sim(i,:)';
    XBCogProxy1Core = X1VarsProxyCore*BetaYProxy1Sim(i,:)';
    XBCogProxy2Core = X1VarsProxyCore*BetaYProxy2Sim(i,:)';
    
    %Overwriting WA cognition
    CogWABalanced = MyXSecMax(CogSimBalanced(IAdamsSelectedBalancedWA,:),IAdamsSelectedBalancedWA,NSize,NSizex,NSizet);
    
    %%% Step 10: Drawing the precision terms
    % linear cognition scores available in all interviews
    ThetaYAllSim(i) = MyBayesTheta(YCogAllCore(:,1)-XBCogAllCore(:,1),A0,B0,NTotHRSCore);
    
    % linear self-interview
    ThetaYSelf1Sim(i) = MyBayesTheta(YCogSelf1Core(:,1)-XBCogSelf1Core(:,1),A0,B0,NTotSelfCore);
    ThetaYSelf2Sim(i) = MyBayesTheta(YCogSelf2Core(:,1)-XBCogSelf2Core(:,1),A0,B0,NTotSelfCore);
    ThetaYSelf3Sim(i) = MyBayesTheta(YCogSelf3Core(:,1)-XBCogSelf3Core(:,1),A0,B0,NTotSelfCore);
    ThetaYSelf4Sim(i) = MyBayesTheta(YCogSelf4Core(:,1)-XBCogSelf4Core(:,1),A0,B0,NTotSelfCore);
    
    % linear proxy interview
    ThetaYProxy1Sim(i) = MyBayesTheta(YCogProxy1Core(:,1)-XBCogProxy1Core(:,1),A0,B0,NTotProxyCore);
    ThetaYProxy2Sim(i) = MyBayesTheta(YCogProxy2Core(:,1)-XBCogProxy2Core(:,1),A0,B0,NTotProxyCore);
    
    % The random effects terms
    ResidM   = [U0Sim, U1Sim]*CholInvVarU';
    ResidM2  = sum(ResidM.^2,2);
    
    VarUCand = wishrnd(VarU/PropScaleVarU,PropScaleVarU);
    
    DetVarUCand     = det(VarUCand);
    InvVarUCand     = inv(VarUCand);
    CholInvVarUCand = chol(InvVarUCand);
    CholVarUCand    = chol(VarUCand);
    ResidMCand   = [U0Sim, U1Sim]*CholInvVarUCand';
    ResidM2Cand  = sum(ResidMCand.^2,2);

    ShapeSim_Part1 = exp(FNormSim(:,1)*LnGammaShapeSim(i,DimXSurv-1) + FNormSim(:,2)*LnGammaShapeSim(i,DimXSurv));
    SurvRestSim = (exp(XHRSSurv1(:,1:DimXSurv-2)*LnGammaShapeSim(i,1:DimXSurv-2)')/GammaScaleSim(i).*(exp(AgeWide(:,1)*GammaScaleSim(i)) - 1))';
    S1 = sum(QuadWeightsSX.*exp( - ShapeSim_Part1 * SurvRestSim))';

    FNormCand = NormSim*CholVarUCand;
    ShapeSim_Part1 = exp(FNormCand(:,1)*LnGammaShapeSim(i,DimXSurv-1) + FNormCand(:,2)*LnGammaShapeSim(i,DimXSurv));
    S1Cand = sum(QuadWeightsSX.*exp( - ShapeSim_Part1 * SurvRestSim))';

    LnLike     = - 0.5*ResidM2     - 0.5*log(DetVarU)     - log(S1);
    LnLikeCand = - 0.5*ResidM2Cand - 0.5*log(DetVarUCand) - log(S1Cand);

    LnPrior     = - 0.5*(A0 + 3)*log(DetVarU)     - 0.5*trace(T02*InvVarU);
    LnPriorCand = - 0.5*(A0 + 3)*log(DetVarUCand) - 0.5*trace(T02*InvVarUCand);
    
    LnQ     = (PropScaleVarU - 0.5)*log(DetVarU)     - 0.5*PropScaleVarU*trace(InvVarUCand*VarU);
    LnQCand = (PropScaleVarU - 0.5)*log(DetVarUCand) - 0.5*PropScaleVarU*trace(InvVarU*VarUCand);

    AcceptVarU(i-1,1) = log(rand) < sum(LnLikeCand - LnLike) + LnQ - LnQCand + LnPriorCand - LnPrior;

    SdCogUSim(i,:)   = SdCogUSim(i-1,:) ;
    CorrCogUSim(i,:) = CorrCogUSim(i-1,:);
    if AcceptVarU(i-1,1)==1
        VarU        = VarUCand;
        DetVarU     = DetVarUCand;
        InvVarU     = InvVarUCand;
        CholInvVarU = CholInvVarUCand;
        
        FNormSim = FNormCand;
        
        SdCogUSim(i,1) = sqrt(VarU(1,1));
        SdCogUSim(i,2) = sqrt(VarU(2,2));
        CorrCogUSim(i,1) = VarU(1,2)/SdCogUSim(i,1)/SdCogUSim(i,2);
    end

    %Updating the proposal density
    if (i>100) && (i<BurnedDraws) && (i==floor(i/100)*100)
        if (mean(AcceptVarU(i-100:i,1))<0.2) && (PropScaleVarU<100000)
            PropScaleVarU = PropScaleVarU*1.1;
        elseif (mean(AcceptVarU(i-100:i,1))>0.4) && (PropScaleVarU>10)
            PropScaleVarU = PropScaleVarU/1.1;
        end
    end  
    
    % Noise in cognition
    ThetaCogMSim(i) = MyBayesTheta(CogNoiseBalanced(IHRSAllBalanced),A0,B0,NTotHRS);
    
    %Adams WA interview timing
    XAdamsTimeWA1 = [XAdamsTimeWA, CogSimBalanced(IAdamsSelectedShiftedWA,:), CogSimBalanced(IAdamsSelectedShiftedWA).*W6WABalanced(IAdamsSelectedBalancedWA)];
    ThetaAdamsTimeWASim(i) = MyBayesTheta(IWTimeAdamsWA - XAdamsTimeWA1*BetaAdamsTimeWASim(i,:)',A0,B0,NAdamsWA);
    
    %Adams WB interview timing
    XAdamsTimeWB1 = [XAdamsTimeWB, CogWABalanced(IAdamsSelectedBalancedWB,:), CogWABalanced(IAdamsSelectedBalancedWB).*W6WABalanced(IAdamsSelectedBalancedWB)];
    ThetaAdamsTimeWBSim(i) = MyBayesTheta(IWTimeAdamsWB - XAdamsTimeWB1*BetaAdamsTimeWBSim(i,:)',A0,B0,NAdamsWB);
    
    %Adams WC interview timing
    XAdamsTimeWC1 = [XAdamsTimeWC, CogWABalanced(IAdamsSelectedBalancedWC,:), CogWABalanced(IAdamsSelectedBalancedWC).*W6WABalanced(IAdamsSelectedBalancedWC)];
    ThetaAdamsTimeWCSim(i) = MyBayesTheta(IWTimeAdamsWC - XAdamsTimeWC1*BetaAdamsTimeWCSim(i,:)',A0,B0,NAdamsWC);
    
    %Adams WD interview timing
    XAdamsTimeWD1 = [XAdamsTimeWD, CogWABalanced(IAdamsSelectedBalancedWD,:), CogWABalanced(IAdamsSelectedBalancedWD).*W6WABalanced(IAdamsSelectedBalancedWD)];
    ThetaAdamsTimeWDSim(i) = MyBayesTheta(IWTimeAdamsWD - XAdamsTimeWD1*BetaAdamsTimeWDSim(i,:)',A0,B0,NAdamsWD);
    
    
    %%% Step 10: Drawing the missing covariates
    CogSimWideNetU = CogSimWide - U0WideSim - U1WideSim.*AgeCentWide;
    
    %%% Race
    % Distribution
    TotPost  = B0 + NSizex;
    OutPosts = zeros(DimXRace+1,1);
    Gs       = zeros(DimXRace+1,1);
    for j=1:DimXRace
        OutPosts(j,1) = A0 + sum(XRaceWide(:,1)==j);
        Gs(j) = randg(OutPosts(j,1))./TotPost;
    end
    OutPosts(DimXRace+1,1) = A0 + sum(XRaceWide(:,1)==0);
    Gs(DimXRace+1) = randg(OutPosts(DimXRace+1,1))./TotPost;
    for j=1:DimXRace
        PRaceSim(i,j)= Gs(j)/sum(Gs);
    end
    
    %Drawing the missing values: The missing values affect many outcomes (HRS scores, cognition, proxy, survival)
    [X1VarsProxyBalancedMis, X1VarsSelfBalancedMis, X1VarsSelf2BalancedMis, X1VarsMisProxyBalancedMis, X1VarsMisSelfBalancedMis, X1VarsMisSelf2BalancedMis, X1VarsMisSelf4BalancedMis, X1ProxyBalancedMis, XCogBalancedMis] = GetMissings(X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XCogBalanced, MisXRaceBalanced);
    LnLikesYAll    = LnLikesMisX(X1VarsProxyBalancedMis, BetaYAllSim(i,:)   , YCogAllWide   , XRaceWide, ThetaYAllSim(i)   , IHRSCoreWide  , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf1  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf1Sim(i,:) , YCogSelf1Wide , XRaceWide, ThetaYSelf1Sim(i) , ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf2  = LnLikesMisX(X1VarsSelf2BalancedMis, BetaYSelf2Sim(i,:) , YCogSelf2Wide , XRaceWide, ThetaYSelf2Sim(i) , ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf3  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf3Sim(i,:) , YCogSelf3Wide , XRaceWide, ThetaYSelf3Sim(i) , ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf4  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf4Sim(i,:) , YCogSelf4Wide , XRaceWide, ThetaYSelf4Sim(i) , ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYProxy1 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy1Sim(i,:), YCogProxy1Wide, XRaceWide, ThetaYProxy1Sim(i), IProxyCoreWide, MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYProxy2 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy2Sim(i,:), YCogProxy2Wide, XRaceWide, ThetaYProxy2Sim(i), IProxyCoreWide, MisXRace, DimXRace, 3, NMisXRace, NSizet);
    
    LnLikesYAllMis    = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYAllMisSim(i,:)   , YCogAllMisWide   , XRaceWide, 1, IHRSCoreWide  , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf1Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf1MisSim(i,:) , YCogSelf1MisWide , XRaceWide, 1, ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf2Mis  = LnLikesMisX(X1VarsMisSelf2BalancedMis, BetaYSelf2MisSim(i,:) , YCogSelf2MisWide , XRaceWide, 1, ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf3Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf3MisSim(i,:) , YCogSelf3MisWide , XRaceWide, 1, ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYSelf4Mis  = LnLikesMisX(X1VarsMisSelf4BalancedMis , BetaYSelf4MisSim(i,:) , YCogSelf4MisWide , XRaceWide, 1, ISelfCoreWide , MisXRace, DimXRace, 3, NMisXRace, NSizet);
    LnLikesYProxy2Mis = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYProxy2MisSim(i,:), YCogProxy2MisWide, XRaceWide, 1, IProxyCoreWide, MisXRace, DimXRace, 3, NMisXRace, NSizet);
    
    LnLikesIProxy    = LnLikesMisX(X1ProxyBalancedMis, BetaProxySim(i,:)   , YProxySimWide   , XRaceWide, 1   , IHRSCoreWide  , MisXRace, DimXRace, 3, NMisXRace, NSizet);

    LnLikesCog = LnLikesMisXInter(XCogBalancedMis, BetaCogSim(i,:), CogSimWideNetU, XRaceWide, XBirthYearWide, ThetaCogMSim(i), IHRSAllWide, MisXRace, DimXRace, 3, 17, NMisXRace, NSizet);

    LnLikesSurv = LnLikesMisXSurv(LnGammaShapeSim(i,:), DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleSim(i), LnGammaShape, XRace, XBirthYear, MisXRace, DimXRace, 3, 15, NMisXRace);
    
    TotLnPostProb = zeros(NMisXRace,DimXRace+1);
    for j=1:DimXRace
        TotLnPostProb(:,j) = LnLikesYAll(:,j) + LnLikesYSelf1(:,j) + LnLikesYSelf2(:,j) + LnLikesYSelf3(:,j) + LnLikesYSelf4(:,j) + LnLikesYProxy1(:,j) + LnLikesYProxy2(:,j) + LnLikesYAllMis(:,j) + LnLikesYSelf1Mis(:,j) + LnLikesYSelf2Mis(:,j) + LnLikesYSelf3Mis(:,j) + LnLikesYSelf4Mis(:,j) + LnLikesYProxy2Mis(:,j) + LnLikesIProxy(:,j) + LnLikesCog(:,j) + LnLikesSurv(:,j) + log(PRaceSim(i,j));
    end
    TotLnPostProb(:,DimXRace+1) = LnLikesYAll(:,DimXRace+1) + LnLikesYSelf1(:,DimXRace+1) + LnLikesYSelf2(:,DimXRace+1) + LnLikesYSelf3(:,DimXRace+1) + LnLikesYSelf4(:,DimXRace+1) + LnLikesYProxy1(:,DimXRace+1) + LnLikesYProxy2(:,DimXRace+1) + LnLikesYAllMis(:,DimXRace+1) + LnLikesYSelf1Mis(:,DimXRace+1) + LnLikesYSelf2Mis(:,DimXRace+1) + LnLikesYSelf3Mis(:,DimXRace+1) + LnLikesYSelf4Mis(:,DimXRace+1) + LnLikesYProxy2Mis(:,DimXRace+1) + LnLikesIProxy(:,DimXRace+1) + LnLikesCog(:,DimXRace+1) + LnLikesSurv(:,DimXRace+1) + log(1-sum(PRaceSim(i,:),2));

    PostProbDiffs = zeros(NMisXRace,DimXRace);
    for j=1:DimXRace
        PostProbDiffs(:,j) = exp(TotLnPostProb(:,j) - TotLnPostProb(:,DimXRace+1));
    end
    PostProbDiffs(PostProbDiffs>realmax/10) = realmax/10;
    PosteriorProbs = zeros(NMisXRace,DimXRace+1);
    PosteriorProbs(:,DimXRace+1) = ones(NMisXRace,1)./(1 + sum(PostProbDiffs,2));
    for j=1:DimXRace
        PosteriorProbs(:,j) = PostProbDiffs(:,j).*PosteriorProbs(:,DimXRace+1);
    end
    PosteriorProbEdges = cumsum([zeros(NMisXRace,1),PosteriorProbs],2)';
    Rands = ones(DimXRace+1,1)*rand(1,NMisXRace);
    [J,~] = find(Rands>PosteriorProbEdges(1:DimXRace+1,:) & Rands<PosteriorProbEdges(2:DimXRace+2,:));
    J(J==DimXRace+1)=0;
    XRace(MisXRace) = J;
    XRaceWide(MisXRace,:) = J*ones(1,NSizet);
    XRaceBalanced = reshape(XRaceWide',NSize,1);
    [XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv] = XVarsUpdate(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv, XRaceBalanced, XRace, XBirthYearBalanced, XBirthYear, MisXRaceBalanced, MisXRace, 3, 17, 15);
    [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1] = X1VarsUpdate2(XVarsBalanced, XHRSSurv, MisXRaceBalanced, MisXRace, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1);
    LnGammaShape = XHRSSurv1*LnGammaShapeSim(i,:)';
    
    %%% Education
    % Distribution
    TotPost  = B0 + NSizex;
    OutPosts = zeros(DimXEduc+1,1);
    Gs       = zeros(DimXEduc+1,1);
    for j=1:DimXEduc
        OutPosts(j,1) = A0 + sum(XEducWide(:,1)==j);
        Gs(j) = randg(OutPosts(j,1))./TotPost;
    end
    OutPosts(DimXEduc+1,1) = A0 + sum(XEducWide(:,1)==0);
    Gs(DimXEduc+1) = randg(OutPosts(DimXEduc+1,1))./TotPost;
    for j=1:DimXEduc
        PEducSim(i,j)= Gs(j)/sum(Gs);
    end
    
    %Drawing the missing values: The missing values affect many outcomes (HRS scores, cognition, proxy, survival)
    [X1VarsProxyBalancedMis, X1VarsSelfBalancedMis, X1VarsSelf2BalancedMis, X1VarsMisProxyBalancedMis, X1VarsMisSelfBalancedMis, X1VarsMisSelf2BalancedMis, X1VarsMisSelf4BalancedMis, X1ProxyBalancedMis, XCogBalancedMis] = GetMissings(X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XCogBalanced, MisXEducBalanced);
    LnLikesYAll    = LnLikesMisX(X1VarsProxyBalancedMis, BetaYAllSim(i,:)   , YCogAllWide   , XEducWide, ThetaYAllSim(i)   , IHRSCoreWide  , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf1  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf1Sim(i,:) , YCogSelf1Wide , XEducWide, ThetaYSelf1Sim(i) , ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf2  = LnLikesMisX(X1VarsSelf2BalancedMis, BetaYSelf2Sim(i,:) , YCogSelf2Wide , XEducWide, ThetaYSelf2Sim(i) , ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf3  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf3Sim(i,:) , YCogSelf3Wide , XEducWide, ThetaYSelf3Sim(i) , ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf4  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf4Sim(i,:) , YCogSelf4Wide , XEducWide, ThetaYSelf4Sim(i) , ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYProxy1 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy1Sim(i,:), YCogProxy1Wide, XEducWide, ThetaYProxy1Sim(i), IProxyCoreWide, MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYProxy2 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy2Sim(i,:), YCogProxy2Wide, XEducWide, ThetaYProxy2Sim(i), IProxyCoreWide, MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    
    LnLikesYAllMis    = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYAllMisSim(i,:)   , YCogAllMisWide   , XEducWide, 1, IHRSCoreWide  , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf1Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf1MisSim(i,:) , YCogSelf1MisWide , XEducWide, 1, ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf2Mis  = LnLikesMisX(X1VarsMisSelf2BalancedMis, BetaYSelf2MisSim(i,:) , YCogSelf2MisWide , XEducWide, 1, ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf3Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf3MisSim(i,:) , YCogSelf3MisWide , XEducWide, 1, ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYSelf4Mis  = LnLikesMisX(X1VarsMisSelf4BalancedMis , BetaYSelf4MisSim(i,:) , YCogSelf4MisWide , XEducWide, 1, ISelfCoreWide , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    LnLikesYProxy2Mis = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYProxy2MisSim(i,:), YCogProxy2MisWide, XEducWide, 1, IProxyCoreWide, MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);
    
    LnLikesIProxy    = LnLikesMisX(X1ProxyBalancedMis, BetaProxySim(i,:)   , YProxySimWide   , XEducWide, 1   , IHRSCoreWide  , MisXEduc, DimXEduc, 6, NMisXEduc, NSizet);

    LnLikesCog = LnLikesMisXInter(XCogBalancedMis, BetaCogSim(i,:), CogSimWideNetU, XEducWide, XBirthYearWide, ThetaCogMSim(i), IHRSAllWide, MisXEduc, DimXEduc, 6, 20, NMisXEduc, NSizet);

    LnLikesSurv = LnLikesMisXSurv(LnGammaShapeSim(i,:), DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleSim(i), LnGammaShape, XEduc, XBirthYear, MisXEduc, DimXEduc, 6, 18, NMisXEduc);
    
    TotLnPostProb = zeros(NMisXEduc,DimXEduc+1);
    for j=1:DimXEduc
        TotLnPostProb(:,j) = LnLikesYAll(:,j) + LnLikesYSelf1(:,j) + LnLikesYSelf2(:,j) + LnLikesYSelf3(:,j) + LnLikesYSelf4(:,j) + LnLikesYProxy1(:,j) + LnLikesYProxy2(:,j) + LnLikesYAllMis(:,j) + LnLikesYSelf1Mis(:,j) + LnLikesYSelf2Mis(:,j) + LnLikesYSelf3Mis(:,j) + LnLikesYSelf4Mis(:,j) + LnLikesYProxy2Mis(:,j) + LnLikesIProxy(:,j) + LnLikesCog(:,j) + LnLikesSurv(:,j) + log(PEducSim(i,j));
    end
    TotLnPostProb(:,DimXEduc+1) = LnLikesYAll(:,DimXEduc+1) + LnLikesYSelf1(:,DimXEduc+1) + LnLikesYSelf2(:,DimXEduc+1) + LnLikesYSelf3(:,DimXEduc+1) + LnLikesYSelf4(:,DimXEduc+1) + LnLikesYProxy1(:,DimXEduc+1) + LnLikesYProxy2(:,DimXEduc+1) + LnLikesYAllMis(:,DimXEduc+1) + LnLikesYSelf1Mis(:,DimXEduc+1) + LnLikesYSelf2Mis(:,DimXEduc+1) + LnLikesYSelf3Mis(:,DimXEduc+1) + LnLikesYSelf4Mis(:,DimXEduc+1) + LnLikesYProxy2Mis(:,DimXEduc+1) + LnLikesIProxy(:,DimXEduc+1) + LnLikesCog(:,DimXEduc+1) + LnLikesSurv(:,DimXEduc+1) + log(1-sum(PEducSim(i,:),2));

    PostProbDiffs = zeros(NMisXEduc,DimXEduc);
    for j=1:DimXEduc
        PostProbDiffs(:,j) = exp(TotLnPostProb(:,j) - TotLnPostProb(:,DimXEduc+1));
    end
    PostProbDiffs(PostProbDiffs>realmax/10) = realmax/10;
    PosteriorProbs = zeros(NMisXEduc,DimXEduc+1);
    PosteriorProbs(:,DimXEduc+1) = ones(NMisXEduc,1)./(1 + sum(PostProbDiffs,2));
    for j=1:DimXEduc
        PosteriorProbs(:,j) = PostProbDiffs(:,j).*PosteriorProbs(:,DimXEduc+1);
    end
    PosteriorProbEdges = cumsum([zeros(NMisXEduc,1),PosteriorProbs],2)';
    Rands = ones(DimXEduc+1,1)*rand(1,NMisXEduc);
    [J,~] = find(Rands>PosteriorProbEdges(1:DimXEduc+1,:) & Rands<PosteriorProbEdges(2:DimXEduc+2,:));
    J(J==DimXEduc+1)=0;
    XEduc(MisXEduc) = J;
    XEducWide(MisXEduc,:) = J*ones(1,NSizet);
    XEducBalanced = reshape(XEducWide',NSize,1);
    [XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv] = XVarsUpdate(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv, XEducBalanced, XEduc, XBirthYearBalanced, XBirthYear, MisXEducBalanced, MisXEduc, 6, 20, 18);
    [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1] = X1VarsUpdate2(XVarsBalanced, XHRSSurv, MisXEducBalanced, MisXEduc, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1);
    LnGammaShape = XHRSSurv1*LnGammaShapeSim(i,:)';
    
    %%% Foreign born
    % Distribution
    TotPost  = B0 + NSizex;
    OutPosts = zeros(2,1);
    Gs       = zeros(2,1);
    OutPosts(1,1) = A0 + sum(XForbornWide(:,1)==1);
    Gs(1) = randg(OutPosts(1,1))./TotPost;
    OutPosts(2,1) = A0 + sum(XForbornWide(:,1)==0);
    Gs(2) = randg(OutPosts(2,1))./TotPost;
    PForbornSim(i,1)= Gs(1)/sum(Gs);
    
    %Drawing the missing values: The missing values affect many outcomes (HRS scores, cognition, proxy, survival)
    [X1VarsProxyBalancedMis, X1VarsSelfBalancedMis, X1VarsSelf2BalancedMis, X1VarsMisProxyBalancedMis, X1VarsMisSelfBalancedMis, X1VarsMisSelf2BalancedMis, X1VarsMisSelf4BalancedMis, X1ProxyBalancedMis, XCogBalancedMis] = GetMissings(X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XCogBalanced, MisXForbornBalanced);
    LnLikesYAll    = LnLikesMisX(X1VarsProxyBalancedMis, BetaYAllSim(i,:)   , YCogAllWide   , XForbornWide, ThetaYAllSim(i)   , IHRSCoreWide  , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf1  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf1Sim(i,:) , YCogSelf1Wide , XForbornWide, ThetaYSelf1Sim(i) , ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf2  = LnLikesMisX(X1VarsSelf2BalancedMis, BetaYSelf2Sim(i,:) , YCogSelf2Wide , XForbornWide, ThetaYSelf2Sim(i) , ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf3  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf3Sim(i,:) , YCogSelf3Wide , XForbornWide, ThetaYSelf3Sim(i) , ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf4  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf4Sim(i,:) , YCogSelf4Wide , XForbornWide, ThetaYSelf4Sim(i) , ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYProxy1 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy1Sim(i,:), YCogProxy1Wide, XForbornWide, ThetaYProxy1Sim(i), IProxyCoreWide, MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYProxy2 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy2Sim(i,:), YCogProxy2Wide, XForbornWide, ThetaYProxy2Sim(i), IProxyCoreWide, MisXForborn, 1, 9, NMisXForborn, NSizet);
    
    LnLikesYAllMis    = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYAllMisSim(i,:)   , YCogAllMisWide   , XForbornWide, 1, IHRSCoreWide  , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf1Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf1MisSim(i,:) , YCogSelf1MisWide , XForbornWide, 1, ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf2Mis  = LnLikesMisX(X1VarsMisSelf2BalancedMis, BetaYSelf2MisSim(i,:) , YCogSelf2MisWide , XForbornWide, 1, ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf3Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf3MisSim(i,:) , YCogSelf3MisWide , XForbornWide, 1, ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYSelf4Mis  = LnLikesMisX(X1VarsMisSelf4BalancedMis, BetaYSelf4MisSim(i,:) , YCogSelf4MisWide , XForbornWide, 1, ISelfCoreWide , MisXForborn, 1, 9, NMisXForborn, NSizet);
    LnLikesYProxy2Mis = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYProxy2MisSim(i,:), YCogProxy2MisWide, XForbornWide, 1, IProxyCoreWide, MisXForborn, 1, 9, NMisXForborn, NSizet);
    
    LnLikesIProxy    = LnLikesMisX(X1ProxyBalancedMis, BetaProxySim(i,:)   , YProxySimWide   , XForbornWide, 1   , IHRSCoreWide  , MisXForborn, 1, 9, NMisXForborn, NSizet);

    LnLikesCog = LnLikesMisXInter(XCogBalancedMis, BetaCogSim(i,:), CogSimWideNetU, XForbornWide, XBirthYearWide, ThetaCogMSim(i), IHRSAllWide, MisXForborn, 1, 9, 23, NMisXForborn, NSizet);

    LnLikesSurv = LnLikesMisXSurv(LnGammaShapeSim(i,:), DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleSim(i), LnGammaShape, XForborn, XBirthYear, MisXForborn, 1, 9, 21, NMisXForborn);
    
    TotLnPostProb = zeros(NMisXForborn,2);
    TotLnPostProb(:,1) = LnLikesYAll(:,1) + LnLikesYSelf1(:,1) + LnLikesYSelf2(:,1) + LnLikesYSelf3(:,1) + LnLikesYSelf4(:,1) + LnLikesYProxy1(:,1) + LnLikesYProxy2(:,1) + LnLikesYAllMis(:,1) + LnLikesYSelf1Mis(:,1) + LnLikesYSelf2Mis(:,1) + LnLikesYSelf3Mis(:,1) + LnLikesYSelf4Mis(:,1) + LnLikesYProxy2Mis(:,1) + LnLikesIProxy(:,1) + LnLikesCog(:,1) + LnLikesSurv(:,1) + log(PForbornSim(i,1));
    TotLnPostProb(:,2) = LnLikesYAll(:,2) + LnLikesYSelf1(:,2) + LnLikesYSelf2(:,2) + LnLikesYSelf3(:,2) + LnLikesYSelf4(:,2) + LnLikesYProxy1(:,2) + LnLikesYProxy2(:,2) + LnLikesYAllMis(:,2) + LnLikesYSelf1Mis(:,2) + LnLikesYSelf2Mis(:,2) + LnLikesYSelf3Mis(:,2) + LnLikesYSelf4Mis(:,2) + LnLikesYProxy2Mis(:,2) + LnLikesIProxy(:,2) + LnLikesCog(:,2) + LnLikesSurv(:,2) + log(1-PForbornSim(i,1));

    PostProbDiffs = exp(TotLnPostProb(:,1) - TotLnPostProb(:,2));
    PostProbDiffs(PostProbDiffs>realmax/10) = realmax/10;
    PosteriorProbs = zeros(NMisXForborn,2);
    PosteriorProbs(:,2) = ones(NMisXForborn,1)./(1 + PostProbDiffs);
    PosteriorProbs(:,1) = PostProbDiffs.*PosteriorProbs(:,2);
    PosteriorProbEdges = cumsum([zeros(NMisXForborn,1),PosteriorProbs],2)';
    Rands = ones(2,1)*rand(1,NMisXForborn);
    [J,~] = find(Rands>PosteriorProbEdges(1:2,:) & Rands<PosteriorProbEdges(2:3,:));
    J(J==2)=0;
    XForborn(MisXForborn) = J;
    XForbornWide(MisXForborn,:) = J*ones(1,NSizet);
    XForbornBalanced = reshape(XForbornWide',NSize,1);
    [XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv] = XVarsUpdate(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv, XForbornBalanced, XForborn, XBirthYearBalanced, XBirthYear, MisXForbornBalanced, MisXForborn, 9, 23, 21);
    [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1] = X1VarsUpdate2(XVarsBalanced, XHRSSurv, MisXForbornBalanced, MisXForborn, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1);
    LnGammaShape = XHRSSurv1*LnGammaShapeSim(i,:)';

    %%% Social Security income
    % Distribution
    TotPost  = B0 + NSizex;
    OutPosts = zeros(DimXHssc+1,1);
    Gs       = zeros(DimXHssc+1,1);
    for j=1:DimXHssc
        OutPosts(j,1) = A0 + sum(XHsscWide(:,1)==j);
        Gs(j) = randg(OutPosts(j,1))./TotPost;
    end
    OutPosts(DimXHssc+1,1) = A0 + sum(XHsscWide(:,1)==0);
    Gs(DimXHssc+1) = randg(OutPosts(DimXHssc+1,1))./TotPost;
    for j=1:DimXHssc
        PHsscSim(i,j)= Gs(j)/sum(Gs);
    end
    
    %Drawing the missing values: The missing values affect many outcomes (HRS scores, cognition, proxy, survival)
    [X1VarsProxyBalancedMis, X1VarsSelfBalancedMis, X1VarsSelf2BalancedMis, X1VarsMisProxyBalancedMis, X1VarsMisSelfBalancedMis, X1VarsMisSelf2BalancedMis, X1VarsMisSelf4BalancedMis, X1ProxyBalancedMis, XCogBalancedMis] = GetMissings(X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XCogBalanced, MisXHsscBalanced);
    LnLikesYAll    = LnLikesMisX(X1VarsProxyBalancedMis, BetaYAllSim(i,:)   , YCogAllWide   , XHsscWide, ThetaYAllSim(i)   , IHRSCoreWide  , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf1  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf1Sim(i,:) , YCogSelf1Wide , XHsscWide, ThetaYSelf1Sim(i) , ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf2  = LnLikesMisX(X1VarsSelf2BalancedMis, BetaYSelf2Sim(i,:) , YCogSelf2Wide , XHsscWide, ThetaYSelf2Sim(i) , ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf3  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf3Sim(i,:) , YCogSelf3Wide , XHsscWide, ThetaYSelf3Sim(i) , ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf4  = LnLikesMisX(X1VarsSelfBalancedMis , BetaYSelf4Sim(i,:) , YCogSelf4Wide , XHsscWide, ThetaYSelf4Sim(i) , ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYProxy1 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy1Sim(i,:), YCogProxy1Wide, XHsscWide, ThetaYProxy1Sim(i), IProxyCoreWide, MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYProxy2 = LnLikesMisX(X1VarsProxyBalancedMis, BetaYProxy2Sim(i,:), YCogProxy2Wide, XHsscWide, ThetaYProxy2Sim(i), IProxyCoreWide, MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    
    LnLikesYAllMis    = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYAllMisSim(i,:)   , YCogAllMisWide   , XHsscWide, 1, IHRSCoreWide  , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf1Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf1MisSim(i,:) , YCogSelf1MisWide , XHsscWide, 1, ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf2Mis  = LnLikesMisX(X1VarsMisSelf2BalancedMis, BetaYSelf2MisSim(i,:) , YCogSelf2MisWide , XHsscWide, 1, ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf3Mis  = LnLikesMisX(X1VarsMisSelfBalancedMis , BetaYSelf3MisSim(i,:) , YCogSelf3MisWide , XHsscWide, 1, ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYSelf4Mis  = LnLikesMisX(X1VarsMisSelf4BalancedMis , BetaYSelf4MisSim(i,:), YCogSelf4MisWide , XHsscWide, 1, ISelfCoreWide , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    LnLikesYProxy2Mis = LnLikesMisX(X1VarsMisProxyBalancedMis, BetaYProxy2MisSim(i,:), YCogProxy2MisWide, XHsscWide, 1, IProxyCoreWide, MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);
    
    LnLikesIProxy    = LnLikesMisX(X1ProxyBalancedMis, BetaProxySim(i,:)   , YProxySimWide   , XHsscWide, 1   , IHRSCoreWide  , MisXHssc, DimXHssc, 10, NMisXHssc, NSizet);

    LnLikesCog = LnLikesMisXInter(XCogBalancedMis, BetaCogSim(i,:), CogSimWideNetU, XHsscWide, XBirthYearWide, ThetaCogMSim(i), IHRSAllWide, MisXHssc, DimXHssc, 10, 24, NMisXHssc, NSizet);

    LnLikesSurv = LnLikesMisXSurv(LnGammaShapeSim(i,:), DeathAgeX, DeathAgeX_min, DeathAgeX_max, DeadX, AgeWide(:,1), GammaScaleSim(i), LnGammaShape, XHssc, XBirthYear, MisXHssc, DimXHssc, 10, 22, NMisXHssc);
    
    TotLnPostProb = zeros(NMisXHssc,DimXHssc+1);
    for j=1:DimXHssc
        TotLnPostProb(:,j) = LnLikesYAll(:,j) + LnLikesYSelf1(:,j) + LnLikesYSelf2(:,j) + LnLikesYSelf3(:,j) + LnLikesYSelf4(:,j) + LnLikesYProxy1(:,j) + LnLikesYProxy2(:,j) + LnLikesYAllMis(:,j) + LnLikesYSelf1Mis(:,j) + LnLikesYSelf2Mis(:,j) + LnLikesYSelf3Mis(:,j) + LnLikesYSelf4Mis(:,j) + LnLikesYProxy2Mis(:,j) + LnLikesIProxy(:,j) + LnLikesCog(:,j) + LnLikesSurv(:,j) + log(PHsscSim(i,j));
    end
    TotLnPostProb(:,DimXHssc+1) = LnLikesYAll(:,DimXHssc+1) + LnLikesYSelf1(:,DimXHssc+1) + LnLikesYSelf2(:,DimXHssc+1) + LnLikesYSelf3(:,DimXHssc+1) + LnLikesYSelf4(:,DimXHssc+1) + LnLikesYProxy1(:,DimXHssc+1) + LnLikesYProxy2(:,DimXHssc+1) + LnLikesYAllMis(:,DimXHssc+1) + LnLikesYSelf1Mis(:,DimXHssc+1) + LnLikesYSelf2Mis(:,DimXHssc+1) + LnLikesYSelf3Mis(:,DimXHssc+1) + LnLikesYSelf4Mis(:,DimXHssc+1) + LnLikesYProxy2Mis(:,DimXHssc+1) + LnLikesIProxy(:,DimXHssc+1) + LnLikesCog(:,DimXHssc+1) + LnLikesSurv(:,DimXHssc+1) + log(1-sum(PHsscSim(i,:),2));

    PostProbDiffs = zeros(NMisXHssc,DimXHssc);
    for j=1:DimXHssc
        PostProbDiffs(:,j) = exp(TotLnPostProb(:,j) - TotLnPostProb(:,DimXHssc+1));
    end
    PostProbDiffs(PostProbDiffs>realmax/10) = realmax/10;
    PosteriorProbs = zeros(NMisXHssc,DimXHssc+1);
    PosteriorProbs(:,DimXHssc+1) = ones(NMisXHssc,1)./(1 + sum(PostProbDiffs,2));
    for j=1:DimXHssc
        PosteriorProbs(:,j) = PostProbDiffs(:,j).*PosteriorProbs(:,DimXHssc+1);
    end
    PosteriorProbEdges = cumsum([zeros(NMisXHssc,1),PosteriorProbs],2)';
    Rands = ones(DimXHssc+1,1)*rand(1,NMisXHssc);
    [J,~] = find(Rands>PosteriorProbEdges(1:DimXHssc+1,:) & Rands<PosteriorProbEdges(2:DimXHssc+2,:));
    J(J==DimXHssc+1)=0;
    XHssc(MisXHssc) = J;
    XHsscWide(MisXHssc,:) = J*ones(1,NSizet);
    XHsscBalanced = reshape(XHsscWide',NSize,1);
    [XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv] = XVarsUpdate(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv, XHsscBalanced, XHssc, XBirthYearBalanced, XBirthYear, MisXHsscBalanced, MisXHssc, 10, 24, 22);
    [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1] = X1VarsUpdate2(XVarsBalanced, XHRSSurv, MisXHsscBalanced, MisXHssc, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1);
    LnGammaShape = XHRSSurv1*LnGammaShapeSim(i,:)';
    GammaShape   = exp(LnGammaShape);
    
    %%% Marital status
    % Drawing the baseline probability
    Out0Post = A0 + sum(XSingleWide(:,1)==0);
    Out1Post = A0 + sum(XSingleWide(:,1)==1);
    G0 = randg(Out0Post)./TotPostX;
    G1 = randg(Out1Post)./TotPostX;
    PSingleSim(i,1)= G1/(G1 + G0);
    
    % Drawing the rate of change (n = lamda01 + lamda10) using the Metropolis-Hastings algorithm
    lnnCand = log(PSingleSim(i-1,2)) + randn(1,1)*PropPSingleSim(1,1);
    nCand   = exp(lnnCand);
    
    XSingleBalanced00 = XSingleBalanced(Ind1T1HRSAllBalanced)==0 & XSingleBalanced(Ind2THRSAllBalanced)==0;
    XSingleBalanced01 = XSingleBalanced(Ind1T1HRSAllBalanced)==0 & XSingleBalanced(Ind2THRSAllBalanced)==1;
    XSingleBalanced10 = XSingleBalanced(Ind1T1HRSAllBalanced)==1 & XSingleBalanced(Ind2THRSAllBalanced)==0;
    XSingleBalanced11 = XSingleBalanced(Ind1T1HRSAllBalanced)==1 & XSingleBalanced(Ind2THRSAllBalanced)==1;
    
    DAgeXBalanced = AgeBalanced(Ind2THRSAllBalanced) - AgeBalanced(Ind1T1HRSAllBalanced);
    DAgeLong00 = DAgeXBalanced(XSingleBalanced00);
    DAgeLong01 = DAgeXBalanced(XSingleBalanced01);
    DAgeLong10 = DAgeXBalanced(XSingleBalanced10);
    DAgeLong11 = DAgeXBalanced(XSingleBalanced11);
    
    T1Sim00  = (1 - exp(-PSingleSim(i-1,2)*DAgeLong00));
    T1Sim01  = (1 - exp(-PSingleSim(i-1,2)*DAgeLong01));
    T1Sim10  = (1 - exp(-PSingleSim(i-1,2)*DAgeLong10));
    T1Sim11  = (1 - exp(-PSingleSim(i-1,2)*DAgeLong11));
    LnLike00 = log(1 - PSingleSim(i-1,3)*T1Sim00);
    LnLike01 = log(PSingleSim(i-1,3)*T1Sim01);
    LnLike10 = log((1-PSingleSim(i-1,3))*T1Sim10);
    LnLike11 = log(1 - (1-PSingleSim(i-1,3))*T1Sim11);

    T1Cand00 = (1 - exp(-nCand*DAgeLong00));
    T1Cand01 = (1 - exp(-nCand*DAgeLong01));
    T1Cand10 = (1 - exp(-nCand*DAgeLong10));
    T1Cand11 = (1 - exp(-nCand*DAgeLong11));
    
    LnLikeCand00 = log(1 - PSingleSim(i-1,3)*T1Cand00);
    LnLikeCand01 = log(PSingleSim(i-1,3)*T1Cand01);
    LnLikeCand10 = log((1-PSingleSim(i-1,3))*T1Cand10);
    LnLikeCand11 = log(1 - (1-PSingleSim(i-1,3))*T1Cand11);
    
    LnPrior     = - log(PSingleSim(i-1,2))^2/2*Tau0;
    LnPriorCand = - lnnCand^2/2*Tau0;
    
    AcceptPSingleSim(i-1,1) = log(rand) < sum(LnLikeCand01 - LnLike01) + sum(LnLikeCand00 - LnLike00) + sum(LnLikeCand10 - LnLike10) + sum(LnLikeCand11 - LnLike11) + LnPriorCand - LnPrior;
    
    PSingleSim(i,2) =PSingleSim(i-1,2);
    if AcceptPSingleSim(i-1,1)==1
        PSingleSim(i,2) = nCand;
        T1Sim00 = T1Cand00;
        T1Sim01 = T1Cand01;
        T1Sim10 = T1Cand10;
        T1Sim11 = T1Cand11;
        LnLike01 = LnLikeCand01;
        LnLike00 = LnLikeCand00;
        LnLike10 = LnLikeCand10;
        LnLike11 = LnLikeCand11;
    end
   
     %Updating the proposal density
    if (i>100) && (i<BurnedDraws) && (i==floor(i/100)*100)
        PropPSingleSim(1,1) = ProposalDensityUpdate(PropPSingleSim(1,1),mean(AcceptPSingleSim(i-100:i,1)));
    end
    
    % Drawing the ratio of married-> single changes (lamda01/(lamda01 + lamda10)) using the Metropolis-Hastings algorithm
    invalphaCand = -sqrt(2)*erfcinv(2*PSingleSim(i-1,3)) + randn(1,1)*PropPSingleSim(1,2);
    alphaCand = 0.5 * erfc(-invalphaCand/sqrt(2));
       
    LnLikeCand00 = log(1-alphaCand*T1Sim00);
    LnLikeCand01 = log(alphaCand*T1Sim01);
    LnLikeCand10 = log((1-alphaCand)*T1Sim10);
    LnLikeCand11 = log(1-(1-alphaCand)*T1Sim11);
    
    LnPrior     = - erfcinv(2*PSingleSim(i-1,3))^2*Tau0;
    LnPriorCand = - invalphaCand^2/2*Tau0;
    
    AcceptPSingleSim(i-1,2) = log(rand) < sum(LnLikeCand01 - LnLike01) + sum(LnLikeCand00 - LnLike00) + sum(LnLikeCand10 - LnLike10) + sum(LnLikeCand11 - LnLike11) + LnPriorCand - LnPrior;
    
    PSingleSim(i,3) = PSingleSim(i-1,3);
    if AcceptPSingleSim(i-1,2)==1
        PSingleSim(i,3) = alphaCand;
    end
    
    %Updating the proposal density
    if (i>100) && (i<BurnedDraws) && (i==floor(i/100)*100)
        PropPSingleSim(1,2) = ProposalDensityUpdate(PropPSingleSim(1,2),mean(AcceptPSingleSim(i-100:i,2)));
    end
    
    % Missing value in period 1
    DAgeWide = AgeWide(:,2:NSizet)-AgeWide(:,1:NSizet-1);
    P01Sim =  PSingleSim(i,3   )*(1 - exp(-PSingleSim(i,2)*DAgeWide));
    P10Sim = (1-PSingleSim(i,3))*(1 - exp(-PSingleSim(i,2)*DAgeWide));
    
    % The likelihood
    XBCogAllBalanced       = X1VarsProxyBalanced*BetaYAllSim(i,:)';
    XBCogSelf1Balanced     = X1VarsSelfBalanced*BetaYSelf1Sim(i,:)';
    XBCogSelf2Balanced     = X1VarsSelf2Balanced*BetaYSelf2Sim(i,:)';
    XBCogSelf3Balanced     = X1VarsSelfBalanced*BetaYSelf3Sim(i,:)';
    XBCogSelf4Balanced     = X1VarsSelfBalanced*BetaYSelf4Sim(i,:)';
    XBCogProxy1Balanced    = X1VarsProxyBalanced*BetaYProxy1Sim(i,:)';
    XBCogProxy2Balanced    = X1VarsProxyBalanced*BetaYProxy2Sim(i,:)';
    XBCogMisAllBalanced    = X1VarsMisProxyBalanced*BetaYAllMisSim(i,:)';
    XBCogMisSelf1Balanced  = X1VarsMisSelfBalanced*BetaYSelf1MisSim(i,:)';
    XBCogMisSelf2Balanced  = X1VarsMisSelf2Balanced*BetaYSelf2MisSim(i,:)';
    XBCogMisSelf3Balanced  = X1VarsMisSelfBalanced*BetaYSelf3MisSim(i,:)';
    XBCogMisSelf4Balanced  = X1VarsMisSelf4Balanced*BetaYSelf4MisSim(i,:)';
    XBCogMisProxy2Balanced = X1VarsMisProxyBalanced*BetaYProxy2MisSim(i,:)';
    XBProxyBalanced        = X1ProxyBalanced*BetaProxySim(i,:)';
    XBCogBalanced          = XCogBalanced*BetaCogSim(i,:)';
    
    XBCogAllWide       = reshape(XBCogAllBalanced,NSizet,NSizex)';
    XBCogSelf1Wide     = reshape(XBCogSelf1Balanced,NSizet,NSizex)';
    XBCogSelf2Wide     = reshape(XBCogSelf2Balanced,NSizet,NSizex)';
    XBCogSelf3Wide     = reshape(XBCogSelf3Balanced,NSizet,NSizex)';
    XBCogSelf4Wide     = reshape(XBCogSelf4Balanced,NSizet,NSizex)';
    XBCogProxy1Wide    = reshape(XBCogProxy1Balanced,NSizet,NSizex)';
    XBCogProxy2Wide    = reshape(XBCogProxy2Balanced,NSizet,NSizex)';
    XBCogMisAllWide    = reshape(XBCogMisAllBalanced,NSizet,NSizex)';
    XBCogMisSelf1Wide  = reshape(XBCogMisSelf1Balanced,NSizet,NSizex)';
    XBCogMisSelf2Wide  = reshape(XBCogMisSelf2Balanced,NSizet,NSizex)';
    XBCogMisSelf3Wide  = reshape(XBCogMisSelf3Balanced,NSizet,NSizex)';
    XBCogMisSelf4Wide  = reshape(XBCogMisSelf4Balanced,NSizet,NSizex)';
    XBCogMisProxy2Wide = reshape(XBCogMisProxy2Balanced,NSizet,NSizex)';
    XBProxyWide        = reshape(XBProxyBalanced,NSizet,NSizex)';
    XBCogWide          = reshape(XBCogBalanced,NSizet,NSizex)';
    
    [LikesYAll_0   , LikesYAll_1   ] = LnLikesMisXT(MisXSingleWide(:,1), IHRSCoreWide(:,1)  , YCogAllWide(:,1)   , XBCogAllWide(:,1)   , XSingleWide(:,1), ThetaYAllSim(i)   , BetaYAllSim(i,13));
    [LikesYSelf1_0 , LikesYSelf1_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf1Wide(:,1) , XBCogSelf1Wide(:,1) , XSingleWide(:,1), ThetaYSelf1Sim(i) , BetaYSelf1Sim(i,13));
    [LikesYSelf2_0 , LikesYSelf2_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf2Wide(:,1) , XBCogSelf2Wide(:,1) , XSingleWide(:,1), ThetaYSelf2Sim(i) , BetaYSelf2Sim(i,13));
    [LikesYSelf3_0 , LikesYSelf3_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf3Wide(:,1) , XBCogSelf3Wide(:,1) , XSingleWide(:,1), ThetaYSelf3Sim(i) , BetaYSelf3Sim(i,13));
    [LikesYSelf4_0 , LikesYSelf4_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf4Wide(:,1) , XBCogSelf4Wide(:,1) , XSingleWide(:,1), ThetaYSelf4Sim(i) , BetaYSelf4Sim(i,13));
    [LikesYProxy1_0, LikesYProxy1_1] = LnLikesMisXT(MisXSingleWide(:,1), IProxyCoreWide(:,1), YCogProxy1Wide(:,1), XBCogProxy1Wide(:,1), XSingleWide(:,1), ThetaYProxy1Sim(i), BetaYProxy1Sim(i,13));
    [LikesYProxy2_0, LikesYProxy2_1] = LnLikesMisXT(MisXSingleWide(:,1), IProxyCoreWide(:,1), YCogProxy2Wide(:,1), XBCogProxy2Wide(:,1), XSingleWide(:,1), ThetaYProxy2Sim(i), BetaYProxy2Sim(i,13));
   
    [LikesYMisAll_0   , LikesYMisAll_1   ] = LnLikesMisXT(MisXSingleWide(:,1), IHRSCoreWide(:,1)  , YCogAllMisWide(:,1)   , XBCogMisAllWide(:,1)   , XSingleWide(:,1), 1, BetaYAllMisSim(i,13));
    [LikesYMisSelf1_0 , LikesYMisSelf1_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf1MisWide(:,1) , XBCogMisSelf1Wide(:,1) , XSingleWide(:,1), 1, BetaYSelf1MisSim(i,13));
    [LikesYMisSelf2_0 , LikesYMisSelf2_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf2MisWide(:,1) , XBCogMisSelf2Wide(:,1) , XSingleWide(:,1), 1, BetaYSelf2MisSim(i,13));
    [LikesYMisSelf3_0 , LikesYMisSelf3_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf3MisWide(:,1) , XBCogMisSelf3Wide(:,1) , XSingleWide(:,1), 1, BetaYSelf3MisSim(i,13));
    [LikesYMisSelf4_0 , LikesYMisSelf4_1 ] = LnLikesMisXT(MisXSingleWide(:,1), ISelfCoreWide(:,1) , YCogSelf4MisWide(:,1) , XBCogMisSelf4Wide(:,1) , XSingleWide(:,1), 1, BetaYSelf4MisSim(i,13));
    [LikesYMisProxy2_0, LikesYMisProxy2_1] = LnLikesMisXT(MisXSingleWide(:,1), IProxyCoreWide(:,1), YCogProxy2MisWide(:,1), XBCogMisProxy2Wide(:,1), XSingleWide(:,1), 1, BetaYProxy2MisSim(i,13));

    [LikesIProxy_0, LikesIProxy_1] = LnLikesMisXT(MisXSingleWide(:,1), IHRSCoreWide(:,1), YProxySimWide(:,1), XBProxyWide(:,1), XSingleWide(:,1), 1, BetaProxySim(i,13));
    
    [LikesCog_0, LikesCog_1] = LnLikesMisXTInt(MisXSingleWide(:,1), IHRSAllWide(:,1), CogSimWideNetU(:,1), XBCogWide(:,1), XSingleWide(:,1), ThetaCogMSim(i), BetaCogSim(i,13), BetaCogSim(i,27), XBirthYear);

    Likes_1 = LikesYAll_1.*LikesYSelf1_1.*LikesYSelf2_1.*LikesYSelf3_1.*LikesYSelf4_1.*LikesYProxy1_1.*LikesYProxy2_1.*LikesYMisAll_1.*LikesYMisSelf1_1.*LikesYMisSelf2_1.*LikesYMisSelf3_1.*LikesYMisSelf4_1.*LikesYMisProxy2_1.*LikesIProxy_1.*LikesCog_1;
    Likes_0 = LikesYAll_0.*LikesYSelf1_0.*LikesYSelf2_0.*LikesYSelf3_0.*LikesYSelf4_0.*LikesYProxy1_0.*LikesYProxy2_0.*LikesYMisAll_0.*LikesYMisSelf1_0.*LikesYMisSelf2_0.*LikesYMisSelf3_0.*LikesYMisSelf4_0.*LikesYMisProxy2_0.*LikesIProxy_0.*LikesCog_0;
    
    %prior & posterior if the value at t=2 is zero
    p01 = P01Sim(MisXSingleWide(:,1),1);
    p10 = P10Sim(MisXSingleWide(:,1),1);
    PP1 = Likes_1.*p10*PSingleSim(i,1);
    PP0 = Likes_0.*(1-p01)*(1-PSingleSim(i,1));
    Posterior1 = PP1 ./ (PP0 + PP1);
    indcase    = XSingleWide(:,2)==0 & IHRSAllWide(:,2)==1;
    indcaseMis = indcase(MisXSingleWide(:,1));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XSingleWide(MisXSingleWide(:,1) & indcase, 1) = value;  
    end
    
    %prior & posterior if the value at t=2 is one
    PP1 = Likes_1.*(1-p10)*PSingleSim(i,1);
    PP0 = Likes_0.*p01*(1-PSingleSim(i,1));
    Posterior1 = PP1 ./ (PP0 + PP1);
    indcase    = XSingleWide(:,2)==1 & IHRSAllWide(:,2)==1;
    indcaseMis = indcase(MisXSingleWide(:,1));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XSingleWide(MisXSingleWide(:,1) & indcase, 1) = value;    
    end
    
    %prior & posterior if the value at t=2 is missing
    PP1 = Likes_1.*PSingleSim(i,1);
    PP0 = Likes_0.*(1-PSingleSim(i,1));
    Posterior1 = PP1 ./ (PP0 + PP1);
    indcase    = IHRSAllWide(:,2)==0;
    indcaseMis = indcase(MisXSingleWide(:,1));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XSingleWide(MisXSingleWide(:,1) & indcase, 1) = value;  
    end
    
    %Period 2:T-1
    for t = 2:NSizet-1
        % The likelihood
        [LikesYAll_0   , LikesYAll_1   ] = LnLikesMisXT(MisXSingleWide(:,t), IHRSCoreWide(:,t)  , YCogAllWide(:,t)   , XBCogAllWide(:,t)   , XSingleWide(:,t), ThetaYAllSim(i)   , BetaYAllSim(i,13));
        [LikesYSelf1_0 , LikesYSelf1_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf1Wide(:,t) , XBCogSelf1Wide(:,t) , XSingleWide(:,t), ThetaYSelf1Sim(i) , BetaYSelf1Sim(i,13));
        [LikesYSelf2_0 , LikesYSelf2_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf2Wide(:,t) , XBCogSelf2Wide(:,t) , XSingleWide(:,t), ThetaYSelf2Sim(i) , BetaYSelf2Sim(i,13));
        [LikesYSelf3_0 , LikesYSelf3_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf3Wide(:,t) , XBCogSelf3Wide(:,t) , XSingleWide(:,t), ThetaYSelf3Sim(i) , BetaYSelf3Sim(i,13));
        [LikesYSelf4_0 , LikesYSelf4_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf4Wide(:,t) , XBCogSelf4Wide(:,t) , XSingleWide(:,t), ThetaYSelf4Sim(i) , BetaYSelf4Sim(i,13));
        [LikesYProxy1_0, LikesYProxy1_1] = LnLikesMisXT(MisXSingleWide(:,t), IProxyCoreWide(:,t), YCogProxy1Wide(:,t), XBCogProxy1Wide(:,t), XSingleWide(:,t), ThetaYProxy1Sim(i), BetaYProxy1Sim(i,13));
        [LikesYProxy2_0, LikesYProxy2_1] = LnLikesMisXT(MisXSingleWide(:,t), IProxyCoreWide(:,t), YCogProxy2Wide(:,t), XBCogProxy2Wide(:,t), XSingleWide(:,t), ThetaYProxy2Sim(i), BetaYProxy2Sim(i,13));

        [LikesYMisAll_0   , LikesYMisAll_1   ] = LnLikesMisXT(MisXSingleWide(:,t), IHRSCoreWide(:,t)  , YCogAllMisWide(:,t)   , XBCogMisAllWide(:,t)   , XSingleWide(:,t), 1, BetaYAllMisSim(i,13));
        [LikesYMisSelf1_0 , LikesYMisSelf1_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf1MisWide(:,t) , XBCogMisSelf1Wide(:,t) , XSingleWide(:,t), 1, BetaYSelf1MisSim(i,13));
        [LikesYMisSelf2_0 , LikesYMisSelf2_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf2MisWide(:,t) , XBCogMisSelf2Wide(:,t) , XSingleWide(:,t), 1, BetaYSelf2MisSim(i,13));
        [LikesYMisSelf3_0 , LikesYMisSelf3_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf3MisWide(:,t) , XBCogMisSelf3Wide(:,t) , XSingleWide(:,t), 1, BetaYSelf3MisSim(i,13));
        [LikesYMisSelf4_0 , LikesYMisSelf4_1 ] = LnLikesMisXT(MisXSingleWide(:,t), ISelfCoreWide(:,t) , YCogSelf4MisWide(:,t) , XBCogMisSelf4Wide(:,t) , XSingleWide(:,t), 1, BetaYSelf4MisSim(i,13));
        [LikesYMisProxy2_0, LikesYMisProxy2_1] = LnLikesMisXT(MisXSingleWide(:,t), IProxyCoreWide(:,t), YCogProxy2MisWide(:,t), XBCogMisProxy2Wide(:,t), XSingleWide(:,t), 1, BetaYProxy2MisSim(i,13));

        [LikesIProxy_0, LikesIProxy_1] = LnLikesMisXT(MisXSingleWide(:,t), IHRSCoreWide(:,t), YProxySimWide(:,t), XBProxyWide(:,t), XSingleWide(:,t), 1, BetaProxySim(i,13));

        [LikesCog_0, LikesCog_1] = LnLikesMisXTInt(MisXSingleWide(:,t), IHRSAllWide(:,t), CogSimWideNetU(:,t), XBCogWide(:,t), XSingleWide(:,t), ThetaCogMSim(i), BetaCogSim(i,13), BetaCogSim(i,27), XBirthYear);

        Likes_1 = LikesYAll_1.*LikesYSelf1_1.*LikesYSelf2_1.*LikesYSelf3_1.*LikesYSelf4_1.*LikesYProxy1_1.*LikesYProxy2_1.*LikesYMisAll_1.*LikesYMisSelf1_1.*LikesYMisSelf2_1.*LikesYMisSelf3_1.*LikesYMisSelf4_1.*LikesYMisProxy2_1.*LikesIProxy_1.*LikesCog_1;
        Likes_0 = LikesYAll_0.*LikesYSelf1_0.*LikesYSelf2_0.*LikesYSelf3_0.*LikesYSelf4_0.*LikesYProxy1_0.*LikesYProxy2_0.*LikesYMisAll_0.*LikesYMisSelf1_0.*LikesYMisSelf2_0.*LikesYMisSelf3_0.*LikesYMisSelf4_0.*LikesYMisProxy2_0.*LikesIProxy_0.*LikesCog_0;

        %prior & posterior if the value at t-1 is zero and the value at t+1 is zero
        p01t1 = P01Sim(MisXSingleWide(:,t),t-1);
        p10t1 = P10Sim(MisXSingleWide(:,t),t-1);
        p01t = P01Sim(MisXSingleWide(:,t),t);
        p10t = P10Sim(MisXSingleWide(:,t),t);
    
        PP1 = Likes_1.*p10t.*p01t1;
        PP0 = Likes_0.*(1-p01t1).*(1-p01t);
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XSingleWide(:,t-1)==0 & XSingleWide(:,t+1)==0 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXSingleWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XSingleWide(MisXSingleWide(:,t) & indcase, t) = value;
        end
    
        %prior & posterior if the value at t-1 is one and the value at t+1 is zero
        PP1 = Likes_1.*p10t.*(1-p10t1);
        PP0 = Likes_0.*(1-p01t).*p10t1;
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XSingleWide(:,t-1)==1 & XSingleWide(:,t+1)==0 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXSingleWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XSingleWide(MisXSingleWide(:,t) & indcase, t) = value;
        end

        %prior & posterior if the value at t-1 is zero and the value at t+1 is one
        PP1 = Likes_1.*(1-p10t).*p01t1;
        PP0 = Likes_0.*p01t.*(1-p01t1);
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XSingleWide(:,t-1)==0 & XSingleWide(:,t+1)==1 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXSingleWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XSingleWide(MisXSingleWide(:,t) & indcase, t) = value;
        end
        
        %prior & posterior if the value at t-1 is one and the value at t+1 is one
        PP1 = Likes_1.*(1-p10t).*(1-p10t1);
        PP0 = Likes_0.*p01t.*p10t1;
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XSingleWide(:,t-1)==1 & XSingleWide(:,t+1)==1 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXSingleWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XSingleWide(MisXSingleWide(:,t) & indcase, t) = value;
        end
        
        %prior & posterior if the value at t-1 is zero and the value at t+1 is missing
        PP1 = Likes_1.*p01t1;
        PP0 = Likes_0.*(1-p01t1);
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XSingleWide(:,t-1)==0 & IHRSAllWide(:,t+1)==0;
        indcaseMis = indcase(MisXSingleWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XSingleWide(MisXSingleWide(:,t) & indcase, t) = value;
        end
        
        %prior & posterior if the value at t-1 is one and the value at t+1 is missing
        PP1 = Likes_1.*(1-p10t1);
        PP0 = Likes_0.*p10t1;
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XSingleWide(:,t-1)==1 & IHRSAllWide(:,t+1)==0;
        indcaseMis = indcase(MisXSingleWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XSingleWide(MisXSingleWide(:,t) & indcase, t) = value;
        end
    end

    %%% Period T
    % The likelihood
    [LikesYAll_0   , LikesYAll_1   ] = LnLikesMisXT(MisXSingleWide(:,NSizet), IHRSCoreWide(:,NSizet)  , YCogAllWide(:,NSizet)   , XBCogAllWide(:,NSizet)   , XSingleWide(:,NSizet), ThetaYAllSim(i)   , BetaYAllSim(i,13));
    [LikesYSelf1_0 , LikesYSelf1_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf1Wide(:,NSizet) , XBCogSelf1Wide(:,NSizet) , XSingleWide(:,NSizet), ThetaYSelf1Sim(i) , BetaYSelf1Sim(i,13));
    [LikesYSelf2_0 , LikesYSelf2_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf2Wide(:,NSizet) , XBCogSelf2Wide(:,NSizet) , XSingleWide(:,NSizet), ThetaYSelf2Sim(i) , BetaYSelf2Sim(i,13));
    [LikesYSelf3_0 , LikesYSelf3_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf3Wide(:,NSizet) , XBCogSelf3Wide(:,NSizet) , XSingleWide(:,NSizet), ThetaYSelf3Sim(i) , BetaYSelf3Sim(i,13));
    [LikesYSelf4_0 , LikesYSelf4_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf4Wide(:,NSizet) , XBCogSelf4Wide(:,NSizet) , XSingleWide(:,NSizet), ThetaYSelf4Sim(i) , BetaYSelf4Sim(i,13));
    [LikesYProxy1_0, LikesYProxy1_1] = LnLikesMisXT(MisXSingleWide(:,NSizet), IProxyCoreWide(:,NSizet), YCogProxy1Wide(:,NSizet), XBCogProxy1Wide(:,NSizet), XSingleWide(:,NSizet), ThetaYProxy1Sim(i), BetaYProxy1Sim(i,13));
    [LikesYProxy2_0, LikesYProxy2_1] = LnLikesMisXT(MisXSingleWide(:,NSizet), IProxyCoreWide(:,NSizet), YCogProxy2Wide(:,NSizet), XBCogProxy2Wide(:,NSizet), XSingleWide(:,NSizet), ThetaYProxy2Sim(i), BetaYProxy2Sim(i,13));

    [LikesYMisAll_0   , LikesYMisAll_1   ] = LnLikesMisXT(MisXSingleWide(:,NSizet), IHRSCoreWide(:,NSizet)  , YCogAllMisWide(:,NSizet)   , XBCogMisAllWide(:,NSizet)   , XSingleWide(:,NSizet), 1, BetaYAllMisSim(i,13));
    [LikesYMisSelf1_0 , LikesYMisSelf1_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf1MisWide(:,NSizet) , XBCogMisSelf1Wide(:,NSizet) , XSingleWide(:,NSizet), 1, BetaYSelf1MisSim(i,13));
    [LikesYMisSelf2_0 , LikesYMisSelf2_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf2MisWide(:,NSizet) , XBCogMisSelf2Wide(:,NSizet) , XSingleWide(:,NSizet), 1, BetaYSelf2MisSim(i,13));
    [LikesYMisSelf3_0 , LikesYMisSelf3_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf3MisWide(:,NSizet) , XBCogMisSelf3Wide(:,NSizet) , XSingleWide(:,NSizet), 1, BetaYSelf3MisSim(i,13));
    [LikesYMisSelf4_0 , LikesYMisSelf4_1 ] = LnLikesMisXT(MisXSingleWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf4MisWide(:,NSizet) , XBCogMisSelf4Wide(:,NSizet) , XSingleWide(:,NSizet), 1, BetaYSelf4MisSim(i,13));
    [LikesYMisProxy2_0, LikesYMisProxy2_1] = LnLikesMisXT(MisXSingleWide(:,NSizet), IProxyCoreWide(:,NSizet), YCogProxy2MisWide(:,NSizet), XBCogMisProxy2Wide(:,NSizet), XSingleWide(:,NSizet), 1, BetaYProxy2MisSim(i,13));

    [LikesIProxy_0, LikesIProxy_1] = LnLikesMisXT(MisXSingleWide(:,NSizet), IHRSCoreWide(:,NSizet), YProxySimWide(:,NSizet), XBProxyWide(:,NSizet), XSingleWide(:,NSizet), 1, BetaProxySim(i,13));

    [LikesCog_0, LikesCog_1] = LnLikesMisXTInt(MisXSingleWide(:,NSizet), IHRSAllWide(:,NSizet), CogSimWideNetU(:,NSizet), XBCogWide(:,NSizet), XSingleWide(:,NSizet), ThetaCogMSim(i), BetaCogSim(i,13), BetaCogSim(i,27), XBirthYear);

    Likes_1 = LikesYAll_1.*LikesYSelf1_1.*LikesYSelf2_1.*LikesYSelf3_1.*LikesYSelf4_1.*LikesYProxy1_1.*LikesYProxy2_1.*LikesYMisAll_1.*LikesYMisSelf1_1.*LikesYMisSelf2_1.*LikesYMisSelf3_1.*LikesYMisSelf4_1.*LikesYMisProxy2_1.*LikesIProxy_1.*LikesCog_1;
    Likes_0 = LikesYAll_0.*LikesYSelf1_0.*LikesYSelf2_0.*LikesYSelf3_0.*LikesYSelf4_0.*LikesYProxy1_0.*LikesYProxy2_0.*LikesYMisAll_0.*LikesYMisSelf1_0.*LikesYMisSelf2_0.*LikesYMisSelf3_0.*LikesYMisSelf4_0.*LikesYMisProxy2_0.*LikesIProxy_0.*LikesCog_0;

 
    %prior & posterior if the value at T-1 is zero
    p01t1 = P01Sim(MisXSingleWide(:,NSizet),NSizet-1);
    p10t1 = P10Sim(MisXSingleWide(:,NSizet),NSizet-1);  
    PP1 = Likes_1.*p01t1;
    PP0 = Likes_0.*(1-p01t1);
    Posterior1     = PP1 ./ (PP0 + PP1);
    indcase = XSingleWide(:,NSizet-1)==0;
    indcaseMis = indcase(MisXSingleWide(:,NSizet));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XSingleWide(MisXSingleWide(:,NSizet) & indcase, NSizet) = value; 
    end
    
    %prior & posterior if the value at T-1 is one
    PP1 = Likes_1.*(1-p10t1);
    PP0 = Likes_0.*p10t1;
    Posterior1     = PP1 ./ (PP0 + PP1);
    indcase = XSingleWide(:,NSizet-1)==1;
    indcaseMis = indcase(MisXSingleWide(:,NSizet));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XSingleWide(MisXSingleWide(:,NSizet) & indcase, NSizet) = value;
    end
    
    %Overwriting the variables dependent on x
    XSingleBalanced = reshape(XSingleWide',NSize,1);
    [XVarsBalanced, XVarsMisBalanced, XCogBalanced] = XVarsUpdate2(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XSingleBalanced, XBirthYearBalanced, MisXSingleBalanced, 13, 27);
    [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced] = X1VarsUpdate3(XVarsBalanced, MisXSingleBalanced, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced);

    
    %%% Having a stroke
    % Drawing the baseline probability
    Out0Post = A0 + sum(XStrokeWide(:,1)==0);
    Out1Post = A0 + sum(XStrokeWide(:,1)==1);
    G0 = randg(Out0Post)./TotPostX;
    G1 = randg(Out1Post)./TotPostX;
    PStrokeSim(i,1)= G1/(G1 + G0);
    
    % Drawing the rate of change (n = lamda01 + lamda10) using the Metropolis-Hastings algorithm
    lnnCand = log(PStrokeSim(i-1,2)) + randn(1,1)*PropPStrokeSim(1,1);
    nCand   = exp(lnnCand);
    
    XStrokeBalanced00 = XStrokeBalanced(Ind1T1HRSAllBalanced)==0 & XStrokeBalanced(Ind2THRSAllBalanced)==0;
    XStrokeBalanced01 = XStrokeBalanced(Ind1T1HRSAllBalanced)==0 & XStrokeBalanced(Ind2THRSAllBalanced)==1;
    XStrokeBalanced10 = XStrokeBalanced(Ind1T1HRSAllBalanced)==1 & XStrokeBalanced(Ind2THRSAllBalanced)==0;
    XStrokeBalanced11 = XStrokeBalanced(Ind1T1HRSAllBalanced)==1 & XStrokeBalanced(Ind2THRSAllBalanced)==1;
    
    DAgeLong00 = DAgeXBalanced(XStrokeBalanced00);
    DAgeLong01 = DAgeXBalanced(XStrokeBalanced01);
    DAgeLong10 = DAgeXBalanced(XStrokeBalanced10);
    DAgeLong11 = DAgeXBalanced(XStrokeBalanced11);
    
    T1Sim00  = (1 - exp(-PStrokeSim(i-1,2)*DAgeLong00));
    T1Sim01  = (1 - exp(-PStrokeSim(i-1,2)*DAgeLong01));
    T1Sim10  = (1 - exp(-PStrokeSim(i-1,2)*DAgeLong10));
    T1Sim11  = (1 - exp(-PStrokeSim(i-1,2)*DAgeLong11));
    LnLike00 = log(1 - PStrokeSim(i-1,3)*T1Sim00);
    LnLike01 = log(PStrokeSim(i-1,3)*T1Sim01);
    LnLike10 = log((1-PStrokeSim(i-1,3))*T1Sim10);
    LnLike11 = log(1 - (1-PStrokeSim(i-1,3))*T1Sim11);

    T1Cand00 = (1 - exp(-nCand*DAgeLong00));
    T1Cand01 = (1 - exp(-nCand*DAgeLong01));
    T1Cand10 = (1 - exp(-nCand*DAgeLong10));
    T1Cand11 = (1 - exp(-nCand*DAgeLong11));
    
    LnLikeCand00 = log(1 - PStrokeSim(i-1,3)*T1Cand00);
    LnLikeCand01 = log(PStrokeSim(i-1,3)*T1Cand01);
    LnLikeCand10 = log((1-PStrokeSim(i-1,3))*T1Cand10);
    LnLikeCand11 = log(1 - (1-PStrokeSim(i-1,3))*T1Cand11);
    
    LnPrior     = - log(PStrokeSim(i-1,2))^2/2*Tau0;
    LnPriorCand = - lnnCand^2/2*Tau0;
    
    AcceptPStrokeSim(i-1,1) = log(rand) < sum(LnLikeCand01 - LnLike01) + sum(LnLikeCand00 - LnLike00) + sum(LnLikeCand10 - LnLike10) + sum(LnLikeCand11 - LnLike11) + LnPriorCand - LnPrior;
    
    PStrokeSim(i,2) =PStrokeSim(i-1,2);
    if AcceptPStrokeSim(i-1,1)==1
        PStrokeSim(i,2) = nCand;
        T1Sim00 = T1Cand00;
        T1Sim01 = T1Cand01;
        T1Sim10 = T1Cand10;
        T1Sim11 = T1Cand11;
        LnLike01 = LnLikeCand01;
        LnLike00 = LnLikeCand00;
        LnLike10 = LnLikeCand10;
        LnLike11 = LnLikeCand11;
    end
   
     %Updating the proposal density
    if (i>100) && (i<BurnedDraws) && (i==floor(i/100)*100)
        PropPStrokeSim(1,1) = ProposalDensityUpdate(PropPStrokeSim(1,1),mean(AcceptPStrokeSim(i-100:i,1)));
    end
    
    % Drawing the ratio of married-> single changes (lamda01/(lamda01 + lamda10)) using the Metropolis-Hastings algorithm
    invalphaCand = -sqrt(2)*erfcinv(2*PStrokeSim(i-1,3)) + randn(1,1)*PropPStrokeSim(1,2);
    alphaCand = 0.5 * erfc(-invalphaCand/sqrt(2));
       
    LnLikeCand00 = log(1-alphaCand*T1Sim00);
    LnLikeCand01 = log(alphaCand*T1Sim01);
    LnLikeCand10 = log((1-alphaCand)*T1Sim10);
    LnLikeCand11 = log(1-(1-alphaCand)*T1Sim11);
    
    LnPrior     = - erfcinv(2*PStrokeSim(i-1,3))^2*Tau0;
    LnPriorCand = - invalphaCand^2/2*Tau0;
    
    AcceptPStrokeSim(i-1,2) = log(rand) < sum(LnLikeCand01 - LnLike01) + sum(LnLikeCand00 - LnLike00) + sum(LnLikeCand10 - LnLike10) + sum(LnLikeCand11 - LnLike11) + LnPriorCand - LnPrior;
    
    PStrokeSim(i,3) = PStrokeSim(i-1,3);
    if AcceptPStrokeSim(i-1,2)==1
        PStrokeSim(i,3) = alphaCand;
    end
    
    %Updating the proposal density
    if (i>100) && (i<BurnedDraws) && (i==floor(i/100)*100)
        PropPStrokeSim(1,2) = ProposalDensityUpdate(PropPStrokeSim(1,2),mean(AcceptPStrokeSim(i-100:i,2)));
    end
    
    % Missing value in period 1
    P01Sim =  PStrokeSim(i,3   )*(1 - exp(-PStrokeSim(i,2)*DAgeWide));
    P10Sim = (1-PStrokeSim(i,3))*(1 - exp(-PStrokeSim(i,2)*DAgeWide));
    
    % The likelihood
    XBCogAllBalanced       = X1VarsProxyBalanced*BetaYAllSim(i,:)';
    XBCogSelf1Balanced     = X1VarsSelfBalanced*BetaYSelf1Sim(i,:)';
    XBCogSelf2Balanced     = X1VarsSelf2Balanced*BetaYSelf2Sim(i,:)';
    XBCogSelf3Balanced     = X1VarsSelfBalanced*BetaYSelf3Sim(i,:)';
    XBCogSelf4Balanced     = X1VarsSelfBalanced*BetaYSelf4Sim(i,:)';
    XBCogProxy1Balanced    = X1VarsProxyBalanced*BetaYProxy1Sim(i,:)';
    XBCogProxy2Balanced    = X1VarsProxyBalanced*BetaYProxy2Sim(i,:)';
    XBCogMisAllBalanced    = X1VarsMisProxyBalanced*BetaYAllMisSim(i,:)';
    XBCogMisSelf1Balanced  = X1VarsMisSelfBalanced*BetaYSelf1MisSim(i,:)';
    XBCogMisSelf2Balanced  = X1VarsMisSelf2Balanced*BetaYSelf2MisSim(i,:)';
    XBCogMisSelf3Balanced  = X1VarsMisSelfBalanced*BetaYSelf3MisSim(i,:)';
    XBCogMisSelf4Balanced  = X1VarsMisSelf4Balanced*BetaYSelf4MisSim(i,:)';
    XBCogMisProxy2Balanced = X1VarsMisProxyBalanced*BetaYProxy2MisSim(i,:)';
    XBProxyBalanced        = X1ProxyBalanced*BetaProxySim(i,:)';
    XBCogBalanced          = XCogBalanced*BetaCogSim(i,:)';
    
    XBCogAllWide       = reshape(XBCogAllBalanced,NSizet,NSizex)';
    XBCogSelf1Wide     = reshape(XBCogSelf1Balanced,NSizet,NSizex)';
    XBCogSelf2Wide     = reshape(XBCogSelf2Balanced,NSizet,NSizex)';
    XBCogSelf3Wide     = reshape(XBCogSelf3Balanced,NSizet,NSizex)';
    XBCogSelf4Wide     = reshape(XBCogSelf4Balanced,NSizet,NSizex)';
    XBCogProxy1Wide    = reshape(XBCogProxy1Balanced,NSizet,NSizex)';
    XBCogProxy2Wide    = reshape(XBCogProxy2Balanced,NSizet,NSizex)';
    XBCogMisAllWide    = reshape(XBCogMisAllBalanced,NSizet,NSizex)';
    XBCogMisSelf1Wide  = reshape(XBCogMisSelf1Balanced,NSizet,NSizex)';
    XBCogMisSelf2Wide  = reshape(XBCogMisSelf2Balanced,NSizet,NSizex)';
    XBCogMisSelf3Wide  = reshape(XBCogMisSelf3Balanced,NSizet,NSizex)';
    XBCogMisSelf4Wide  = reshape(XBCogMisSelf4Balanced,NSizet,NSizex)';
    XBCogMisProxy2Wide = reshape(XBCogMisProxy2Balanced,NSizet,NSizex)';
    XBProxyWide        = reshape(XBProxyBalanced,NSizet,NSizex)';
    XBCogWide          = reshape(XBCogBalanced,NSizet,NSizex)';
    
    [LikesYAll_0   , LikesYAll_1   ] = LnLikesMisXT(MisXStrokeWide(:,1), IHRSCoreWide(:,1)  , YCogAllWide(:,1)   , XBCogAllWide(:,1)   , XStrokeWide(:,1), ThetaYAllSim(i)   , BetaYAllSim(i,14));
    [LikesYSelf1_0 , LikesYSelf1_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf1Wide(:,1) , XBCogSelf1Wide(:,1) , XStrokeWide(:,1), ThetaYSelf1Sim(i) , BetaYSelf1Sim(i,14));
    [LikesYSelf2_0 , LikesYSelf2_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf2Wide(:,1) , XBCogSelf2Wide(:,1) , XStrokeWide(:,1), ThetaYSelf2Sim(i) , BetaYSelf2Sim(i,14));
    [LikesYSelf3_0 , LikesYSelf3_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf3Wide(:,1) , XBCogSelf3Wide(:,1) , XStrokeWide(:,1), ThetaYSelf3Sim(i) , BetaYSelf3Sim(i,14));
    [LikesYSelf4_0 , LikesYSelf4_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf4Wide(:,1) , XBCogSelf4Wide(:,1) , XStrokeWide(:,1), ThetaYSelf4Sim(i) , BetaYSelf4Sim(i,14));
    [LikesYProxy1_0, LikesYProxy1_1] = LnLikesMisXT(MisXStrokeWide(:,1), IProxyCoreWide(:,1), YCogProxy1Wide(:,1), XBCogProxy1Wide(:,1), XStrokeWide(:,1), ThetaYProxy1Sim(i), BetaYProxy1Sim(i,14));
    [LikesYProxy2_0, LikesYProxy2_1] = LnLikesMisXT(MisXStrokeWide(:,1), IProxyCoreWide(:,1), YCogProxy2Wide(:,1), XBCogProxy2Wide(:,1), XStrokeWide(:,1), ThetaYProxy2Sim(i), BetaYProxy2Sim(i,14));
   
    [LikesYMisAll_0   , LikesYMisAll_1   ] = LnLikesMisXT(MisXStrokeWide(:,1), IHRSCoreWide(:,1)  , YCogAllMisWide(:,1)   , XBCogMisAllWide(:,1)   , XStrokeWide(:,1), 1, BetaYAllMisSim(i,14));
    [LikesYMisSelf1_0 , LikesYMisSelf1_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf1MisWide(:,1) , XBCogMisSelf1Wide(:,1) , XStrokeWide(:,1), 1, BetaYSelf1MisSim(i,14));
    [LikesYMisSelf2_0 , LikesYMisSelf2_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf2MisWide(:,1) , XBCogMisSelf2Wide(:,1) , XStrokeWide(:,1), 1, BetaYSelf2MisSim(i,14));
    [LikesYMisSelf3_0 , LikesYMisSelf3_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf3MisWide(:,1) , XBCogMisSelf3Wide(:,1) , XStrokeWide(:,1), 1, BetaYSelf3MisSim(i,14));
    [LikesYMisSelf4_0 , LikesYMisSelf4_1 ] = LnLikesMisXT(MisXStrokeWide(:,1), ISelfCoreWide(:,1) , YCogSelf4MisWide(:,1) , XBCogMisSelf4Wide(:,1) , XStrokeWide(:,1), 1, BetaYSelf4MisSim(i,14));
    [LikesYMisProxy2_0, LikesYMisProxy2_1] = LnLikesMisXT(MisXStrokeWide(:,1), IProxyCoreWide(:,1), YCogProxy2MisWide(:,1), XBCogMisProxy2Wide(:,1), XStrokeWide(:,1), 1, BetaYProxy2MisSim(i,14));

    [LikesIProxy_0, LikesIProxy_1] = LnLikesMisXT(MisXStrokeWide(:,1), IHRSCoreWide(:,1), YProxySimWide(:,1), XBProxyWide(:,1), XStrokeWide(:,1), 1, BetaProxySim(i,14));
    
    [LikesCog_0, LikesCog_1] = LnLikesMisXTInt(MisXStrokeWide(:,1), IHRSAllWide(:,1), CogSimWideNetU(:,1), XBCogWide(:,1), XStrokeWide(:,1), ThetaCogMSim(i), BetaCogSim(i,14), BetaCogSim(i,28), XBirthYear);

    Likes_1 = LikesYAll_1.*LikesYSelf1_1.*LikesYSelf2_1.*LikesYSelf3_1.*LikesYSelf4_1.*LikesYProxy1_1.*LikesYProxy2_1.*LikesYMisAll_1.*LikesYMisSelf1_1.*LikesYMisSelf2_1.*LikesYMisSelf3_1.*LikesYMisSelf4_1.*LikesYMisProxy2_1.*LikesIProxy_1.*LikesCog_1;
    Likes_0 = LikesYAll_0.*LikesYSelf1_0.*LikesYSelf2_0.*LikesYSelf3_0.*LikesYSelf4_0.*LikesYProxy1_0.*LikesYProxy2_0.*LikesYMisAll_0.*LikesYMisSelf1_0.*LikesYMisSelf2_0.*LikesYMisSelf3_0.*LikesYMisSelf4_0.*LikesYMisProxy2_0.*LikesIProxy_0.*LikesCog_0;
    
    %prior & posterior if the value at t=2 is zero
    p01 = P01Sim(MisXStrokeWide(:,1),1);
    p10 = P10Sim(MisXStrokeWide(:,1),1);
    PP1 = Likes_1.*p10*PStrokeSim(i,1);
    PP0 = Likes_0.*(1-p01)*(1-PStrokeSim(i,1));
    Posterior1 = PP1 ./ (PP0 + PP1);
    indcase    = XStrokeWide(:,2)==0 & IHRSAllWide(:,2)==1;
    indcaseMis = indcase(MisXStrokeWide(:,1));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XStrokeWide(MisXStrokeWide(:,1) & indcase, 1) = value;  
    end
    
    %prior & posterior if the value at t=2 is one
    PP1 = Likes_1.*(1-p10)*PStrokeSim(i,1);
    PP0 = Likes_0.*p01*(1-PStrokeSim(i,1));
    Posterior1 = PP1 ./ (PP0 + PP1);
    indcase    = XStrokeWide(:,2)==1 & IHRSAllWide(:,2)==1;
    indcaseMis = indcase(MisXStrokeWide(:,1));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XStrokeWide(MisXStrokeWide(:,1) & indcase, 1) = value;    
    end
    
    %prior & posterior if the value at t=2 is missing
    PP1 = Likes_1.*PStrokeSim(i,1);
    PP0 = Likes_0.*(1-PStrokeSim(i,1));
    Posterior1 = PP1 ./ (PP0 + PP1);
    indcase    = IHRSAllWide(:,2)==0;
    indcaseMis = indcase(MisXStrokeWide(:,1));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XStrokeWide(MisXStrokeWide(:,1) & indcase, 1) = value;  
    end
    
    %Period 2:T-1
    for t = 2:NSizet-1
        % The likelihood
        [LikesYAll_0   , LikesYAll_1   ] = LnLikesMisXT(MisXStrokeWide(:,t), IHRSCoreWide(:,t)  , YCogAllWide(:,t)   , XBCogAllWide(:,t)   , XStrokeWide(:,t), ThetaYAllSim(i)   , BetaYAllSim(i,14));
        [LikesYSelf1_0 , LikesYSelf1_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf1Wide(:,t) , XBCogSelf1Wide(:,t) , XStrokeWide(:,t), ThetaYSelf1Sim(i) , BetaYSelf1Sim(i,14));
        [LikesYSelf2_0 , LikesYSelf2_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf2Wide(:,t) , XBCogSelf2Wide(:,t) , XStrokeWide(:,t), ThetaYSelf2Sim(i) , BetaYSelf2Sim(i,14));
        [LikesYSelf3_0 , LikesYSelf3_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf3Wide(:,t) , XBCogSelf3Wide(:,t) , XStrokeWide(:,t), ThetaYSelf3Sim(i) , BetaYSelf3Sim(i,14));
        [LikesYSelf4_0 , LikesYSelf4_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf4Wide(:,t) , XBCogSelf4Wide(:,t) , XStrokeWide(:,t), ThetaYSelf4Sim(i) , BetaYSelf4Sim(i,14));
        [LikesYProxy1_0, LikesYProxy1_1] = LnLikesMisXT(MisXStrokeWide(:,t), IProxyCoreWide(:,t), YCogProxy1Wide(:,t), XBCogProxy1Wide(:,t), XStrokeWide(:,t), ThetaYProxy1Sim(i), BetaYProxy1Sim(i,14));
        [LikesYProxy2_0, LikesYProxy2_1] = LnLikesMisXT(MisXStrokeWide(:,t), IProxyCoreWide(:,t), YCogProxy2Wide(:,t), XBCogProxy2Wide(:,t), XStrokeWide(:,t), ThetaYProxy2Sim(i), BetaYProxy2Sim(i,14));

        [LikesYMisAll_0   , LikesYMisAll_1   ] = LnLikesMisXT(MisXStrokeWide(:,t), IHRSCoreWide(:,t)  , YCogAllMisWide(:,t)   , XBCogMisAllWide(:,t)   , XStrokeWide(:,t), 1, BetaYAllMisSim(i,14));
        [LikesYMisSelf1_0 , LikesYMisSelf1_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf1MisWide(:,t) , XBCogMisSelf1Wide(:,t) , XStrokeWide(:,t), 1, BetaYSelf1MisSim(i,14));
        [LikesYMisSelf2_0 , LikesYMisSelf2_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf2MisWide(:,t) , XBCogMisSelf2Wide(:,t) , XStrokeWide(:,t), 1, BetaYSelf2MisSim(i,14));
        [LikesYMisSelf3_0 , LikesYMisSelf3_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf3MisWide(:,t) , XBCogMisSelf3Wide(:,t) , XStrokeWide(:,t), 1, BetaYSelf3MisSim(i,14));
        [LikesYMisSelf4_0 , LikesYMisSelf4_1 ] = LnLikesMisXT(MisXStrokeWide(:,t), ISelfCoreWide(:,t) , YCogSelf4MisWide(:,t) , XBCogMisSelf4Wide(:,t) , XStrokeWide(:,t), 1, BetaYSelf4MisSim(i,14));
        [LikesYMisProxy2_0, LikesYMisProxy2_1] = LnLikesMisXT(MisXStrokeWide(:,t), IProxyCoreWide(:,t), YCogProxy2MisWide(:,t), XBCogMisProxy2Wide(:,t), XStrokeWide(:,t), 1, BetaYProxy2MisSim(i,14));

        [LikesIProxy_0, LikesIProxy_1] = LnLikesMisXT(MisXStrokeWide(:,t), IHRSCoreWide(:,t), YProxySimWide(:,t), XBProxyWide(:,t), XStrokeWide(:,t), 1, BetaProxySim(i,14));

        [LikesCog_0, LikesCog_1] = LnLikesMisXTInt(MisXStrokeWide(:,t), IHRSAllWide(:,t), CogSimWideNetU(:,t), XBCogWide(:,t), XStrokeWide(:,t), ThetaCogMSim(i), BetaCogSim(i,14), BetaCogSim(i,28), XBirthYear);

        Likes_1 = LikesYAll_1.*LikesYSelf1_1.*LikesYSelf2_1.*LikesYSelf3_1.*LikesYSelf4_1.*LikesYProxy1_1.*LikesYProxy2_1.*LikesYMisAll_1.*LikesYMisSelf1_1.*LikesYMisSelf2_1.*LikesYMisSelf3_1.*LikesYMisSelf4_1.*LikesYMisProxy2_1.*LikesIProxy_1.*LikesCog_1;
        Likes_0 = LikesYAll_0.*LikesYSelf1_0.*LikesYSelf2_0.*LikesYSelf3_0.*LikesYSelf4_0.*LikesYProxy1_0.*LikesYProxy2_0.*LikesYMisAll_0.*LikesYMisSelf1_0.*LikesYMisSelf2_0.*LikesYMisSelf3_0.*LikesYMisSelf4_0.*LikesYMisProxy2_0.*LikesIProxy_0.*LikesCog_0;

        %prior & posterior if the value at t-1 is zero and the value at t+1 is zero
        p01t1 = P01Sim(MisXStrokeWide(:,t),t-1);
        p10t1 = P10Sim(MisXStrokeWide(:,t),t-1);
        p01t = P01Sim(MisXStrokeWide(:,t),t);
        p10t = P10Sim(MisXStrokeWide(:,t),t);
    
        PP1 = Likes_1.*p10t.*p01t1;
        PP0 = Likes_0.*(1-p01t1).*(1-p01t);
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XStrokeWide(:,t-1)==0 & XStrokeWide(:,t+1)==0 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXStrokeWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XStrokeWide(MisXStrokeWide(:,t) & indcase, t) = value;
        end
    
        %prior & posterior if the value at t-1 is one and the value at t+1 is zero
        PP1 = Likes_1.*p10t.*(1-p10t1);
        PP0 = Likes_0.*(1-p01t).*p10t1;
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XStrokeWide(:,t-1)==1 & XStrokeWide(:,t+1)==0 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXStrokeWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XStrokeWide(MisXStrokeWide(:,t) & indcase, t) = value;
        end

        %prior & posterior if the value at t-1 is zero and the value at t+1 is one
        PP1 = Likes_1.*(1-p10t).*p01t1;
        PP0 = Likes_0.*p01t.*(1-p01t1);
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XStrokeWide(:,t-1)==0 & XStrokeWide(:,t+1)==1 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXStrokeWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XStrokeWide(MisXStrokeWide(:,t) & indcase, t) = value;
        end
        
        %prior & posterior if the value at t-1 is one and the value at t+1 is one
        PP1 = Likes_1.*(1-p10t).*(1-p10t1);
        PP0 = Likes_0.*p01t.*p10t1;
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XStrokeWide(:,t-1)==1 & XStrokeWide(:,t+1)==1 & IHRSAllWide(:,t+1)==1;
        indcaseMis = indcase(MisXStrokeWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XStrokeWide(MisXStrokeWide(:,t) & indcase, t) = value;
        end
        
        %prior & posterior if the value at t-1 is zero and the value at t+1 is missing
        PP1 = Likes_1.*p01t1;
        PP0 = Likes_0.*(1-p01t1);
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XStrokeWide(:,t-1)==0 & IHRSAllWide(:,t+1)==0;
        indcaseMis = indcase(MisXStrokeWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XStrokeWide(MisXStrokeWide(:,t) & indcase, t) = value;
        end
        
        %prior & posterior if the value at t-1 is one and the value at t+1 is missing
        PP1 = Likes_1.*(1-p10t1);
        PP0 = Likes_0.*p10t1;
        Posterior1 = PP1 ./ (PP0 + PP1);
        indcase    = XStrokeWide(:,t-1)==1 & IHRSAllWide(:,t+1)==0;
        indcaseMis = indcase(MisXStrokeWide(:,t));
        sumindcaseMis = sum(indcaseMis);
        if sumindcaseMis>0
            value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
            XStrokeWide(MisXStrokeWide(:,t) & indcase, t) = value;
        end
    end

    %%% Period T
    % The likelihood
    [LikesYAll_0   , LikesYAll_1   ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), IHRSCoreWide(:,NSizet)  , YCogAllWide(:,NSizet)   , XBCogAllWide(:,NSizet)   , XStrokeWide(:,NSizet), ThetaYAllSim(i)   , BetaYAllSim(i,14));
    [LikesYSelf1_0 , LikesYSelf1_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf1Wide(:,NSizet) , XBCogSelf1Wide(:,NSizet) , XStrokeWide(:,NSizet), ThetaYSelf1Sim(i) , BetaYSelf1Sim(i,14));
    [LikesYSelf2_0 , LikesYSelf2_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf2Wide(:,NSizet) , XBCogSelf2Wide(:,NSizet) , XStrokeWide(:,NSizet), ThetaYSelf2Sim(i) , BetaYSelf2Sim(i,14));
    [LikesYSelf3_0 , LikesYSelf3_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf3Wide(:,NSizet) , XBCogSelf3Wide(:,NSizet) , XStrokeWide(:,NSizet), ThetaYSelf3Sim(i) , BetaYSelf3Sim(i,14));
    [LikesYSelf4_0 , LikesYSelf4_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf4Wide(:,NSizet) , XBCogSelf4Wide(:,NSizet) , XStrokeWide(:,NSizet), ThetaYSelf4Sim(i) , BetaYSelf4Sim(i,14));
    [LikesYProxy1_0, LikesYProxy1_1] = LnLikesMisXT(MisXStrokeWide(:,NSizet), IProxyCoreWide(:,NSizet), YCogProxy1Wide(:,NSizet), XBCogProxy1Wide(:,NSizet), XStrokeWide(:,NSizet), ThetaYProxy1Sim(i), BetaYProxy1Sim(i,14));
    [LikesYProxy2_0, LikesYProxy2_1] = LnLikesMisXT(MisXStrokeWide(:,NSizet), IProxyCoreWide(:,NSizet), YCogProxy2Wide(:,NSizet), XBCogProxy2Wide(:,NSizet), XStrokeWide(:,NSizet), ThetaYProxy2Sim(i), BetaYProxy2Sim(i,14));

    [LikesYMisAll_0   , LikesYMisAll_1   ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), IHRSCoreWide(:,NSizet)  , YCogAllMisWide(:,NSizet)   , XBCogMisAllWide(:,NSizet)   , XStrokeWide(:,NSizet), 1, BetaYAllMisSim(i,14));
    [LikesYMisSelf1_0 , LikesYMisSelf1_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf1MisWide(:,NSizet) , XBCogMisSelf1Wide(:,NSizet) , XStrokeWide(:,NSizet), 1, BetaYSelf1MisSim(i,14));
    [LikesYMisSelf2_0 , LikesYMisSelf2_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf2MisWide(:,NSizet) , XBCogMisSelf2Wide(:,NSizet) , XStrokeWide(:,NSizet), 1, BetaYSelf2MisSim(i,14));
    [LikesYMisSelf3_0 , LikesYMisSelf3_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf3MisWide(:,NSizet) , XBCogMisSelf3Wide(:,NSizet) , XStrokeWide(:,NSizet), 1, BetaYSelf3MisSim(i,14));
    [LikesYMisSelf4_0 , LikesYMisSelf4_1 ] = LnLikesMisXT(MisXStrokeWide(:,NSizet), ISelfCoreWide(:,NSizet) , YCogSelf4MisWide(:,NSizet) , XBCogMisSelf4Wide(:,NSizet) , XStrokeWide(:,NSizet), 1, BetaYSelf4MisSim(i,14));
    [LikesYMisProxy2_0, LikesYMisProxy2_1] = LnLikesMisXT(MisXStrokeWide(:,NSizet), IProxyCoreWide(:,NSizet), YCogProxy2MisWide(:,NSizet), XBCogMisProxy2Wide(:,NSizet), XStrokeWide(:,NSizet), 1, BetaYProxy2MisSim(i,14));

    [LikesIProxy_0, LikesIProxy_1] = LnLikesMisXT(MisXStrokeWide(:,NSizet), IHRSCoreWide(:,NSizet), YProxySimWide(:,NSizet), XBProxyWide(:,NSizet), XStrokeWide(:,NSizet), 1, BetaProxySim(i,14));

    [LikesCog_0, LikesCog_1] = LnLikesMisXTInt(MisXStrokeWide(:,NSizet), IHRSAllWide(:,NSizet), CogSimWideNetU(:,NSizet), XBCogWide(:,NSizet), XStrokeWide(:,NSizet), ThetaCogMSim(i), BetaCogSim(i,14), BetaCogSim(i,28), XBirthYear);

    Likes_1 = LikesYAll_1.*LikesYSelf1_1.*LikesYSelf2_1.*LikesYSelf3_1.*LikesYSelf4_1.*LikesYProxy1_1.*LikesYProxy2_1.*LikesYMisAll_1.*LikesYMisSelf1_1.*LikesYMisSelf2_1.*LikesYMisSelf3_1.*LikesYMisSelf4_1.*LikesYMisProxy2_1.*LikesIProxy_1.*LikesCog_1;
    Likes_0 = LikesYAll_0.*LikesYSelf1_0.*LikesYSelf2_0.*LikesYSelf3_0.*LikesYSelf4_0.*LikesYProxy1_0.*LikesYProxy2_0.*LikesYMisAll_0.*LikesYMisSelf1_0.*LikesYMisSelf2_0.*LikesYMisSelf3_0.*LikesYMisSelf4_0.*LikesYMisProxy2_0.*LikesIProxy_0.*LikesCog_0;

 
    %prior & posterior if the value at T-1 is zero
    p01t1 = P01Sim(MisXStrokeWide(:,NSizet),NSizet-1);
    p10t1 = P10Sim(MisXStrokeWide(:,NSizet),NSizet-1);  
    PP1 = Likes_1.*p01t1;
    PP0 = Likes_0.*(1-p01t1);
    Posterior1     = PP1 ./ (PP0 + PP1);
    indcase = XStrokeWide(:,NSizet-1)==0;
    indcaseMis = indcase(MisXStrokeWide(:,NSizet));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XStrokeWide(MisXStrokeWide(:,NSizet) & indcase, NSizet) = value; 
    end
    
    %prior & posterior if the value at T-1 is one
    PP1 = Likes_1.*(1-p10t1);
    PP0 = Likes_0.*p10t1;
    Posterior1     = PP1 ./ (PP0 + PP1);
    indcase = XStrokeWide(:,NSizet-1)==1;
    indcaseMis = indcase(MisXStrokeWide(:,NSizet));
    sumindcaseMis = sum(indcaseMis);
    if sumindcaseMis>0
        value = rand(sumindcaseMis,1) < Posterior1(indcaseMis);
        XStrokeWide(MisXStrokeWide(:,NSizet) & indcase, NSizet) = value;
    end
    
    %Overwriting the variables dependent on x
    XStrokeBalanced = reshape(XStrokeWide',NSize,1);
    [XVarsBalanced, XVarsMisBalanced, XCogBalanced] = XVarsUpdate2(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XStrokeBalanced, XBirthYearBalanced, MisXStrokeBalanced, 14, 28);
    [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore, XHRSSurv1] = X1VarsUpdate4(XVarsBalanced, XHRSSurv, MisXAnyBalanced, MisXAny, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore, XHRSSurv1, IProxyCoreBalanced, ISelfCoreBalanced, IHRSCoreBalanced);
    LnGammaShape = XHRSSurv1*LnGammaShapeSim(i,:)';
    GammaShape   = exp(LnGammaShape);

   
    % Step 11: Imputing cognition at the Deathage grid points
    % Drawing death ages for the missing cases
    GammaShapeAlive = GammaShape(DeadX<0.5);
    SS0 = exp(LnSurvival(DeathAgeAlive_min, Age1Alive, GammaScaleSim(i), GammaShapeAlive));
    SS1 = exp(LnSurvival(DeathAgeAlive_max, Age1Alive, GammaScaleSim(i), GammaShapeAlive));
    rr = SS1 + (SS0 - SS1) .*rand(NHRSAlive,1);
    DeathAgeX(DeadX<0.5) = log(exp(GammaScaleSim(i).*Age1Alive) - log(rr).*GammaScaleSim(i)./GammaShapeAlive)./GammaScaleSim(i);
    
    %Updating the grid
    DeathAgeGrids(DeathMis(DeathObservedX),6) = DeathAgeX(DeathMis);
    DeathAgeGrids(:,5) = DeathAgeGrids(:,6) - 0.05; 
    DeathAgeGrids(:,4) = DeathAgeGrids(:,6) - 0.1; 
    DeathAgeGrids(:,3) = DeathAgeGrids(:,6) - 0.2; 
    DeathAgeGrids(:,2) = DeathAgeGrids(:,6) - 0.3; 
    DeathAgeGrids(:,1) = DeathAgeGrids(:,6) - 0.5; 

    %Simulating cognition
    SingleGridDead = TimeInvarDeadGrid(XSingleWide(DeathObservedX,:), AgeWide(DeathObservedX,:), IHRSAllWide(DeathObservedX,:), DeathAgeGrids, PSingleSim(i,:), NumDeads, NSizet);
    StrokeGridDead = TimeInvarDeadGrid(XStrokeWide(DeathObservedX,:), AgeWide(DeathObservedX,:), IHRSAllWide(DeathObservedX,:), DeathAgeGrids, PStrokeSim(i,:), NumDeads, NSizet);
    XCogDemDead = XCogBalanced(DeathObservedBalanced & IMaxBalanced,1:DimXCogDem);
    CogU0Dead   = U0Sim(DeathObservedX);
    CogU1Dead   = U1Sim(DeathObservedX);
    
    for j=1:6
        CogDeathGrids(:,j) = CogU0Dead + CogU1Dead.*(DeathAgeGrids(:,j) - CenterAge) + randn(NumDeads,1)/sqrt(ThetaCogMSim(i));
        XCogDemDead(:,13) = SingleGridDead(:,j);
        XCogDemDead(:,14) = StrokeGridDead(:,j);
        XCogDemDead(:,27) = SingleGridDead(:,j).*BirthYearDead;
        XCogDemDead(:,28) = StrokeGridDead(:,j).*BirthYearDead;
        XCogAgeDead = [(DeathAgeGrids(:,j) - CenterAge), (DeathAgeGrids(:,j) - CenterAge).^2, (DeathAgeGrids(:,j) - CenterAge).^3];
        
        XCogDead = [XCogDemDead,XCogAgeDead,XCogAgeDead.*(BirthYearDead*ones(1,3))];
        CogDeathGrids(:,j) = CogDeathGrids(:,j) + XCogDead*BetaCogSim(i,:)';
    end
    
    
    % Step 12: Saving some simulation draws
    % Person specific expected vaues of variables: cognition, dementia, and survival
    if i>=BurnedDraws
       CogSimHRS  = CogSimBalanced(IHRSAllBalanced>0.5);
       CogSimHRS0 = CogSimBalanced(IHRSAllBalanced>0.5) - CogNoiseBalanced(IHRSAllBalanced>0.5);
       
       ExpCog  = (ExpCog*(i-BurnedDraws)  + CogSimHRS)/(i-BurnedDraws+1);
       ExpCog2 = (ExpCog2*(i-BurnedDraws) + CogSimHRS.*CogSimHRS)/(i-BurnedDraws+1);
       
       PrDement = (PrDement*(i-BurnedDraws)  + (CogSimHRS<0))/(i-BurnedDraws+1);
       PrCind   = (PrCind*(i-BurnedDraws)    + (CogSimHRS>=0 & CogSimHRS<1))/(i-BurnedDraws+1);
       PrNormal = (PrNormal*(i-BurnedDraws)  + (CogSimHRS>=1))/(i-BurnedDraws+1);     
       
       ExpCog0  = (ExpCog0*(i-BurnedDraws)  + CogSimHRS0)/(i-BurnedDraws+1);
       ExpCog02 = (ExpCog02*(i-BurnedDraws) + CogSimHRS0.*CogSimHRS0)/(i-BurnedDraws+1);
       
       CogResidBalanced = reshape(CogResidWide',NSize,1);
       CogResidHRS  = CogResidBalanced(IHRSAllBalanced>0.5);
       ExpCogR  = (ExpCogR*(i-BurnedDraws)  + CogResidHRS)/(i-BurnedDraws+1);
       ExpCogR2 = (ExpCogR2*(i-BurnedDraws) + CogResidHRS.*CogResidHRS)/(i-BurnedDraws+1);
       
       U0SimHRS = U0BalancedSim(IHRSAllBalanced>0.5);
       ExpCogU0  = (ExpCogU0*(i-BurnedDraws)  + U0SimHRS)/(i-BurnedDraws+1);
       ExpCogU02 = (ExpCogU02*(i-BurnedDraws) + U0SimHRS.*U0SimHRS)/(i-BurnedDraws+1);
       
       U1SimHRS  = U1BalancedSim(IHRSAllBalanced>0.5);
       ExpCogU1  = (ExpCogU1*(i-BurnedDraws)  + U1SimHRS)/(i-BurnedDraws+1);
       ExpCogU12 = (ExpCogU12*(i-BurnedDraws) + U1SimHRS.*U1SimHRS)/(i-BurnedDraws+1);
             
       ExpShape  = (ExpShape*(i-BurnedDraws)  + GammaShape)/(i-BurnedDraws+1);
       ExpShape2 = (ExpShape2*(i-BurnedDraws) + GammaShape.*GammaShape)/(i-BurnedDraws+1);
       
       ExpDeath  = (ExpDeath*(i-BurnedDraws)  + DeathAgeX)/(i-BurnedDraws+1);
       ExpDeath2 = (ExpDeath2*(i-BurnedDraws) + DeathAgeX.*DeathAgeX)/(i-BurnedDraws+1);
       
       ExpCogDead  = (ExpCogDead*(i-BurnedDraws)  + CogDeathGrids)/(i-BurnedDraws+1);
       ExpCogDead2 = (ExpCogDead2*(i-BurnedDraws) + CogDeathGrids.*CogDeathGrids)/(i-BurnedDraws+1); 
       
       PrDementDead = (PrDementDead*(i-BurnedDraws)  + (CogDeathGrids<0))/(i-BurnedDraws+1);   
    end
    
    % Prevalence estimates (Only after burn-in, and using thinning)
    if (i>=BurnedDraws) && (floor(i/PrevThinning)==i/PrevThinning)
        k = (i-BurnedDraws)/PrevThinning + 1;
        DementedBalancedSim = CogSimBalanced<0;
        
        PrevGroupsCompare(k,:) = PrevUpdate(DementedBalancedSim, WeightedIndsCompare, IndPrevsCompare, DimPrevGroupsCompare);
        PrevGroupsGender(k,:)  = PrevUpdate(DementedBalancedSim, WeightedIndsGender , IndPrevsGender , DimPrevGroupsGender);
        PrevGroupsAge(k,:)     = PrevUpdate(DementedBalancedSim, WeightedIndsAge    , IndPrevsAge    , DimPrevGroupsAge);
        PrevGroupsRace(k,:)    = PrevUpdate(DementedBalancedSim, WeightedIndsRace   , IndPrevsRace   , DimPrevGroupsRace);
        PrevGroupsForborn(k,:) = PrevUpdate(DementedBalancedSim, WeightedIndsForborn, IndPrevsForborn, DimPrevGroupsForborn);
        PrevGroupsEduc(k,:)    = PrevUpdate(DementedBalancedSim, WeightedIndsEduc   , IndPrevsEduc   , DimPrevGroupsEduc);
        PrevGroupsHssc(k,:)    = PrevUpdate(DementedBalancedSim, WeightedIndsHssc   , IndPrevsHssc   , DimPrevGroupsHssc);
        
        % Prevalance at death
        DementedDead = CogDeathGrids<0;
        PrevGroupsDead(k,1:DimPrevGroupsDead) = PrevUpdate(DementedDead(:,1), WeightedIndsDead, IndPrevsDead, DimPrevGroupsDead);
        for j=2:6
            PrevGroupsDead(k,(j-1)*DimPrevGroupsDead + 1 : j*DimPrevGroupsDead) = PrevUpdate(DementedDead(:,j), WeightedIndsDead, IndPrevsDead, DimPrevGroupsDead);
        end
    end
    
    % Individual cognition draws (Only after burn-in, and using thinning)
    if (i>=BurnedDraws) && (floor(i/IndThinning)==i/IndThinning)
        k = (i-BurnedDraws)/IndThinning + 1;
        CogStore(:,k) = CogSimBalanced(IHRSAllBalanced>0.5);
        
        CogDeadStore(:,:,k) = CogDeathGrids;
    end
    
    if i==floor(i/DrawsNotify)*DrawsNotify
        fprintf('%d percent done after %1.1f hours\n',100*i/TotalDraws, toc/3600);
    end
end
time = toc;

% Dropping the burn-in draws and saving the results
[Results.EstYAll   , Results.BetaYAllSim   , Results.SdYAllSim   ] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYAllSim   , ThetaYAllSim   , 1);
[Results.EstYSelf1 , Results.BetaYSelf1Sim , Results.SdYSelf1Sim ] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf1Sim , ThetaYSelf1Sim , 1);
[Results.EstYSelf2 , Results.BetaYSelf2Sim , Results.SdYSelf2Sim ] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf2Sim , ThetaYSelf2Sim , 1);
[Results.EstYSelf3 , Results.BetaYSelf3Sim , Results.SdYSelf3Sim ] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf3Sim , ThetaYSelf3Sim , 1);
[Results.EstYSelf4 , Results.BetaYSelf4Sim , Results.SdYSelf4Sim ] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf4Sim , ThetaYSelf4Sim , 1);
[Results.EstYProxy1, Results.BetaYProxy1Sim, Results.SdYProxy1Sim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYProxy1Sim, ThetaYProxy1Sim, 1);
[Results.EstYProxy2, Results.BetaYProxy2Sim, Results.SdYProxy2Sim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYProxy2Sim, ThetaYProxy2Sim, 1);

[Results.EstYAllMis   , Results.BetaYAllMisSim   , ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYAllMisSim  );
[Results.EstYSelf1Mis , Results.BetaYSelf1MisSim , ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf1MisSim);
[Results.EstYSelf2Mis , Results.BetaYSelf2MisSim , ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf2MisSim);
[Results.EstYSelf3Mis , Results.BetaYSelf3MisSim , ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf3MisSim);
[Results.EstYSelf4Mis , Results.BetaYSelf4MisSim , ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYSelf4MisSim);
[Results.EstYProxy2Mis, Results.BetaYProxy2MisSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaYProxy2MisSim);

[Results.EstProxySel, Results.BetaProxySim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaProxySim);

SdCogTotSim = [SdCogUSim, CorrCogUSim, ones(TotalDraws,1)./sqrt(ThetaCogMSim)];
[Results.EstCog, Results.BetaCogSim, Results.SdCogTotSim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaCogSim, SdCogTotSim, 0);

[EstIAdams1, Results.BetaIAdamsProxyW5Sim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaIAdamsProxyW5Sim);
[EstIAdams2, Results.BetaIAdamsProxyW6Sim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaIAdamsProxyW6Sim);
[EstIAdams3, Results.BetaIAdamsSelfW5Sim, ~]  = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaIAdamsSelfW5Sim);
[EstIAdams4, Results.BetaIAdamsSelfW6Sim, ~]  = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaIAdamsSelfW6Sim);
Results.EstIAdams = [EstIAdams1; [-NaN,-NaN]; EstIAdams2; [-NaN,-NaN]; EstIAdams3; [-NaN,-NaN]; EstIAdams4];

[EstAdamsTimeWA, Results.BetaAdamsTimeWASim, Results.SdAdamsTimeWASim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsTimeWASim, ThetaAdamsTimeWASim, 1);
[EstAdamsTimeWB, Results.BetaAdamsTimeWBSim, Results.SdAdamsTimeWBSim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsTimeWBSim, ThetaAdamsTimeWBSim, 1);
[EstAdamsTimeWC, Results.BetaAdamsTimeWCSim, Results.SdAdamsTimeWCSim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsTimeWCSim, ThetaAdamsTimeWCSim, 1);
[EstAdamsTimeWD, Results.BetaAdamsTimeWDSim, Results.SdAdamsTimeWDSim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsTimeWDSim, ThetaAdamsTimeWDSim, 1);
Results.EstAdamsTime = [EstAdamsTimeWA; [-NaN,-NaN]; EstAdamsTimeWB; [-NaN,-NaN]; EstAdamsTimeWC; [-NaN,-NaN]; EstAdamsTimeWD];

[Results.EstSurv, Results.LnGammaShapeSim, Results.GammaScaleSim] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, LnGammaShapeSim, GammaScaleSim, 0);

[EstAdamsResp1, Results.BetaAdamsRespWASim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsRespWASim);
[EstAdamsResp2, Results.BetaAdamsRespWBSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsRespWBSim);
[EstAdamsResp3, Results.BetaAdamsRespWCSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsRespWCSim);
[EstAdamsResp4, Results.BetaAdamsRespWDSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, BetaAdamsRespWDSim);
Results.EstAdamsResp = [EstAdamsResp1; [-NaN,-NaN]; EstAdamsResp2; [-NaN,-NaN]; EstAdamsResp3; [-NaN,-NaN]; EstAdamsResp4];

[Results.EstPRace, Results.PRaceSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, PRaceSim);
[Results.EstPEduc, Results.PEducSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, PEducSim);
[Results.EstPForborn, Results.PForbornSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, PForbornSim);
[Results.EstPHssc, Results.PHsscSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, PHsscSim);
[Results.EstDSingle, Results.PSingleSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, PSingleSim);
[Results.EstDStroke, Results.PStrokeSim, ~] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, PStrokeSim);

SizePrev = size(PrevGroupsCompare,1);
[Results.EstPrevalenceCompare, Results.PrevGroupsCompare, ~] = EstimateFormat(SizePrev, 1, SizePrev, 1, PrevGroupsCompare);
[Results.EstPrevalenceGender , Results.PrevGroupsGender , ~] = EstimateFormat(SizePrev, 1, SizePrev, 1, PrevGroupsGender);
[Results.EstPrevalenceAge    , Results.PrevGroupsAge    , ~] = EstimateFormat(SizePrev, 1, SizePrev, 1, PrevGroupsAge);
[Results.EstPrevalenceRace   , Results.PrevGroupsRace   , ~] = EstimateFormat(SizePrev, 1, SizePrev, 1, PrevGroupsRace);
[Results.EstPrevalenceForborn, Results.PrevGroupsForborn, ~] = EstimateFormat(SizePrev, 1, SizePrev, 1, PrevGroupsForborn);
[Results.EstPrevalenceEduc   , Results.PrevGroupsEduc   , ~] = EstimateFormat(SizePrev, 1, SizePrev, 1, PrevGroupsEduc);
[Results.EstPrevalenceHssc   , Results.PrevGroupsHssc   , ~] = EstimateFormat(SizePrev, 1, SizePrev, 1, PrevGroupsHssc);

SizePrevDead = size(PrevGroupsDead,1);
[Results.EstPrevalenceDead, Results.PrevGroupsDead, ~] = EstimateFormat(SizePrevDead, 1, SizePrevDead, 1, PrevGroupsDead);

% The standard deviations of the person specific cognition terms
Results.SdCog   = sqrt(ExpCog2   - ExpCog.*ExpCog);
Results.SdCog0  = sqrt(ExpCog02  - ExpCog0.*ExpCog0);
Results.SdCogR  = sqrt(ExpCogR2  - ExpCogR.*ExpCogR);
Results.SdCogU0 = sqrt(ExpCogU02 - ExpCogU0.*ExpCogU0);
Results.SdCogU1 = sqrt(ExpCogU12 - ExpCogU1.*ExpCogU1);
Results.SdDeath = sqrt(ExpDeath2   - ExpDeath.*ExpDeath);
Results.SdShape = sqrt(ExpShape2   - ExpShape.*ExpShape);
Results.SdCogDead = sqrt(ExpCogDead2 - ExpCogDead.*ExpCogDead);

Results.CogStore = cast(CogStore,'single');

% Reshaping the cognition values around death
CogDeadStore2 = zeros(NumDeads,6*UsedIndDraws);
for i=1:6
    CogDeadStore2(:,(i-1)*UsedIndDraws+1:i*UsedIndDraws) = CogDeadStore(:,i,:);
end
Results.CogDeadStore = CogDeadStore2;

% Storing other important variables
Results.PrDement = PrDement; 
Results.PrCind   = PrCind;
Results.PrNormal = PrNormal;
Results.PrDementDead = PrDementDead;
Results.ExpCog   = ExpCog;
Results.ExpCog0  = ExpCog0;
Results.ExpCogR  = ExpCogR;
Results.ExpCogU0 = ExpCogU0;
Results.ExpCogU1 = ExpCogU1;
Results.ExpDeath = ExpDeath;
Results.ExpShape = ExpShape;
Results.ExpCogDead = ExpCogDead;
Results.time     = time/3600;
Results.AcceptGammaShape = AcceptGammaShape;
Results.PropGammaShape   = PropGammaShape;
Results.AcceptGammaScale = AcceptGammaScale;
Results.PropGammaScale   = PropGammaScale;
Results.PropCog0         = PropCogU;
Results.MeanAcceptCog0   = MeanAcceptCogU;
Results.MeanAcceptIW     = MeanAcceptIW;
Results.PropScaleVarU    = PropScaleVarU;
Results.AcceptVarU       = AcceptVarU;
Results.PropSdIW         = [PropSdIWWA, PropSdIWWB, PropSdIWWC, PropSdIWWD];
end

function beta = MyBayesOLS(x,y,theta,XX,cholXX)
    DimX = size(x,2);
    if nargin==3
        T0x = eye(DimX)*0.001;
        XX = x'*x  + T0x;
        cholXX = chol(inv(XX));
    end
    XY = x'*y;
    MuB = XX\XY;
    beta = MuB' + randn(1,DimX)*cholXX/sqrt(theta);
end

function y = MyProbitDraw(xb,ind)
    N  = size(xb,1);
    N1 = sum(ind);
    N0 = N - N1;
    cc = 0.5 * erfc(-xb/sqrt(2));
    RandU = zeros(N,1);
    RandU(ind<0.5)  = cc(ind<0.5) + rand(N0,1).*(1-cc(ind<0.5));
    RandU(ind>0.5)  = cc(ind>0.5).*rand(N1,1);
    RandU(RandU==0) = 0.00000001;
    RandU(RandU==1) = 0.99999999;
    y = xb + sqrt(2)*erfcinv(2*RandU);
end

function y = MyTobitDraw(xb,theta,indlow,lowval,indhigh,highval)
    indlow = indlow>0.5;
    indhigh = indhigh>0.5;
    indany = indlow|indhigh;
    
    N = size(xb,1);
    N1 = sum(indlow);
    N2 = sum(indhigh);
        
    cclow  = 0.5 * erfc((lowval -xb(indlow ))*sqrt(theta/2));
    cchigh = 0.5 * erfc((highval-xb(indhigh))*sqrt(theta/2));
    
    RandU = zeros(N,1);
    RandU(indlow)   = cclow + rand(N1,1).*(1-cclow);
    RandU(indhigh)  = cchigh.*rand(N2,1);
    RandU(RandU==0 & indany) = 0.00000001;
    RandU(RandU==1 & indany) = 0.99999999;
    
    y = xb(indany) + sqrt(2/theta)*erfcinv(2*RandU(indany));
end

function y = MyOProbit3Draw(xb,theta,ycategs,indmis)
    indlow  = ycategs==0;
    indmed  = ycategs==1;
    indhigh = ycategs==2;
    
    N = size(xb,1);
    N1 = sum(indlow);
    N2 = sum(indmed);
    N3 = sum(indhigh);
    NMis = sum(indmis);
        
    cclow  = 0.5 * erfc((0-xb)*sqrt(theta/2));
    cchigh = 0.5 * erfc((1-xb)*sqrt(theta/2));
    
    RandU = zeros(N,1);
    RandU(indlow)   = cclow(indlow) + rand(N1,1).*(1-cclow(indlow));
    RandU(indmed)   = cchigh(indmed) + rand(N2,1).*(cclow(indmed)-cchigh(indmed));
    RandU(indhigh)  = cchigh(indhigh).*rand(N3,1);
    RandU(indmis)   = rand(NMis,1);
    RandU(RandU==0) = 0.00000001;
    RandU(RandU==1) = 0.99999999;
    
    y = xb + sqrt(2/theta)*erfcinv(2*RandU);
end

function Proposal = ProposalDensityUpdate(Proposal, MeanAccept, LowerBound, UpperBound, CutoffLow, CutoffHigh)
    if nargin<3
       LowerBound = 0;
       UpperBound = Proposal*2;
    end
    
    if nargin<5
       CutoffLow = 0.2;
       CutoffHigh = 0.4;
    end
    
    if (MeanAccept<CutoffLow) && (Proposal>LowerBound)
        Proposal = Proposal/1.1;
    elseif (MeanAccept>CutoffHigh) && (Proposal < UpperBound)
        Proposal = Proposal*1.1;
    end
end

function Theta = MyBayesTheta(error,A0,B0,NSize)
    if nargin==3
        NSize = size(error,1)*size(error,2);
    end
    APost = A0 + NSize/2;
    BPost = B0 + sum(sum((error).^2))/2;
    Theta = randg(APost)./BPost;
end

function yb = MyXSecMax(y,index,NSize,NSizex,NSizet)
    aux1 = ones(NSize,1)*(-100);
    aux1(index) = y;
    aux2 = reshape(aux1,NSizet,NSizex);
    yx = max(aux2)';
    yw = yx*ones(1,NSizet);
    yb = reshape(yw',NSize,1);
end

function [AgeBalanced, IWTimeBalanced, IWTimeAdamsWX, XCogBalanced, XBCogBalanced, PropSdIWWX, MeanAcceptIWX] = MyAdamsIWTimingUpdate(AgeBalanced, AgeBalancedCand, ...
           AgeBalanced_Min, AgeBalanced_Max, CenterAge, IWTimeBalanced, IWTimeBalancedCand, XBAdamsTimeBalanced, IAdamsSelectedBalancedWX, IAdamsRespondentBalancedWX, ...
           IAdamsNonRespondentBalancedWX, IAdamsSurvivedBalancedWX, IAdamsSurvNonRespWX, NAdamsNonRespondentWX, PropSdIWWX, XCogBalanced, BetaCogSim, CogSimBalanced, ...
           U0BalancedSim, U1BalancedSim, XBCogBalanced, XBirthYearBalanced, ThetaM, YAdamsRespBalanced, BetaAdamsRespWXSim, XAdamsRespWX, ...
           ThetaAdamsTimeWXSim, NSize, DimXCogDem, DimXCogAge, DimXAdamsRespDemVars, BurnedDraws, i) 
    
    % Auxiliary variables for cognition
    CogSimNR   = CogSimBalanced(IAdamsNonRespondentBalancedWX);
    XBCogNR    = XBCogBalanced(IAdamsNonRespondentBalancedWX);
    AgeNR      = AgeBalanced(IAdamsNonRespondentBalancedWX);
    AgeCandNR  = AgeBalancedCand(IAdamsNonRespondentBalancedWX);
    XCogCandNR = XCogBalanced(IAdamsNonRespondentBalancedWX,:);
    AgeCandNR3 = [(AgeCandNR - CenterAge), (AgeCandNR - CenterAge).^2, (AgeCandNR - CenterAge).^3];
    XBirthYearNR       = XBirthYearBalanced(IAdamsNonRespondentBalancedWX);
    XCogCandNR(:,DimXCogDem+1:DimXCogDem+2*DimXCogAge) = [AgeCandNR3,AgeCandNR3.*(XBirthYearNR*ones(1,3))];
    XBCogCandNR = XCogCandNR*BetaCogSim';
    U0SimNR = U0BalancedSim(IAdamsNonRespondentBalancedWX);
    U1SimNR = U1BalancedSim(IAdamsNonRespondentBalancedWX);
    
    XBAdamsTimeBalancedNR = XBAdamsTimeBalanced(IAdamsNonRespondentBalancedWX,:);

    % Auxiliary variables for ADAMS non-response
    XAdamsRespWXSurv       = XAdamsRespWX(IAdamsNonRespondentBalancedWX(IAdamsSurvivedBalancedWX),:);
    YAdamsRespBalancedSurv = YAdamsRespBalanced(IAdamsRespondentBalancedWX<0.5&IAdamsSurvivedBalancedWX>0.5);
    
    XAdamsRespWXSurv(:,DimXAdamsRespDemVars+1) = AgeNR(IAdamsSurvNonRespWX);
    XAdamsRespWX1Surv = [XAdamsRespWXSurv, CogSimNR(IAdamsSurvNonRespWX)];
    XBAdamsRespWX = XAdamsRespWX1Surv*BetaAdamsRespWXSim';

    XAdamsRespWXSurvCand = XAdamsRespWXSurv;
    XAdamsRespWXSurvCand(:,DimXAdamsRespDemVars+1) = AgeCandNR(IAdamsSurvNonRespWX); 
    XAdamsRespWX1Cand = [XAdamsRespWXSurvCand, CogSimNR(IAdamsSurvNonRespWX)];
    XBAdamsRespWXCand = XAdamsRespWX1Cand*BetaAdamsRespWXSim';
 
    % The prior
    LnPrior     = - (IWTimeBalanced(IAdamsNonRespondentBalancedWX)     - XBAdamsTimeBalancedNR).^2.*ThetaAdamsTimeWXSim/2;
    LnPriorCand = - (IWTimeBalancedCand(IAdamsNonRespondentBalancedWX) - XBAdamsTimeBalancedNR).^2.*ThetaAdamsTimeWXSim/2;
    
    % The likelihood of latent cognition
    LnLike      = - (CogSimNR - XBCogNR     - U0SimNR - U1SimNR.*(AgeNR     - CenterAge)).^2.*ThetaM/2;
    LnLikeCand  = - (CogSimNR - XBCogCandNR - U0SimNR - U1SimNR.*(AgeCandNR - CenterAge)).^2.*ThetaM/2;
    
    % The likelihood of ADAMS non-response
    LnLikeResp     = - (YAdamsRespBalancedSurv - XBAdamsRespWX    ).^2/2;
    LnLikeRespCand = - (YAdamsRespBalancedSurv - XBAdamsRespWXCand).^2/2;
    LnLike(IAdamsSurvNonRespWX)     = LnLike(IAdamsSurvNonRespWX)     + LnLikeResp;
    LnLikeCand(IAdamsSurvNonRespWX) = LnLikeCand(IAdamsSurvNonRespWX) + LnLikeRespCand;
    
    % Acceptance
    Accept = log(rand(NAdamsNonRespondentWX,1)) < LnLikeCand - LnLike + LnPriorCand - LnPrior;
    Accept(AgeCandNR < AgeBalanced_Min(IAdamsNonRespondentBalancedWX)) = 0;
    Accept(AgeCandNR > AgeBalanced_Max(IAdamsNonRespondentBalancedWX)) = 0;
    
    AcceptIWBalanced = zeros(NSize,1)>0.5;
    AcceptIWBalanced(IAdamsNonRespondentBalancedWX) = Accept;
    IWTimeBalanced(AcceptIWBalanced) = IWTimeBalancedCand(AcceptIWBalanced);
    IWTimeAdamsWX = IWTimeBalanced(IAdamsSelectedBalancedWX);
    
    AgeBalanced(AcceptIWBalanced) = AgeBalancedCand(AcceptIWBalanced);
        
    %Updating the proposal density
    MeanAcceptIWX = mean(Accept);
    if (i>200) && (i<BurnedDraws)
        PropSdIWWX = ProposalDensityUpdate(PropSdIWWX,MeanAcceptIWX,0.05,4,0.15,0.35);
    end
    
    AgeBalancedNR  = AgeBalanced(IAdamsNonRespondentBalancedWX);
    AgeBalancedNR3 = [(AgeBalancedNR - CenterAge), (AgeBalancedNR - CenterAge).^2,(AgeBalancedNR - CenterAge).^3];
    XCogBalanced(IAdamsNonRespondentBalancedWX,DimXCogDem+1:DimXCogDem+2*DimXCogAge) = [AgeBalancedNR3,AgeBalancedNR3.*(XBirthYearNR*ones(1,3))];
    XBCogBalanced(IAdamsNonRespondentBalancedWX,:) = XCogBalanced(IAdamsNonRespondentBalancedWX,:)*BetaCogSim';
end

function [BetaAdamsRespWXSim, YAdamsRespBalanced, XAdamsRespWX, XBAdamsRespBalanced] = MyAdamsRespUpdate(YAdamsRespBalanced, AgeBalanced, IAdamsSurvivedBalancedWX, IAdamsRespondentSurvWX, CogSimBalanced, XAdamsRespWX, XBAdamsRespBalanced, BetaAdamsRespWXSim, DimXAdamsRespDemVars, i)
    XAdamsRespWX(:,DimXAdamsRespDemVars+1) = AgeBalanced(IAdamsSurvivedBalancedWX);
    XAdamsRespWX1 = [XAdamsRespWX, CogSimBalanced(IAdamsSurvivedBalancedWX)];
    XBAdamsRespWX = XAdamsRespWX1*BetaAdamsRespWXSim(i-1,:)';

    YAdamsRespWX = MyProbitDraw(XBAdamsRespWX,IAdamsRespondentSurvWX);
    YAdamsRespBalanced(IAdamsSurvivedBalancedWX) = YAdamsRespWX;
    
    BetaAdamsRespWXSim(i,:) = MyBayesOLS(XAdamsRespWX1,YAdamsRespWX, 1);
    XBAdamsRespWX = XAdamsRespWX1*BetaAdamsRespWXSim(i,:)';
    XBAdamsRespBalanced(IAdamsSurvivedBalancedWX) = XBAdamsRespWX;
end

function LnS = LnSurvival(TargetAge, Age, GammaScale, GammaShape)
    LnS = - (GammaShape ./ GammaScale) .* (exp(TargetAge.*GammaScale) - exp(Age.*GammaScale));
end

function f = LnSurvLike(d, d_min, d_max, dead, age, scale, shape)
    LnSD   = - (shape ./ scale) .* (exp(d.*scale)     - exp(age.*scale));
    LnSmin = - (shape ./ scale) .* (exp(d_min.*scale) - exp(age.*scale));
    LnSmax = - (shape ./ scale) .* (exp(d_max.*scale) - exp(age.*scale));
    LnH = log(shape) + d.*scale;
    LnD = log(exp(LnSmin) - exp(LnSmax));
    
    f = LnSD + LnH;
    f(~dead) = LnD(~dead);
end

function f = SurvivalNLike(betas, d, x1, age, d_min, d_max, dead)
    dim = size(betas,2);
    GammaScale = betas(1);
    GammaShape = exp(x1*betas(2:dim)');
    
    LnSD = - (GammaShape ./ GammaScale) .* (exp(d.*GammaScale) - exp(age.*GammaScale));
    LnSmin = - (GammaShape ./ GammaScale) .* (exp(d_min.*GammaScale) - exp(age.*GammaScale));
    LnSmax = - (GammaShape ./ GammaScale) .* (exp(d_max.*GammaScale) - exp(age.*GammaScale));
    LnH = log(GammaShape) + d.*GammaScale;
    LnD = log(exp(LnSmin) - exp(LnSmax));
    
    like = LnSD + LnH;
    like(~dead) = LnD(~dead);
    
    f =  - sum(like);
end

function [XCogDemBalanced, XCogAgeBalanced, XCogBalanced, XProxyBalanced, XHRSSurv, XVarsBalanced, XVarsMisBalanced] = XVarsLoad(XRaceBalanced, XEducBalanced, XForbornBalanced, XHsscBalanced, XSingleBalanced, XFemaleBalanced, AgeBalanced, CenterAge, XStrokeBalanced, WaveDummies, XBirthYear, IHRSSelect1Balanced, NSizex, NSize)
    XDemHealth = [XFemaleBalanced, XRaceBalanced==1, XRaceBalanced==2, XRaceBalanced==3, XEducBalanced==1, XEducBalanced==2, XEducBalanced==3, XForbornBalanced, XHsscBalanced==1, XHsscBalanced==2, XHsscBalanced==3, XSingleBalanced, XStrokeBalanced];
    AgeBalanced3 = [(AgeBalanced - CenterAge), (AgeBalanced - CenterAge).^2, (AgeBalanced - CenterAge).^3];

    DimX = size(XDemHealth,2);
    XCogDemBalanced = [ones(NSize,1), XDemHealth, XBirthYear, XDemHealth.*(XBirthYear*ones(1,DimX))];
    XCogAgeBalanced = AgeBalanced3;
    XCogBalanced = [XCogDemBalanced,XCogAgeBalanced,XCogAgeBalanced.*(XBirthYear*ones(1,3))];
    
    XProxyBalanced = [ones(NSize,1), XDemHealth, WaveDummies, AgeBalanced3];

    XHRSSurv = [ones(NSizex,1), XDemHealth(IHRSSelect1Balanced,1:11), XBirthYear(IHRSSelect1Balanced,1), XDemHealth(IHRSSelect1Balanced,1:11).*(XBirthYear(IHRSSelect1Balanced,1)*ones(1,11))];

    XVarsBalanced = [ones(NSize,1),XDemHealth,(AgeBalanced - CenterAge)];
    XVarsMisBalanced = [ones(NSize,1),XDemHealth,WaveDummies,(AgeBalanced - CenterAge)];
end

function [XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv] = XVarsUpdate(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XHRSSurv, XLong, X, XBirthYearBalanced, XBirthYear, IndexNT, IndexN, Position1, Position2, Position3)
    DimX = max(XLong);
    Xmt = XLong(IndexNT,:);
    Xm  = X(IndexN,:);
    XBirthYearBalancedm = XBirthYearBalanced(IndexNT,:);
    XBirthYearm     = XBirthYear(IndexN,:);
    for j=1:DimX
        Xmtj = Xmt==j;
        Xmj  = Xm==j;
        
        XVarsBalanced(IndexNT,Position1+j-1) = Xmtj;
        XVarsMisBalanced(IndexNT,Position1+j-1) = Xmtj;
        XCogBalanced(IndexNT,Position1+j-1)  = Xmtj;
        XCogBalanced(IndexNT,Position2+j-1)  = Xmtj.*XBirthYearBalancedm;
        XHRSSurv(IndexN,Position1+j-1)       = Xmj;  
        XHRSSurv(IndexN,Position3+j-1)       = Xmj.*XBirthYearm;  
    end
end

function [XVarsBalanced, XVarsMisBalanced, XCogBalanced] = XVarsUpdate2(XVarsBalanced, XVarsMisBalanced, XCogBalanced, XLong, XBirthYearBalanced, IndexNT, Position1, Position2)
    Xmt = XLong(IndexNT,:);
    XBirthYearBalancedm = XBirthYearBalanced(IndexNT,:);
    Xmtj = Xmt==1;

    XVarsBalanced(IndexNT,Position1) = Xmtj;
    XVarsMisBalanced(IndexNT,Position1) = Xmtj;
    XCogBalanced(IndexNT,Position1)  = Xmtj;
    XCogBalanced(IndexNT,Position2)  = Xmtj.*XBirthYearBalancedm;
end

function [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore] = X1VarsLoad(XVarsBalanced, XVarsMisBalanced, CogSimBalanced, FirstSelfBalanced, IProxyCoreBalanced, ISelfCoreBalanced, IHRSCoreBalanced, XProxyBalanced, WaveDummies)
    X1VarsProxyBalanced = [XVarsBalanced, CogSimBalanced];
    X1VarsSelfBalanced  = [XVarsBalanced, FirstSelfBalanced, CogSimBalanced];
    X1VarsProxyCore = X1VarsProxyBalanced(IProxyCoreBalanced,:);
    X1VarsSelfCore  = X1VarsSelfBalanced(ISelfCoreBalanced,:);
    X1VarsAllCore   = X1VarsProxyBalanced(IHRSCoreBalanced,:);
    
    X1VarsMisProxyBalanced = [XVarsMisBalanced, CogSimBalanced, WaveDummies.*(CogSimBalanced*ones(1,8))];
    X1VarsMisSelfBalanced  = [XVarsMisBalanced, FirstSelfBalanced, CogSimBalanced, WaveDummies.*(CogSimBalanced*ones(1,8))];
    X1VarsMisProxyCore  = X1VarsMisProxyBalanced(IProxyCoreBalanced,:);
    X1VarsMisSelfCore   = X1VarsMisSelfBalanced(ISelfCoreBalanced,:);
    X1VarsMisAllCore    = X1VarsMisProxyBalanced(IHRSCoreBalanced,:);
    
    X1ProxyBalanced = [XProxyBalanced, CogSimBalanced, WaveDummies.*(CogSimBalanced*ones(1,8))];
    X1ProxyCore     = X1ProxyBalanced(IHRSCoreBalanced,:);
end

function [X1VarsProxyBalancedMis, X1VarsSelfBalancedMis, X1VarsSelf2BalancedMis, X1VarsMisProxyBalancedMis, X1VarsMisSelfBalancedMis, X1VarsMisSelf2BalancedMis, X1VarsMisSelf4BalancedMis, X1ProxyBalancedMis, XCogBalancedMis] = GetMissings(X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XCogBalanced, MisIndex)
    X1VarsProxyBalancedMis    = X1VarsProxyBalanced(MisIndex,:);
    X1VarsSelfBalancedMis     = X1VarsSelfBalanced(MisIndex,:);
    X1VarsSelf2BalancedMis    = X1VarsSelf2Balanced(MisIndex,:);
    X1VarsMisProxyBalancedMis = X1VarsMisProxyBalanced(MisIndex,:);
    X1VarsMisSelfBalancedMis  = X1VarsMisSelfBalanced(MisIndex,:);
    X1VarsMisSelf2BalancedMis = X1VarsMisSelf2Balanced(MisIndex,:);
    X1VarsMisSelf4BalancedMis = X1VarsMisSelf4Balanced(MisIndex,:);
    X1ProxyBalancedMis        = X1ProxyBalanced(MisIndex,:);
    XCogBalancedMis           = XCogBalanced(MisIndex,:);
end

function [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsSelf2Core, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore] = X1VarsUpdate1(X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsSelf2Core, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore, WaveDummies, WaveDummiesCore, WaveDummiesProxy, WaveDummiesSelf, CogSimBalanced, IProxyCoreBalanced, ISelfCoreBalanced, IHRSCoreBalanced)
    CProxy = CogSimBalanced(IProxyCoreBalanced);
    CSelf  = CogSimBalanced(ISelfCoreBalanced);
    CCore  = CogSimBalanced(IHRSCoreBalanced);
    
    CogWave     = [CogSimBalanced, WaveDummies.*(CogSimBalanced*ones(1,8))];
    CoreCogWave = [CCore, WaveDummiesCore.*(CCore*ones(1,8))];
    
    X1VarsProxyBalanced(:,size(X1VarsProxyBalanced,2)) = CogSimBalanced;
    X1VarsSelfBalanced(:,size(X1VarsSelfBalanced,2))   = CogSimBalanced;
    X1VarsSelf2Balanced(:,size(X1VarsSelf2Balanced,2)) = CogSimBalanced;
    X1VarsProxyCore(:,size(X1VarsProxyCore,2)) = CProxy;
    X1VarsSelfCore(:,size(X1VarsSelfCore,2))   = CSelf;
    X1VarsSelf2Core(:,size(X1VarsSelf2Core,2)) = CSelf;
    X1VarsAllCore(:,size(X1VarsAllCore,2))     = CCore;
    
    siz = size(X1VarsMisProxyBalanced,2);
    X1VarsMisProxyBalanced(:,siz-8:siz) = CogWave;
    siz = size(X1VarsMisSelfBalanced,2);
    X1VarsMisSelfBalanced(:,siz-8:siz)  = CogWave;
    siz = size(X1VarsMisSelf2Balanced,2);
    X1VarsMisSelf2Balanced(:,siz-8:siz)  = CogWave;
    siz = size(X1VarsMisSelf4Balanced,2);
    X1VarsMisSelf4Balanced(:,siz-8:siz)  = CogWave;
    siz = size(X1VarsMisProxyCore,2);
    X1VarsMisProxyCore(:,siz-8:siz)  = [CProxy, WaveDummiesProxy.*(CProxy*ones(1,8))];
    siz = size(X1VarsMisSelfCore,2);
    X1VarsMisSelfCore(:,siz-8:siz)   = [CSelf, WaveDummiesSelf.*(CSelf*ones(1,8))];
    siz = size(X1VarsMisAllCore,2);
    X1VarsMisAllCore(:,siz-8:siz)    = CoreCogWave;
        
    siz = size(X1ProxyBalanced,2);
    X1ProxyBalanced(:,siz-8:siz) =  CogWave;
    X1ProxyCore(:,siz-8:siz)     =  CoreCogWave;
end

function [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1] = X1VarsUpdate2(XLong, X, IndexNT, IndexN, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced, XHRSSurv1)
    DimX = size(XLong,2) - 1;   % The last variable in XVars is age or waves which does not need updating.
    DimXSurv = size(X,2);
    Xmt  =  XLong(IndexNT,1:DimX);
    Xm   =  X(IndexN,1:DimXSurv);
    
    X1VarsProxyBalanced(IndexNT,1:DimX) = Xmt;
    X1VarsSelfBalanced(IndexNT,1:DimX)  = Xmt;
    X1VarsSelf2Balanced(IndexNT,1:DimX) = Xmt;
    
    X1VarsMisProxyBalanced(IndexNT,1:DimX) = Xmt;
    X1VarsMisSelfBalanced(IndexNT,1:DimX)  = Xmt;
    X1VarsMisSelf2Balanced(IndexNT,1:DimX) = Xmt;
    X1VarsMisSelf4Balanced(IndexNT,1:DimX) = Xmt;
    
    X1ProxyBalanced(IndexNT,1:DimX) = Xmt; 
    
    XHRSSurv1(IndexN,1:DimXSurv)=Xm;
end

function [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced] = X1VarsUpdate3(XLong, IndexNT, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsSelf2Balanced, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisSelf2Balanced, X1VarsMisSelf4Balanced, X1ProxyBalanced)
    DimX = size(XLong,2) - 1;   % The last variable in XVars is age or waves which does not need updating.
    Xmt  =  XLong(IndexNT,1:DimX);
    
    X1VarsProxyBalanced(IndexNT,1:DimX) = Xmt;
    X1VarsSelfBalanced(IndexNT,1:DimX)  = Xmt;
    X1VarsSelf2Balanced(IndexNT,1:DimX) = Xmt;
    
    X1VarsMisProxyBalanced(IndexNT,1:DimX) = Xmt;
    X1VarsMisSelfBalanced(IndexNT,1:DimX)  = Xmt;
    X1VarsMisSelf2Balanced(IndexNT,1:DimX) = Xmt;
    X1VarsMisSelf4Balanced(IndexNT,1:DimX) = Xmt;
    
    X1ProxyBalanced(IndexNT,1:DimX) = Xmt; 
end

function [X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore, XHRSSurv1] = X1VarsUpdate4(XLong, X, IndexNT, IndexN, X1VarsProxyBalanced, X1VarsSelfBalanced, X1VarsProxyCore, X1VarsSelfCore, X1VarsAllCore, X1VarsMisProxyBalanced, X1VarsMisSelfBalanced, X1VarsMisProxyCore, X1VarsMisSelfCore, X1VarsMisAllCore, X1ProxyBalanced, X1ProxyCore, XHRSSurv1, IProxyCoreBalanced, ISelfCoreBalanced, IHRSCoreBalanced)
    DimX = size(XLong,2)-1; % The last variable in Xmt is age or waves which does not need updating.
    DimXSurv = size(X,2);
    Xmt =  XLong(IndexNT,1:DimX);
    XmtCoreProxy = XLong(IProxyCoreBalanced&IndexNT,1:DimX);
    XmtCoreSelf  = XLong(ISelfCoreBalanced&IndexNT,1:DimX);
    XmtCoreAll   = XLong(IHRSCoreBalanced&IndexNT,1:DimX);
    Xm  =  X(IndexN,1:DimXSurv);
    
    IndexNTProxy = IndexNT(IProxyCoreBalanced);
    IndexNTSelf  = IndexNT(ISelfCoreBalanced);
    IndexNTAll   = IndexNT(IHRSCoreBalanced);
    

    X1VarsProxyBalanced(IndexNT,1:DimX)  = Xmt;
    X1VarsSelfBalanced(IndexNT,1:DimX)   = Xmt;
    X1VarsProxyCore(IndexNTProxy,1:DimX) = XmtCoreProxy;
    X1VarsSelfCore(IndexNTSelf,1:DimX)   = XmtCoreSelf;
    X1VarsAllCore(IndexNTAll,1:DimX)     = XmtCoreAll;
        
    X1VarsMisProxyBalanced(IndexNT,1:DimX)  = Xmt;
    X1VarsMisSelfBalanced(IndexNT,1:DimX)   = Xmt;
    X1VarsMisProxyCore(IndexNTProxy,1:DimX) = XmtCoreProxy;
    X1VarsMisSelfCore(IndexNTSelf,1:DimX)   = XmtCoreSelf;
    X1VarsMisAllCore(IndexNTAll,1:DimX)     = XmtCoreAll;
    
    X1ProxyBalanced(IndexNT,1:DimX) = Xmt;
    X1ProxyCore(IndexNTAll,1:DimX)  = XmtCoreAll;
    
    XHRSSurv1(IndexN,1:DimXSurv)=Xm;
end


function LnLikes = LnLikesMisX(x1, beta, yWide, XWide, Theta, index, IndexN, DimX, Position, NMisX, NSizet)
    XWidem = XWide(IndexN,:);
    indexm = index(IndexN,:);
    
    XBBalanced = x1*beta';
    XBWide     = reshape(XBBalanced, NSizet, NMisX)';
    
    EZB  = yWide(IndexN,:) - XBWide;
    for j = 1:DimX 
       EZB = EZB + beta(1,Position+j-1)*(XWidem==j);
    end
    
    LnLikes = zeros(NMisX, DimX+1);
    for j=1:DimX
        aux = -0.5*(EZB - beta(1,Position+j-1)).^2*Theta;
        aux(indexm<0.5)=0;
        LnLikes(:,j) = sum(aux,2);
    end
    aux = -0.5*(EZB).^2*Theta;
    aux(indexm<0.5)=0;
    LnLikes(:,DimX+1) = sum(aux,2);
end

function LnLikes = LnLikesMisXInter(x1, beta, yWide, XWide, IntWide, Theta, index, IndexN, DimX, Position1, Position2, NMisX, NSizet)
    XWidem = XWide(IndexN,:);
    indexm = index(IndexN,:);
    Intm = IntWide(IndexN,:);
    
    XBBalanced = x1*beta';
    XBWide     = reshape(XBBalanced, NSizet, NMisX)';
    
    EZB  = yWide(IndexN,:) - XBWide;
    for j = 1:DimX 
       EZB = EZB + (beta(1,Position1+j-1) + beta(1,Position2+j-1)*Intm).*(XWidem==j);
    end
    
    LnLikes = zeros(NMisX, DimX+1);
    for j=1:DimX
        aux = -0.5*(EZB - beta(1,Position1+j-1) - beta(1,Position2+j-1)*Intm).^2*Theta;
        aux(indexm<0.5)=0;
        LnLikes(:,j) = sum(aux,2);
    end
    aux = -0.5*(EZB).^2*Theta;
    aux(indexm<0.5)=0;
    LnLikes(:,DimX+1) = sum(aux,2);
end

function LnLikesSurv = LnLikesMisXSurv(beta, dx, dmin, dmax, dead, A1, Scale, LnShape, X, Inter, IndexN, DimX, Position1, Position2, NMisX)
    Xm = X(IndexN,:);
    dxm = dx(IndexN,:);
    dminm = dmin(IndexN,:);
    dmaxm = dmax(IndexN,:);
    deadm = dead(IndexN,:);
    A1m = A1(IndexN,:);
    LnShapem = LnShape(IndexN,:);
    Interm = Inter(IndexN,:);
    
    L0 = LnShapem;
    for j=1:DimX 
       L0 = L0 - (beta(1,Position1+j-1) + beta(1,Position2+j-1)*Interm).*(Xm==j);
    end
    
    LnLikesSurv = zeros(NMisX, DimX+1);
    for j=1:DimX
        LnLikesSurv(:,j) = LnSurvLike(dxm, dminm, dmaxm, deadm, A1m, Scale, exp(L0 + beta(1,Position1+j-1) + beta(1,Position2+j-1)*Interm));
    end
    LnLikesSurv(:,DimX+1) = LnSurvLike(dxm, dminm, dmaxm, deadm, A1m, Scale, exp(L0));
end

function [f0, f1] = LnLikesMisXT(MisInd, IntInd, y, xb, x, theta, beta)
    IntMis = IntInd(MisInd);
    ym  = y(MisInd);
    xbm = xb(MisInd);
    xm  = x(MisInd);
    lnf0 = -0.5*(ym - xbm + beta*xm    ).^2*theta;
    lnf1 = -0.5*(ym - xbm + beta*(xm-1)).^2*theta;
    
    lnf0(~IntMis) = 0;
    lnf1(~IntMis) = 0;
    f0 = exp(lnf0);
    f1 = exp(lnf1);
end

function [f0, f1] = LnLikesMisXTInt(MisInd, IntInd, y, xb, x, theta, betac, betaint, inter)
    IntMis = IntInd(MisInd);
    ym  = y(MisInd);
    xbm = xb(MisInd);
    xm  = x(MisInd);
    interm = inter(MisInd);
    lnf0 = -0.5*(ym - xbm + (betac + betaint*interm).*xm    ).^2*theta;
    lnf1 = -0.5*(ym - xbm + (betac + betaint*interm).*(xm-1)).^2*theta;
    
    lnf0(~IntMis) = 0;
    lnf1(~IntMis) = 0;
    f0 = exp(lnf0);
    f1 = exp(lnf1);
end

function XGridDead = TimeInvarDeadGrid(XWide, AgeWide, IHrsWide, DeathAgeGrids, PDistX, NumDeads, NSizet)
    XGridDead = zeros(NumDeads,6);
    
    %%% Last column (at death)
    PPosterior = zeros(NumDeads,1);
    
    Iprev = zeros(NumDeads,NSizet)>0.5;
    AgeWide2 = AgeWide;
    AgeWide2(IHrsWide<0.5) = 0;
    MaxAgeWide2 = max(AgeWide2,[],2)*ones(1,NSizet);
    Iprev(AgeWide2==MaxAgeWide2) = 1;
    
    AgeWide3 = -ones(NumDeads,NSizet);
    AgeWide3(Iprev) = AgeWide(Iprev);
    X2 = -ones(NumDeads,NSizet);
    X2(Iprev) = XWide(Iprev);
    
    a0 = max(AgeWide3,[],2);
    x0 = max(X2,[],2);
    
    p01t1  = PDistX(1,3)*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,6)-a0)));
    p10t1  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,6)-a0)));
    
    indic = x0==0;
    PP1 = p01t1(indic);
    PP0 = (1-p01t1(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = x0==1;
    PP1 = (1-p10t1(indic));
    PP0 = p10t1(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    
    XGridDead(:,6) = rand(NumDeads,1)< PPosterior;
    
    %%% First column
    PPosterior = zeros(NumDeads,1);
    
    % Case with no prior values available
    p01t  = PDistX(1,3)*(1 - exp(-PDistX(1,2)*(AgeWide(:,1)-DeathAgeGrids(:,1))));
    p10t  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(AgeWide(:,1)-DeathAgeGrids(:,1))));
    
    indic = AgeWide(:,1)>DeathAgeGrids(:,1) & XWide(:,1)==0;
    PP1 = p10t(indic);
    PP0 = (1-p01t(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)>DeathAgeGrids(:,1) & XWide(:,1)==1;
    PP1 = (1-p10t(indic));
    PP0 = p01t(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    
    %Case with proper prior value
    Iprev = zeros(NumDeads,NSizet)>0.5;
    AgeWide2 = AgeWide;
    AgeWide2(IHrsWide<0.5 | AgeWide>DeathAgeGrids(:,1)*ones(1,NSizet)) = 0;
    MaxAgeWide2 = max(AgeWide2,[],2)*ones(1,NSizet);
    Iprev(AgeWide2==MaxAgeWide2) = 1;
    
    AgeWide3 = -ones(NumDeads,NSizet);
    AgeWide3(Iprev) = AgeWide(Iprev);
    X2 = -ones(NumDeads,NSizet);
    X2(Iprev) = XWide(Iprev);
    
    a0 = max(AgeWide3,[],2);
    x0 = max(X2,[],2);
    
    Inext = zeros(NumDeads,NSizet+1)>0.5;
    allage  = [AgeWide, DeathAgeGrids(:,6)];
    allx     = [XWide, XGridDead(:,6)];
    AgeWide2 = allage;
    AgeWide2(allage<=(DeathAgeGrids(:,1)*ones(1,NSizet+1))) = 100;
    mallage = min(AgeWide2,[],2)*ones(1,NSizet+1);
    Inext(AgeWide2==mallage) = 1;
    
    AgeWide3 = -ones(NumDeads,NSizet+1);
    AgeWide3(Inext) = allage(Inext);
    X2 = -ones(NumDeads,NSizet+1);
    X2(Inext) = allx(Inext);
    
    a2 = max(AgeWide3,[],2);
    x2 = max(X2,[],2);
    
    p01t1 = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,1)-a0)));
    p10t1 = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,1)-a0)));
    p01t  = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,1))));
    p10t  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,1))));
    
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==0 & x2==0;
    PP1 = p01t1(indic) .* p10t(indic);
    PP0 = (1-p01t1(indic)) .* (1-p01t(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==0 & x2==1;
    PP1 = p01t1(indic) .* (1 - p10t(indic));
    PP0 = (1-p01t1(indic)) .* p01t(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==1 & x2==0;
    PP1 = (1-p10t1(indic)) .* p10t(indic);
    PP0 = p10t1(indic) .* (1-p01t(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==1 & x2==1;
    PP1 = (1-p10t1(indic)) .* (1-p10t(indic));
    PP0 = p10t1(indic) .* p01t(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    
    XGridDead(:,1) = rand(NumDeads,1)< PPosterior;
    
    
    %%% Middle columns
    for j=2:5
        PPosterior = zeros(NumDeads,1);
        
        Iprev = zeros(NumDeads,NSizet+j-1)>0.5;
        allage  = [AgeWide, DeathAgeGrids(:,1:j-1)];
        allx     = [XWide, XGridDead(:,1:j-1)];
        IHrsExt = [IHrsWide, ones(NumDeads,j-1)]>0.5;
        AgeWide2 = allage;
        AgeWide2(IHrsExt<0.5 | allage>DeathAgeGrids(:,j)*ones(1,NSizet+j-1)) = 0;
        MaxAgeWide2 = max(AgeWide2,[],2)*ones(1,NSizet+j-1);
        Iprev(AgeWide2==MaxAgeWide2) = 1;

        AgeWide3 = -ones(NumDeads,NSizet+j-1);
        AgeWide3(Iprev) = allage(Iprev);
        X2 = -ones(NumDeads,NSizet+j-1);
        X2(Iprev) = allx(Iprev);

        a0 = max(AgeWide3,[],2);
        x0 = max(X2,[],2);

        Inext = zeros(NumDeads,NSizet+1)>0.5;
        allage  = [AgeWide, DeathAgeGrids(:,6)];
        allx     = [XWide, XGridDead(:,6)];
        AgeWide2 = allage;
        AgeWide2(allage<=(DeathAgeGrids(:,j)*ones(1,NSizet+1))) = 100;
        mallage = min(AgeWide2,[],2)*ones(1,NSizet+1);
        Inext(AgeWide2==mallage) = 1;

        AgeWide3 = -ones(NumDeads,NSizet+1);
        AgeWide3(Inext) = allage(Inext);
        X2 = -ones(NumDeads,NSizet+1);
        X2(Inext) = allx(Inext);

        a2 = max(AgeWide3,[],2);
        x2 = max(X2,[],2);

        p01t1 = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,j)-a0)));
        p10t1 = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,j)-a0)));
        p01t  = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,j))));
        p10t  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,j))));

        indic = x0==0 & x2==0;
        PP1 = p01t1(indic) .* p10t(indic);
        PP0 = (1-p01t1(indic)) .* (1-p01t(indic));
        PPosterior(indic) = PP1 ./ (PP0 + PP1);
        indic = x0==0 & x2==1;
        PP1 = p01t1(indic) .* (1 - p10t(indic));
        PP0 = (1-p01t1(indic)) .* p01t(indic);
        PPosterior(indic) = PP1 ./ (PP0 + PP1);
        indic = x0==1 & x2==0;
        PP1 = (1-p10t1(indic)) .* p10t(indic);
        PP0 = p10t1(indic) .* (1-p01t(indic));
        PPosterior(indic) = PP1 ./ (PP0 + PP1);
        indic = x0==1 & x2==1;
        PP1 = (1-p10t1(indic)) .* (1-p10t(indic));
        PP0 = p10t1(indic) .* p01t(indic);
        PPosterior(indic) = PP1 ./ (PP0 + PP1);

        XGridDead(:,j) = rand(NumDeads,1)< PPosterior;
    end
end

function [IndPrevs, DimTot] = IndPrevsInitG1(Ind, WavesBalanced, G1, NSize)
    MinW  = min(WavesBalanced(Ind));
    MaxW  = max(WavesBalanced(Ind));
    SizeW = MaxW - MinW + 1;
    
    MinG1  = min(G1(Ind));
    MaxG1  = max(G1(Ind));
    SizeG1 = MaxG1 - MinG1 + 1;
    
    DimTot = SizeW * (SizeG1 + 1);
    
    IndPrevs = zeros(NSize,DimTot)>0.5;
    for i=1:SizeW
        IndPrevs(:,i)    = Ind==1 & WavesBalanced==4+i;
        for j=MinG1:MaxG1
            IndPrevs(:,SizeW*(j-MinG1+1)+i)  = Ind==1 & WavesBalanced==4+i & G1==j;
        end
    end
end

function [IndPrevs, DimTot] = IndPrevsInitG2(Ind, WavesBalanced, G1, G2, NSize)
    MinW  = min(WavesBalanced(Ind));
    MaxW  = max(WavesBalanced(Ind));
    SizeW = MaxW - MinW + 1;
    
    MinG1  = min(G1(Ind&G1>-1));
    MaxG1  = max(G1(Ind));
    SizeG1 = MaxG1 - MinG1 + 1;
    
    MinG2  = min(G2(Ind&G2>-1));
    MaxG2  = max(G2(Ind));
    SizeG2 = MaxG2 - MinG2 + 1;
    
    DimTot = SizeW * SizeG1 * SizeG2;
    IndPrevs = zeros(NSize,DimTot)>0.5;
    for i=1:9
        for j=MinG1:MaxG1
            for k=MinG2:MaxG2
                IndPrevs(:,SizeW*((j-MinG1)*(SizeG2) + (k-MinG2)) + i)    = Ind==1 & WavesBalanced==4+i & G1==j & G2==k;
            end
        end
    end
end

function WeightedInds = WeightIndInit(IndPrevs, WeightsBalanced, DimPrevGroups, NSize)
    WeightedInds = zeros(NSize,DimPrevGroups);
    for i=1:DimPrevGroups
        WeightedInds(:,i) = IndPrevs(:,i).*WeightsBalanced;
        WeightedInds(:,i) = WeightedInds(:,i) / mean(WeightedInds(IndPrevs(:,i),i));
    end
end

function PrevGroups = PrevUpdate(DementedBalanced, WeightedInds, IndPrevs, DimPrevGroups)
    PrevGroups = zeros(1,DimPrevGroups);
    for j=1:DimPrevGroups
        Aux = DementedBalanced.*WeightedInds(:,j);
        PrevGroups(1,j) = mean(Aux(IndPrevs(:,j)));
    end
end

function [Est, Beta, Sd] = EstimateFormat(TotalDraws, BurnedDraws, UsedDraws, Thinning, Beta, Sd, Reverse)
    Beta    = Beta(BurnedDraws:TotalDraws,:);
    DimBeta = size(Beta,2);
    Est     = zeros(DimBeta,2);
    for j=1:DimBeta
        Est(j,:)   = [mean(Beta(:,j)), std(Beta(:,j))];
    end
    
    if nargin<6
        Sd = NaN;
    else
        DimSd = size(Sd,2);
        if Reverse==0
            Sd = Sd(BurnedDraws:TotalDraws,:);
        else
            Sd = ones(UsedDraws,DimSd)./sqrt(Sd(BurnedDraws:TotalDraws,:));
        end
        Est2 = zeros(DimSd,2);
        for j=1:DimSd
            Est2(j,:)   = [mean(Sd(:,j)), std(Sd(:,j))];
        end
        Est = [Est; [-NaN,-NaN]; Est2];
    end
    Beta = Beta(1:Thinning:end,:);
    Sd   = Sd(1:Thinning:end,:);
end