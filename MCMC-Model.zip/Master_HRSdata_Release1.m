%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimating a joint model of latent cognition, dementia model and 
%   survival using Health and Retirement Study data
%
% Release 1: First public release published in 2021.
%   
% Data: Health And Retirement Study, 2000-2016, age 65+
%
% Main model features:
%     - Random intercept and random slope in latent cognition (correlated)
%     - Gompertz survival
%     - Selection equation for proxy interviews
%     - HRS cognition measures modeled individually
%     - All four ADAMS waves modeled
%     - Missing data modeled with multiple imputation
%
% by P�ter Hudomiet
% August 9, 2021
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear;


%%% Loading the data
Data = DataLoad_Release1;


%%% Running the estimation model
Results = MCMC_Estimate_Release1(Data);


%%% Saving the results
% All variables stored in a matlab file
save('Results_HRSdata_Release1_2m.mat', 'Data', 'Results');

% Dementia probabilities and estimated cognition at HRS interviews 
data1 = csvread('data_ids.txt');
results = [data1(Data.IHRSAllBalanced,1:3), Results.PrDement, Results.PrCind, Results.PrNormal, Results.ExpCog, Results.SdCog, Results.ExpCog0, Results.SdCog0, Results.ExpCogR, Results.SdCogR, Results.ExpCogU0, Results.SdCogU0, Results.ExpCogU1, Results.SdCogU1];
save Results_HRSdataPredicted_Release1_2m.txt results -ascii -double;

results = cast(Results.CogStore,'double');
save Results_HRSdataSimulated_Release1_2m.txt results -ascii -single;

% Dementia probabilities and estimated cognition at various times before death
Idx = data1(Data.IHRSSelect1Balanced,1);
IDead = Idx(Data.DeathObservedX);
results = [IDead, Results.PrDementDead, Results.ExpCogDead, Results.SdCogDead];
save Results_HRSdataDeath_Release1_2m.txt results -ascii -double;

results = cast(Results.CogDeadStore,'double');
save Results_HRSdataDeathSim_Release1_2m.txt results -ascii -single;

% Convergence Diagnostics: save in a txt for stata
results = Results.PrevGroupsDead;
save CoefSims_GroupDead.txt results -ascii -double;

results = Results.PrevGroupsGender;
save CoefSims_GroupGender.txt results -ascii -double;

results = Results.BetaCogSim;
save CoefSims_Cog.txt results -ascii -double;


%%% Showing the interesting estimated coefficients on the screen
fprintf('Coefficients in the HRS cognition measures:\n');
Results.EstYProxy1
Results.EstYProxy2
Results.EstYSelf1
Results.EstYSelf2
Results.EstYSelf3
Results.EstYSelf4
Results.EstYAll

fprintf('Equations for missing HRS cognition measures:\n');
Results.EstYProxy2Mis
Results.EstYSelf1Mis
Results.EstYSelf2Mis
Results.EstYSelf3Mis
Results.EstYSelf4Mis
Results.EstYAllMis

fprintf('Proxy selection:\n');
Results.EstProxySel

fprintf('Latent cognition:\n');
Results.EstCog

fprintf('Survival:\n');
Results.EstSurv

fprintf('ADAMS selection:\n');
Results.EstIAdams

fprintf('ADAMS interview time:\n');
Results.EstAdamsTime

fprintf('ADAMS non-response:\n');
Results.EstAdamsResp

fprintf('Distribution of the predictor variables for modeling missing values:\n');
Results.EstPRace
Results.EstPEduc
Results.EstPForborn
Results.EstPHssc
Results.EstDSingle
Results.EstDStroke


fprintf('Dementia prevalence:\n');
mean([Results.PrDement, Results.PrCind, Results.PrNormal])
Results.EstPrevalenceCompare
Results.EstPrevalenceGender
Results.EstPrevalenceAge
Results.EstPrevalenceRace
Results.EstPrevalenceForborn
Results.EstPrevalenceEduc
Results.EstPrevalenceHssc
Results.EstPrevalenceDead

fprintf('Total run time (hours):\n');
Results.time