%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimating a joint model of latent cognition, dementia model and 
%   survival using simulated data for testing
%
% Release 1: First public release published in 2021.
%   
% Data: Simulted data following features of the Health And Retirement Study, 
%   2000-2016, age 65+
%
% Main model features:
%     - Random intercept and random slope in latent cognition (correlated)
%     - Gompertz survival
%     - Selection equation for proxy interviews
%     - HRS cognition measures modeled individually
%     - All four ADAMS waves modeled
%     - Missing data modeled with multiple imputation
%
% by P�ter Hudomiet
% August 9, 2021
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear;


% Simuating the data
Data = DataCreate_Release1;


%%% Running the estimation model
Results = MCMC_Estimate_Release1(Data);


%%% Saving the results
% All variables stored in a matlab file
save('Results_SyntheticData_Release1.mat', 'Data', 'Results');


%%% Showing the interesting estimated coefficients on the screen together
%%% with the true values 
fprintf('Coefficients in the HRS cognition measures:\n');
[Data.TrueYProxy1, Results.EstYProxy1]
[Data.TrueYProxy2, Results.EstYProxy2]
[Data.TrueYSelf1 , Results.EstYSelf1]
[Data.TrueYSelf2 , Results.EstYSelf2]
[Data.TrueYSelf3 , Results.EstYSelf3]
[Data.TrueYSelf4 , Results.EstYSelf4]
[Data.TrueYAll   , Results.EstYAll]

fprintf('Equations for missing HRS cognition measures:\n');
[Data.TrueYProxy2Mis, Results.EstYProxy2Mis]
[Data.TrueYSelf1Mis , Results.EstYSelf1Mis]
[Data.TrueYSelf2Mis , Results.EstYSelf2Mis]
[Data.TrueYSelf3Mis , Results.EstYSelf3Mis]
[Data.TrueYSelf4Mis , Results.EstYSelf4Mis]
[Data.TrueYAllMis   , Results.EstYAllMis]

fprintf('Proxy selection:\n');
[Data.TrueProxySel, Results.EstProxySel]

fprintf('Latent cognition:\n');
[Data.TrueCog, Results.EstCog]

fprintf('Survival:\n');
[Data.TrueSurv, Results.EstSurv]

fprintf('ADAMS selection:\n');
[Data.TrueIAdams, Results.EstIAdams]

fprintf('ADAMS interview time:\n');
[Data.TrueAdamsTime, Results.EstAdamsTime]

fprintf('ADAMS non-response:\n');
[Data.TrueAdamsResp, Results.EstAdamsResp]

fprintf('Distribution of the predictor variables for modeling missing values:\n');
[Data.TruePRace, Results.EstPRace]
[Data.TruePEduc, Results.EstPEduc]
[Data.TruePForborn, Results.EstPForborn]
[Data.TruePHssc, Results.EstPHssc]
[Data.TrueDSingle, Results.EstDSingle]
[Data.TrueDStroke, Results.EstDStroke]

fprintf('Dementia prevalence:\n');
mean([Data.DementedTrueBalanced(Data.IHRSAllBalanced), Data.CindTrueBalanced(Data.IHRSAllBalanced), Data.NormalcTrueBalanced(Data.IHRSAllBalanced)])
mean([Results.PrDement, Results.PrCind, Results.PrNormal])
[Data.TruePrevGroupsCompare, Results.EstPrevalenceCompare]
[Data.TruePrevGroupsGender , Results.EstPrevalenceGender]
[Data.TruePrevGroupsAge    , Results.EstPrevalenceAge]
[Data.TruePrevGroupsRace   , Results.EstPrevalenceRace]
[Data.TruePrevGroupsForborn, Results.EstPrevalenceForborn]
[Data.TruePrevGroupsEduc   , Results.EstPrevalenceEduc]
[Data.TruePrevGroupsHssc   , Results.EstPrevalenceHssc]
[Data.TruePrevGroupsDead   , Results.EstPrevalenceDead]

fprintf('Total run time (hours):\n');
Results.time