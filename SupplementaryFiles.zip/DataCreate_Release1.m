function Data = DataCreate_Release1()
%%% Creating data following the HRS and formatting for estimation

% Initializing the random number generator
rng('shuffle');
%rng(12345);

fprintf('*** Creating a synthetic datafile... ');

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Step 1: Parameters
% Basic parameters
NSizet      = 13;       % Time periods: Need to adjust manually
NSizetHRS   = NSizet-4; % Number of HRS waves
NSizetAdams = 4;        % Number of Adams waves  
NSizex      = 30000;    % Number of people   

% Cognition coefficients
BetaCog_cons = 0.8;
BetaCog_fema = 0.1;
BetaCog_ages = [-0.1, -0.05, 0];
BetaCog_race = [-0.1, -0.05, 0];
BetaCog_educ = [-0.01, 0.02, 0.03];
BetaCog_fore = -0.05;
BetaCog_hssc = [-0.05, 0.05, 0.05];
BetaCog_sing  = -0.1;
BetaCog_strok = -0.5;
BetaCog_byear = 0.01;
BetaCog_byfema = 0.05;
BetaCog_byages = [-0.05, -0.02, 0];
BetaCog_byrace = [-0.01, -0.005, 0];
BetaCog_byeduc = [-0.05, 0.1, 0.2];
BetaCog_byfore = -0.1;
BetaCog_byhssc = [-0.05, 0.1, 0.2];
BetaCog_bysing  = -0.02;
BetaCog_bystrok = -0.05;

SigmaUs = [0.7, 0.6]; % Standard deviations of the random effects terms
CorrUs  = [0.5];      % Correlations between the random effects terms
SigmaMs = 0.1;        % Standard deviation of the residual 

% Survival coefficients
GammaShape_cons = -2;
GammaShape_fema = 0.1;
GammaShape_cog  = [-0.2, -0.2];
GammaShape_race = [0.1, 0.05, 0.1];
GammaShape_educ = [0.05, -0.1, -0.15];
GammaShape_fore = 0.1;
GammaShape_hssc = [0.05, -0.1, -0.15];
GammaShape_byear = -0.01;
GammaShape_byfema = 0.005;
GammaShape_byrace = [0.01, 0.005, 0.005];
GammaShape_byeduc = [0.01, -0.005, 0];
GammaShape_byfore = 0.01;
GammaShape_byhssc = [0.005, -0.01, -0.02];
GammaScale = 0.7;

% Adams selection
BetaIAdamsProxyW5 = [0.5,-0.05];
BetaIAdamsProxyW6 = [0  ,-0.05];
BetaIAdamsSelfW5  = [0.5,-0.05];
BetaIAdamsSelfW6  = [0  ,-0.05];

% Adams interview timing
BetaIW_1 = [-2.4,-1,0.1,0,0.1,0.05];
SdIW_1   = 0.3;
BetaIW_2 = [-2,-1,0.1,0,0.1,0];
SdIW_2   = 0.1;
BetaIW_3 = [-1.6,-1,0.1,0,0.1,-0.05];
SdIW_3   = 0.1;
BetaIW_4 = [-1.2,-1,0.1,0,0.1,0];
SdIW_4   = 0.1;

% Adams respondent
BetaAResp1 = [0,-0.1,0.1];
BetaAResp2 = [0,-0.1,0.1];
BetaAResp3 = [0,-0.1,0.3];
BetaAResp4 = [0,-0.1,0.3];

% Coefficients in the HRS cognition scores
BetaCogAll_dem    = [6,0.5,0.1,0.1,0.1,0.15,0.15,0.15,0.15,0.2,0.2,0.2, 0.1, 0.1    ]; BetaCogAll_age = 0.3;    BetaCogAll_cog = -1;      SdCogAll = 1;
BetaCogProxy1_dem = [0.5,0.5,0.1,0.1,0.1,0.15,0.15,0.15,0.15,0.2,0.2,0.2, -0.1, 0.1 ]; BetaCogProxy1_age = 0.3; BetaCogProxy1_cog = -0.5; SdCogProxy1 = 0.5;
BetaCogProxy2_dem = [1,0.5,0.1,0.1,0.1,0.15,0.15,0.15,0.15,0.2,0.2,0.2, 0.1, -0.1   ]; BetaCogProxy2_age = 0.3; BetaCogProxy2_cog = -1;   SdCogProxy2 = 1;
BetaCogSelf1_dem  = [6,-0.5,0.1,0.1,0.1,0.15,0.15,0.15,0.15,0.2,0.2,0.2, 0.1, 0.1   ]; BetaCogSelf1_age = 0.3;  BetaCogSelf1_cog = 1;     BetaCogSelf1_oth = -1; SdCogSelf1 = 1;
BetaCogSelf2_dem  = [-2,-0.5,0.1,0.1,0.1,0.15,0.15,0.15,0.15,0.2,0.2,0.2, -0.1, -0.1]; BetaCogSelf2_age  = 0.3; BetaCogSelf2_cog  = 0.5;  BetaCogSelf2_oth = [-1,0.5]; SdCogSelf2 = 1;
BetaCogSelf3_dem  = [3,-0.5,0.1,0.1,0.1,0.15,0.15,0.15,0.15,0.2,0.2,0.2, 0.1, -0.1  ]; BetaCogSelf3_age = 0.3;  BetaCogSelf3_cog = 0.5;   BetaCogSelf3_oth = -1; SdCogSelf3 = 1;
BetaCogSelf4_dem  = [7,-0.5,0.1,0.1,0.1,0.15,0.15,0.15,0.15,0.2,0.2,0.2, -0.1, 0.1  ]; BetaCogSelf4_age = 0.3;  BetaCogSelf4_cog = 1;     BetaCogSelf4_oth = -1; SdCogSelf4 = 1;

% Coefficients in selection into proxy interviews
BetaIProxy_cons = 0;
BetaIProxy_fema = 0.1;
BetaIProxy_ages = [0.1, 0.1, 0.1];
BetaIProxy_race = [-0.2, -0.1, 0];
BetaIProxy_educ = [-0.1, -0.2, -0.3];
BetaIProxy_fore = 0.2;
BetaIProxy_hssc = [-0.1, -0.2, -0.3];
BetaIProxy_sing = -0.2;
BetaIProxy_strok = 0.2;
BetaIProxy_wave = -0.2;
BetaIProxy_cog  = -0.5;
BetaIProxy_wavecog = -0.5;

% Selection equations for missing HRS cognition scores
BetaMisAll_dem    = [-2,0.3,0.5,0.5,0.5,0.6,0.7,0.8,0.7,0.1,0.2,0.3,0.2,0.3]; BetaMisAll_wave=[0,0,0,-1,-1,-1,-1,-1];   BetaMisAll_age = 0.3; BetaMisAll_cog = -1; BetaMisAll_wavecog = [0, 0, 0, 0.3, 0.3, 0.2, 0.2, 0.1];
BetaMisProxy1     = 0.01;  % In the HRS there is a single missing value, so we cannot estimate a selection equation
BetaMisProxy2_dem = [-2,0.2,0.4,0.4,0.4,0.5,0.6,0.7,0.6,0.2,0.2,0.4,-0.2,-0.3]; BetaMisProxy2_wave=[0,0,0,-1,-1,-1,-1,-1]; BetaMisProxy2_age = 0.3; BetaMisProxy2_cog = -2; BetaMisProxy2_wavecog = [0, 0, 0, 0, 0.3, 0.2, 0.1, 0.1];
BetaMisSelf1_dem  = [2,-0.3,-0.5,-0.5,-0.4,-0.5,-0.6,-0.6,-0.6,-0.1,-0.2,-0.3,0.2,-0.3]; BetaMisSelf1_wave=[0,0,0,-1,-1,-1,-1,-1]; BetaMisSelf1_age = 0.3;  BetaMisSelf1_oth = -0.5; BetaMisSelf1_cog = -1; BetaMisSelf1_wavecog = [0, 0.1, 0.5, 0.5, 0.1, 0, 0.1, 0];
BetaMisSelf2_dem  = [2,-0.3,-0.4,-0.4,-0.3,-0.4,-0.7,-0.8,-0.8,-0.2,-0.2,-0.2,0.2,-0.3];   BetaMisSelf2_wave=[0,0,0,-1,-1,-1,-1,-1]; BetaMisSelf2_age  = 0.3; BetaMisSelf2_oth  = [-1,-0.1,1]; BetaMisSelf2_cog  = -0.5; BetaMisSelf2_wavecog = [0.5, 0.5, 0.5, 0, 0, 0, 0, 0];
BetaMisSelf3_dem  = [2,-0.3,-0.3,-0.5,-0.5,-0.5,-0.6,-0.8,-0.8,-0.1,-0.2,-0.3,-0.2,0.3]; BetaMisSelf3_wave=[0,0,0,-1,-1,-1,-1,-1]; BetaMisSelf3_age = 0.3;  BetaMisSelf3_oth = -1;  BetaMisSelf3_cog = -1; BetaMisSelf3_wavecog = [0, 0, 0, 0, 0, 0, 0.3, 0.3];
BetaMisSelf4_dem  = [2,-0.3,-0.5,-0.4,-0.6,-0.6,-0.6,-0.8,-0.8,-0.2,-0.2,-0.3,-0.2,0.3];   BetaMisSelf4_wave=[0,0,0,-1,-1,-1,-1,-1]; BetaMisSelf4_age = 0.3;  BetaMisSelf4_oth = [-1, 1];  BetaMisSelf4_cog = -2; BetaMisSelf4_wavecog = [0.5, 0.5, 0.5, 0.3, 0.3, 0, 0, 0];

%Distribution of time-invariant covariates
PrRaceDist = [0.15, 0.05, 0.2];
PrEducDist = [0.25, 0.25, 0.25];
PrForeDist = 0.5;
PrHsscDist = [0.25, 0.25, 0.25];

%Missing time-invariant predictors
PrRaceMis = 0.1;
PrEducMis = 0.1;
PrForeMis = 0.1;
PrHsscMis = 0.1;

% Coefficeints of the distribution of the time-varying predictors (1. distribution in period 1; 2. rate of change (n = lamda01 + lamda10); 3. ratio of 0->1 change (lamda01/(lamda01 + lamda10)))
PDistSingle = [0.2, 0.5, 0.5];
PDistStroke = [0.1, 0.3, 0.8];

%Missing time-varying predictors
PrSingleMis = 0.1;
PrStrokeMis = 0.1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Step 2: Simulating data

% Waves
aux_w4 = rand(NSizex,1);
W1 = ones(NSizex,1)*5;
W1(aux_w4>=0.5&aux_w4<0.56,1) = 6;
W1(aux_w4>=0.56&aux_w4<0.62,1) = 7;
W1(aux_w4>=0.62&aux_w4<0.68,1) = 8;
W1(aux_w4>=0.68&aux_w4<0.74,1) = 9;
W1(aux_w4>=0.74&aux_w4<0.80,1) = 10;
W1(aux_w4>=0.80&aux_w4<0.86,1) = 11;
W1(aux_w4>=0.86&aux_w4<0.92,1) = 12;
W1(aux_w4>=0.92&aux_w4<=1,1)   = 13;

% Birth year and ages (older cohorts are left censored)
RandAge1 = 0.005 + rand(NSizex,1)*0.2;
RandAge2 = 0.005 + 4*(1 - sqrt(1-rand(NSizex,1)));

A1 = RandAge1;
A1(W1==5,1) = RandAge2(W1==5);

FirstWaveYear = 1990+2*W1;
BirthYear0 = FirstWaveYear - 65 - round(A1*10);
BirthYear   = (BirthYear0-1930)/10;

% Age
AgeWideHRS      = zeros(NSizex,NSizetHRS);
AgeWideHRS(:,1) = A1;
for i = 2:NSizetHRS
    AgeWideHRS(:,i) = AgeWideHRS(:,i-1)+0.2;
end
DAgeWideHRS = AgeWideHRS(:,2:NSizetHRS)-AgeWideHRS(:,1:NSizetHRS-1);
CenterAge = 1;

% Basic demographic covariates
Female        = rand(NSizex,1)<0.5;

aux = rand(NSizex,1);
Race = zeros(NSizex,1);
Race(aux<=PrRaceDist(1)) = 1;
Race(aux>PrRaceDist(1) & aux<=PrRaceDist(1)+PrRaceDist(2)) = 2;
Race(aux>PrRaceDist(1)+PrRaceDist(2) & aux<=PrRaceDist(1)+PrRaceDist(2)+PrRaceDist(3)) = 3;

aux = rand(NSizex,1);
Educ = zeros(NSizex,1);
Educ(aux<=PrEducDist(1)) = 1;
Educ(aux>PrEducDist(1) & aux<=PrEducDist(1)+PrEducDist(2)) = 2;
Educ(aux>PrEducDist(1)+PrEducDist(2) & aux<=PrEducDist(1)+PrEducDist(2)+PrEducDist(3)) = 3;

Forborn        = rand(NSizex,1)<PrForeDist;

aux = rand(NSizex,1);
Hssc = zeros(NSizex,1);
Hssc(aux<=PrHsscDist(1)) = 1;
Hssc(aux>PrHsscDist(1) & aux<=PrHsscDist(1)+PrHsscDist(2)) = 2;
Hssc(aux>PrHsscDist(1)+PrHsscDist(2) & aux<=PrHsscDist(1)+PrHsscDist(2)+PrHsscDist(3)) = 3;

SingleWideHRS = zeros(NSizex,NSizetHRS)>0.5;
SingleWideHRS(:,1) = rand(NSizex,1)<PDistSingle(1,1);
for i=2:NSizetHRS
    aux01 = rand(NSizex,1)<(PDistSingle(1,3)*(1-exp(-PDistSingle(1,2)*DAgeWideHRS(:,i-1))));
    aux10 = rand(NSizex,1)<((1-PDistSingle(1,3))*(1-exp(-PDistSingle(1,2)*DAgeWideHRS(:,i-1))));
    SingleWideHRS(SingleWideHRS(:,i-1)==0,i)=0;
    SingleWideHRS(SingleWideHRS(:,i-1)==0 & aux01==1,i)=1;
    SingleWideHRS(SingleWideHRS(:,i-1)==1,i)=1;
    SingleWideHRS(SingleWideHRS(:,i-1)==1 & aux10==1,i)=0;
end

StrokeWideHRS = zeros(NSizex,NSizetHRS)>0.5;
StrokeWideHRS(:,1) = rand(NSizex,1)<PDistStroke(1,1);
for i=2:NSizetHRS
    aux01 = rand(NSizex,1)<(PDistStroke(1,3)*(1-exp(-PDistStroke(1,2)*DAgeWideHRS(:,i-1))));
    aux10 = rand(NSizex,1)<((1-PDistStroke(1,3))*(1-exp(-PDistStroke(1,2)*DAgeWideHRS(:,i-1))));
    StrokeWideHRS(StrokeWideHRS(:,i-1)==0,i)=0;
    StrokeWideHRS(StrokeWideHRS(:,i-1)==0 & aux01==1,i)=1;
    StrokeWideHRS(StrokeWideHRS(:,i-1)==1,i)=1;
    StrokeWideHRS(StrokeWideHRS(:,i-1)==1 & aux10==1,i)=0;
end


% Baseline cognition and survival
VarU = [SigmaUs(1,1)*SigmaUs(1,1),            CorrUs(1,1)*SigmaUs(1,1)*SigmaUs(1,2); ...
        CorrUs(1,1)*SigmaUs(1,1)*SigmaUs(1,2),SigmaUs(1,2)*SigmaUs(1,2)]; % Covariance matrix
cholVarU = chol(VarU);
CogUs = randn(NSizex,2)*cholVarU;
CogU0 = CogUs(:,1); CogU1 = CogUs(:,2);

LnGammaShape = GammaShape_cons + GammaShape_fema*Female + [CogU0, CogU1]*GammaShape_cog';
LnGammaShape = LnGammaShape + GammaShape_race(1)*(Race==1) + GammaShape_race(2)*(Race==2) + GammaShape_race(3)*(Race==3);
LnGammaShape = LnGammaShape + GammaShape_educ(1)*(Educ==1) + GammaShape_educ(2)*(Educ==2) + GammaShape_educ(3)*(Educ==3) + GammaShape_fore(1)*(Forborn==1);
LnGammaShape = LnGammaShape + GammaShape_hssc(1)*(Hssc==1) + GammaShape_hssc(2)*(Hssc==2) + GammaShape_hssc(3)*(Hssc==3) + GammaShape_byear*BirthYear;

Inter = GammaShape_byfema*Female + GammaShape_byrace(1)*(Race==1) + GammaShape_byrace(2)*(Race==2) + GammaShape_byrace(3)*(Race==3);
Inter = Inter + GammaShape_byeduc(1)*(Educ==1) + GammaShape_byeduc(2)*(Educ==2) + GammaShape_byeduc(3)*(Educ==3) + GammaShape_byfore(1)*(Forborn==1);
Inter = Inter + GammaShape_byhssc(1)*(Hssc==1) + GammaShape_byhssc(2)*(Hssc==2) + GammaShape_byhssc(3)*(Hssc==3);

LnGammaShape = LnGammaShape + Inter.*BirthYear;

GammaShape   = exp(LnGammaShape);
S = rand(NSizex,1);
DeathAge = ones(NSizex,1)./GammaScale .* log(1 - log(S).*GammaScale./GammaShape);


% Apply left censoring
Censored = DeathAge<A1;

Female(Censored) = [];
Race(Censored) = [];
Educ(Censored) = [];
Forborn(Censored) = [];
Hssc(Censored) = [];
W1(Censored) = [];
A1(Censored) = [];
BirthYear(Censored) = [];
CogU0(Censored) = [];
CogU1(Censored) = [];
DeathAge(Censored) = [];
AgeWideHRS(Censored,:) = [];
SingleWideHRS(Censored,:) = [];
StrokeWideHRS(Censored,:) = [];


% Final sample size
NSizex = size(A1,1);
NSize  = NSizex*NSizet;        % Total (long) sample size


%%% Step 2a: Most important variables in HRS waves (needed for ADAMS)
%Exogenous variables
FemaleWideHRS = Female*ones(1,NSizetHRS);
RaceWideHRS = Race*ones(1,NSizetHRS);
EducWideHRS = Educ*ones(1,NSizetHRS);
ForbornWideHRS = Forborn*ones(1,NSizetHRS);
HsscWideHRS = Hssc*ones(1,NSizetHRS);

XDemWideHRS = ones(NSizex,NSizetHRS,13);
XDemWideHRS(:,:,2) = FemaleWideHRS;
XDemWideHRS(:,:,3) = RaceWideHRS==1;
XDemWideHRS(:,:,4) = RaceWideHRS==2;
XDemWideHRS(:,:,5) = RaceWideHRS==3;
XDemWideHRS(:,:,6) = EducWideHRS==1;
XDemWideHRS(:,:,7) = EducWideHRS==2;
XDemWideHRS(:,:,8) = EducWideHRS==3;
XDemWideHRS(:,:,9) = ForbornWideHRS;
XDemWideHRS(:,:,10) = HsscWideHRS==1;
XDemWideHRS(:,:,11) = HsscWideHRS==2;
XDemWideHRS(:,:,12) = HsscWideHRS==3;
XDemWideHRS(:,:,13) = SingleWideHRS==1;
XDemWideHRS(:,:,14) = StrokeWideHRS==1;

WavesWideHRS  = zeros(NSizex,NSizetHRS);
WavesWideHRS(:,1) = W1;
for i = 2:NSizetHRS
    WavesWideHRS(:,i) = WavesWideHRS(:,i-1)+1;
end


%Birth year
BirthYearWideHRS = BirthYear*ones(1,NSizetHRS);

% Latent Cognition
CogU0WideHRS = CogU0 * ones(1,NSizetHRS);
CogU1WideHRS = CogU1 * ones(1,NSizetHRS);
CogMWideHRS  = randn(NSizex,NSizetHRS)*SigmaMs;

CogResidWideHRS = CogU0WideHRS + CogU1WideHRS.*(AgeWideHRS - CenterAge) + CogMWideHRS;

CogSimWideHRS = BetaCog_cons  + BetaCog_fema*FemaleWideHRS + BetaCog_ages(1)*(AgeWideHRS - CenterAge) + BetaCog_ages(2)*(AgeWideHRS - CenterAge).^2 + BetaCog_ages(3)*(AgeWideHRS - CenterAge).^3;
CogSimWideHRS = CogSimWideHRS + BetaCog_race(1)*(RaceWideHRS==1) + BetaCog_race(2)*(RaceWideHRS==2) + BetaCog_race(3)*(RaceWideHRS==3);
CogSimWideHRS = CogSimWideHRS + BetaCog_educ(1)*(EducWideHRS==1) + BetaCog_educ(2)*(EducWideHRS==2) + BetaCog_educ(3)*(EducWideHRS==3) + BetaCog_fore(1)*(ForbornWideHRS==1);
CogSimWideHRS = CogSimWideHRS + BetaCog_hssc(1)*(HsscWideHRS==1) + BetaCog_hssc(2)*(HsscWideHRS==2) + BetaCog_hssc(3)*(HsscWideHRS==3);
CogSimWideHRS = CogSimWideHRS + BetaCog_byear*BirthYearWideHRS + BetaCog_sing*SingleWideHRS + BetaCog_strok*StrokeWideHRS + CogResidWideHRS;

Inter = BetaCog_byfema*FemaleWideHRS + BetaCog_byages(1)*(AgeWideHRS - CenterAge) + BetaCog_byages(2)*(AgeWideHRS - CenterAge).^2 + BetaCog_byages(3)*(AgeWideHRS - CenterAge).^3;
Inter = Inter + BetaCog_byrace(1)*(RaceWideHRS==1) + BetaCog_byrace(2)*(RaceWideHRS==2) + BetaCog_byrace(3)*(RaceWideHRS==3);
Inter = Inter + BetaCog_byeduc(1)*(EducWideHRS==1) + BetaCog_byeduc(2)*(EducWideHRS==2) + BetaCog_byeduc(3)*(EducWideHRS==3) + BetaCog_byfore(1)*(ForbornWideHRS==1);
Inter = Inter + BetaCog_byhssc(1)*(HsscWideHRS==1) + BetaCog_byhssc(2)*(HsscWideHRS==2) + BetaCog_byhssc(3)*(HsscWideHRS==3);
Inter = Inter + BetaCog_bysing(1)*SingleWideHRS + BetaCog_bystrok(1)*StrokeWideHRS;

CogSimWideHRS = CogSimWideHRS + Inter.*BirthYearWideHRS;

% Proxy status
ProxyStarHRS= BetaIProxy_cons  + BetaIProxy_fema*FemaleWideHRS + BetaIProxy_ages(1)*(AgeWideHRS - CenterAge) + BetaIProxy_ages(2)*(AgeWideHRS - CenterAge).^2 + BetaIProxy_ages(3)*(AgeWideHRS - CenterAge).^3;
ProxyStarHRS= ProxyStarHRS+ BetaIProxy_race(1)*(RaceWideHRS==1) + BetaIProxy_race(2)*(RaceWideHRS==2) + BetaIProxy_race(3)*(RaceWideHRS==3);
ProxyStarHRS= ProxyStarHRS+ BetaIProxy_educ(1)*(EducWideHRS==1) + BetaIProxy_educ(2)*(EducWideHRS==2) + BetaIProxy_educ(3)*(EducWideHRS==3) + BetaIProxy_fore(1)*(ForbornWideHRS==1);
ProxyStarHRS= ProxyStarHRS+ BetaIProxy_hssc(1)*(HsscWideHRS==1) + BetaIProxy_hssc(2)*(HsscWideHRS==2) + BetaIProxy_hssc(3)*(HsscWideHRS==3);
ProxyStarHRS= ProxyStarHRS+ BetaIProxy_wave*(WavesWideHRS>9) + BetaIProxy_cog*CogSimWideHRS + BetaIProxy_wavecog*CogSimWideHRS.*(WavesWideHRS>9);
ProxyStarHRS= ProxyStarHRS+ BetaIProxy_sing*SingleWideHRS + BetaIProxy_strok*StrokeWideHRS;
ProxyWideHRS  = ProxyStarHRS + randn(NSizex,NSizetHRS) > 0; 
FirstSelfHRS = ProxyWideHRS <0.5;
for j=2:NSizetHRS
   for k=1:j-1
      FirstSelfHRS(ProxyWideHRS(:,k)<0.5,j) = 0; 
   end
end

% HRS cognition measures
YCogAllWideHRS  = VariableFill(BetaCogAll_dem,XDemWideHRS) + BetaCogAll_age*(AgeWideHRS - CenterAge) + BetaCogAll_cog*CogSimWideHRS + randn(NSizex,NSizetHRS)*SdCogAll; 
YCogSelf1WideHRS  = VariableFill(BetaCogSelf1_dem,XDemWideHRS) + BetaCogSelf1_age*(AgeWideHRS - CenterAge) + BetaCogSelf1_cog*CogSimWideHRS + BetaCogSelf1_oth*FirstSelfHRS + randn(NSizex,NSizetHRS)*SdCogSelf1; 
YCogSelf1WideHRS(ProxyWideHRS>0.5)=-100;
YCogSelf2WideHRS  = VariableFill(BetaCogSelf2_dem,XDemWideHRS) + BetaCogSelf2_age*(AgeWideHRS - CenterAge) + BetaCogSelf2_cog*CogSimWideHRS + BetaCogSelf2_oth(1)*FirstSelfHRS + BetaCogSelf2_oth(2)*YCogSelf1WideHRS + randn(NSizex,NSizetHRS)*SdCogSelf2; 
YCogSelf2WideHRS(ProxyWideHRS>0.5)=-100;
YCogSelf3WideHRS  = VariableFill(BetaCogSelf3_dem,XDemWideHRS) + BetaCogSelf3_age*(AgeWideHRS - CenterAge) + BetaCogSelf3_cog*CogSimWideHRS + BetaCogSelf3_oth*FirstSelfHRS + randn(NSizex,NSizetHRS)*SdCogSelf3; 
YCogSelf3WideHRS(ProxyWideHRS>0.5)=-100;
YCogSelf4WideHRS  = VariableFill(BetaCogSelf4_dem,XDemWideHRS) + BetaCogSelf4_age*(AgeWideHRS - CenterAge) + BetaCogSelf4_cog*CogSimWideHRS + BetaCogSelf4_oth*FirstSelfHRS + randn(NSizex,NSizetHRS)*SdCogSelf4; 
YCogSelf4WideHRS(ProxyWideHRS>0.5)=-100;
YCogProxy1WideHRS  = VariableFill(BetaCogProxy1_dem,XDemWideHRS) + BetaCogProxy1_age*(AgeWideHRS - CenterAge) + BetaCogProxy1_cog*CogSimWideHRS + randn(NSizex,NSizetHRS)*SdCogProxy1; 
YCogProxy1WideHRS(ProxyWideHRS<0.5)=-100;
YCogProxy2WideHRS  = VariableFill(BetaCogProxy2_dem,XDemWideHRS) + BetaCogProxy2_age*(AgeWideHRS - CenterAge) + BetaCogProxy2_cog*CogSimWideHRS + randn(NSizex,NSizetHRS)*SdCogProxy2; 
YCogProxy2WideHRS(ProxyWideHRS<0.5)=-100;

%Let's apply the bounds
YCogSelf2WideHRS(YCogSelf2WideHRS<0&YCogSelf2WideHRS>-100)=0;
YCogSelf3WideHRS(YCogSelf3WideHRS<0&YCogSelf3WideHRS>-100)=0;
YCogSelf3WideHRS(YCogSelf3WideHRS>5)=5;
YCogSelf4WideHRS(YCogSelf4WideHRS>9)=9;
YCogProxy1WideHRS(YCogProxy1WideHRS<0&YCogProxy1WideHRS>-100)=0;
YCogProxy1WideHRS(YCogProxy1WideHRS>=1)=2;
YCogProxy1WideHRS(YCogProxy1WideHRS>0&YCogProxy1WideHRS<1)=1;
YCogProxy2WideHRS(YCogProxy2WideHRS<0&YCogProxy2WideHRS>-100)=0;
YCogProxy2WideHRS(YCogProxy2WideHRS>=4)=4;


%HRS Indicator
IHRSCoreWideHRS = WavesWideHRS<=13 & AgeWideHRS<(DeathAge*ones(1,NSizetHRS));


%%% Step 2b: ADAMS waves
% Initializing
IAdamsSelectedWideAdams   = zeros(NSizex,NSizetAdams)>0.5;
IAdamsSurvivedWideAdams   = zeros(NSizex,NSizetAdams)>0.5;
IAdamsRespondentWideAdams = zeros(NSizex,NSizetAdams)>0.5;
PriorProxyWideAdams       = zeros(NSizex,NSizetAdams);
PriorAgeWideAdams         = zeros(NSizex,NSizetAdams);
PriorWaveWideAdams        = zeros(NSizex,NSizetAdams);
PriorSingleWideAdams      = zeros(NSizex,NSizetAdams);
PriorStrokeWideAdams      = zeros(NSizex,NSizetAdams);
SingleWideAdams           = zeros(NSizex,NSizetAdams);
StrokeWideAdams           = zeros(NSizex,NSizetAdams);
NextSingleWideAdams       = zeros(NSizex,NSizetAdams);
NextStrokeWideAdams       = zeros(NSizex,NSizetAdams);
NextAgeWideAdams          = zeros(NSizex,NSizetAdams);
PriorCogSimWideAdams      = zeros(NSizex,NSizetAdams);
AgeWideAdams              = zeros(NSizex,NSizetAdams);
CogResidWideAdams         = zeros(NSizex,NSizetAdams);
CogSimWideAdams           = zeros(NSizex,NSizetAdams);


% Getting important HRS values from HRS waves 5 & 6 (prior waves)
AnyWave5 = sum(WavesWideHRS==5&IHRSCoreWideHRS>0.5,2)>0.5;
AnyWave6 = sum(WavesWideHRS==6&IHRSCoreWideHRS>0.5,2)>0.5;

aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==5) = AgeWideHRS(WavesWideHRS==5);
AgeWave5 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==6) = AgeWideHRS(WavesWideHRS==6);
AgeWave6 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==7) = AgeWideHRS(WavesWideHRS==7);
AgeWave7 = sum(aux,2);

aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==5) = CogSimWideHRS(WavesWideHRS==5);
CogSimWave5 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==6) = CogSimWideHRS(WavesWideHRS==6);
CogSimWave6 = sum(aux,2);

aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==5) = ProxyWideHRS(WavesWideHRS==5);
ProxyWave5 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==6) = ProxyWideHRS(WavesWideHRS==6);
ProxyWave6 = sum(aux,2);

aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==5&ProxyWideHRS<0.5) = YCogSelf1WideHRS(WavesWideHRS==5&ProxyWideHRS<0.5);
YCogLinearSelfWave5 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==6&ProxyWideHRS<0.5) = YCogSelf1WideHRS(WavesWideHRS==6&ProxyWideHRS<0.5);
YCogLinearSelfWave6 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==5&ProxyWideHRS>0.5) = YCogProxy1WideHRS(WavesWideHRS==5&ProxyWideHRS>0.5);
YCogLinearProxyWave5 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==6&ProxyWideHRS>0.5) = YCogProxy1WideHRS(WavesWideHRS==6&ProxyWideHRS>0.5);
YCogLinearProxyWave6 = sum(aux,2);

aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==5) = SingleWideHRS(WavesWideHRS==5);
SingleWave5 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==6) = SingleWideHRS(WavesWideHRS==6);
SingleWave6 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==7) = SingleWideHRS(WavesWideHRS==7);
SingleWave7 = sum(aux,2);

aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==5) = StrokeWideHRS(WavesWideHRS==5);
StrokeWave5 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==6) = StrokeWideHRS(WavesWideHRS==6);
StrokeWave6 = sum(aux,2);
aux = zeros(NSizex,NSizetHRS);
aux(WavesWideHRS==7) = StrokeWideHRS(WavesWideHRS==7);
StrokeWave7 = sum(aux,2);


% ADAMS WA selection
SelW5Self = (AnyWave5>0.5) & (ProxyWave5<0.5) & (BetaIAdamsSelfW5(1) + BetaIAdamsSelfW5(2)*YCogLinearSelfWave5 + randn(NSizex,1)>0);
IAdamsSelectedWideAdams(SelW5Self,1) = 1;

SelW5Proxy = (AnyWave5>0.5) & (ProxyWave5>0.5) & (BetaIAdamsProxyW5(1) + BetaIAdamsProxyW5(2)*YCogLinearProxyWave5 + randn(NSizex,1)>0);
IAdamsSelectedWideAdams(SelW5Proxy,1) = 1 ;

SelW5 = SelW5Self | SelW5Proxy;
PriorProxyWideAdams(SelW5,1)  = ProxyWave5(SelW5);
PriorAgeWideAdams(SelW5,1)    = AgeWave5(SelW5);
NextAgeWideAdams(SelW5,1)     = AgeWave6(SelW5);
PriorCogSimWideAdams(SelW5,1) = CogSimWave5(SelW5);
PriorSingleWideAdams(SelW5,1) = SingleWave5(SelW5);
NextSingleWideAdams(SelW5,1)  = SingleWave6(SelW5);
PriorStrokeWideAdams(SelW5,1) = StrokeWave5(SelW5);
NextStrokeWideAdams(SelW5,1)  = StrokeWave6(SelW5);
PriorWaveWideAdams(SelW5,1)   = 5;

SelW6Self = (SelW5<0.5) & (AnyWave6>0.5) & (ProxyWave6<0.5) & (BetaIAdamsSelfW6(1) + BetaIAdamsSelfW6(2)*YCogLinearSelfWave6 + randn(NSizex,1)>0);
IAdamsSelectedWideAdams(SelW6Self,1) = 1 ;

SelW6Proxy = (SelW5<0.5) & (AnyWave6>0.5) & (ProxyWave6>0.5) & (BetaIAdamsProxyW6(1) + BetaIAdamsProxyW6(2)*YCogLinearProxyWave6 + randn(NSizex,1)>0);
IAdamsSelectedWideAdams(SelW6Proxy,1) = 1 ;

SelW6 = SelW6Self | SelW6Proxy;
PriorProxyWideAdams(SelW6,1)  = ProxyWave6(SelW6);
PriorAgeWideAdams(SelW6,1)    = AgeWave6(SelW6);
NextAgeWideAdams(SelW6,1)     = AgeWave7(SelW6);
PriorCogSimWideAdams(SelW6,1) = CogSimWave6(SelW6);
PriorSingleWideAdams(SelW6,1) = SingleWave6(SelW6);
NextSingleWideAdams(SelW6,1)  = SingleWave7(SelW6);
PriorStrokeWideAdams(SelW6,1) = StrokeWave6(SelW6);
NextStrokeWideAdams(SelW6,1)  = StrokeWave7(SelW6);
PriorWaveWideAdams(SelW6,1)   = 6;

% ADAMS WA interview time 
IWTime_Pot = exp(BetaIW_1(1) + BetaIW_1(2)*(PriorWaveWideAdams(:,1)==6) + BetaIW_1(3)*PriorAgeWideAdams(:,1) + BetaIW_1(4)*(PriorWaveWideAdams(:,1)==6).*PriorAgeWideAdams(:,1) + BetaIW_1(5)*PriorCogSimWideAdams(:,1) + BetaIW_1(6)*(PriorWaveWideAdams(:,1)==6).*PriorCogSimWideAdams(:,1) + randn(NSizex,1)*SdIW_1);
IWTime_Pot(IWTime_Pot>0.2) = 0.19; % Has to be before the next HRS interview
AgeWideAdams(IAdamsSelectedWideAdams(:,1),1) = PriorAgeWideAdams(IAdamsSelectedWideAdams(:,1),1) + IWTime_Pot(IAdamsSelectedWideAdams(:,1));

a0 = PriorAgeWideAdams(:,1);
a1 = AgeWideAdams(:,1);
a2 = NextAgeWideAdams(:,1);

pSingle01t1 = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle10t1 = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle01t  = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a2-a1)));
pSingle10t  = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a2-a1)));

% Marital status and stroke (as a function of values in the previous and next waves)
PSinglePosterior = zeros(NSizex,1);
indic = PriorSingleWideAdams(:,1)==0 & NextSingleWideAdams(:,1)==0;
PP1 = pSingle10t(indic).*pSingle01t1(indic);
PP0 = (1-pSingle01t1(indic)).*(1-pSingle01t(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,1)==1 & NextSingleWideAdams(:,1)==0;
PP1 = pSingle10t(indic).*(1-pSingle10t1(indic));
PP0 = (1-pSingle01t(indic)).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,1)==0 & NextSingleWideAdams(:,1)==1;
PP1 = (1-pSingle10t(indic)).*pSingle01t1(indic);
PP0 = pSingle01t(indic).*(1-pSingle01t1(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,1)==1 & NextSingleWideAdams(:,1)==1;
PP1 = (1-pSingle10t(indic)).*(1-pSingle10t1(indic));
PP0 = pSingle01t(indic).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
SingleWideAdams(:,1) = rand(NSizex,1)< PSinglePosterior;

pStroke01t1 = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke10t1 = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke01t  = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a2-a1)));
pStroke10t  = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a2-a1)));

PStrokePosterior = zeros(NSizex,1);
indic = PriorStrokeWideAdams(:,1)==0 & NextStrokeWideAdams(:,1)==0;
PP1 = pStroke10t(indic).*pStroke01t1(indic);
PP0 = (1-pStroke01t1(indic)).*(1-pStroke01t(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,1)==1 & NextStrokeWideAdams(:,1)==0;
PP1 = pStroke10t(indic).*(1-pStroke10t1(indic));
PP0 = (1-pStroke01t(indic)).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,1)==0 & NextStrokeWideAdams(:,1)==1;
PP1 = (1-pStroke10t(indic)).*pStroke01t1(indic);
PP0 = pStroke01t(indic).*(1-pStroke01t1(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,1)==1 & NextStrokeWideAdams(:,1)==1;
PP1 = (1-pStroke10t(indic)).*(1-pStroke10t1(indic));
PP0 = pStroke01t(indic).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
StrokeWideAdams(:,1) = rand(NSizex,1)< PStrokePosterior;

%Adams WA cognition
CogResidWideAdams(:,1) = CogU0 + CogU1.*(AgeWideAdams(:,1) - CenterAge) + randn(NSizex,1)*SigmaMs;
CogSimWideAdams(:,1) = BetaCog_cons  + BetaCog_fema*Female + BetaCog_ages(1)*(AgeWideAdams(:,1) - CenterAge) + BetaCog_ages(2)*(AgeWideAdams(:,1) - CenterAge).^2 + BetaCog_ages(3)*(AgeWideAdams(:,1) - CenterAge).^3;
CogSimWideAdams(:,1) = CogSimWideAdams(:,1) + BetaCog_race(1)*(Race==1) + BetaCog_race(2)*(Race==2) + BetaCog_race(3)*(Race==3);
CogSimWideAdams(:,1) = CogSimWideAdams(:,1) + BetaCog_educ(1)*(Educ==1) + BetaCog_educ(2)*(Educ==2) + BetaCog_educ(3)*(Educ==3) + BetaCog_fore(1)*(Forborn==1);
CogSimWideAdams(:,1) = CogSimWideAdams(:,1) + BetaCog_hssc(1)*(Hssc==1) + BetaCog_hssc(2)*(Hssc==2) + BetaCog_hssc(3)*(Hssc==3);
CogSimWideAdams(:,1) = CogSimWideAdams(:,1) + BetaCog_byear*BirthYear + BetaCog_sing*SingleWideAdams(:,1) + BetaCog_strok*StrokeWideAdams(:,1) + CogResidWideAdams(:,1);

Inter = BetaCog_byfema*Female + BetaCog_byages(1)*(AgeWideAdams(:,1) - CenterAge) + BetaCog_byages(2)*(AgeWideAdams(:,1) - CenterAge).^2 + BetaCog_byages(3)*(AgeWideAdams(:,1) - CenterAge).^3;
Inter = Inter + BetaCog_byrace(1)*(Race==1) + BetaCog_byrace(2)*(Race==2) + BetaCog_byrace(3)*(Race==3);
Inter = Inter + BetaCog_byeduc(1)*(Educ==1) + BetaCog_byeduc(2)*(Educ==2) + BetaCog_byeduc(3)*(Educ==3) + BetaCog_byfore(1)*(Forborn==1);
Inter = Inter + BetaCog_byhssc(1)*(Hssc==1) + BetaCog_byhssc(2)*(Hssc==2) + BetaCog_byhssc(3)*(Hssc==3);
Inter = Inter + BetaCog_bysing*SingleWideAdams(:,1) + BetaCog_bystrok*StrokeWideAdams(:,1);

CogSimWideAdams(:,1) = CogSimWideAdams(:,1) + Inter.*BirthYear;

CogResidWideAdams(IAdamsSelectedWideAdams(:,1)<0.5,1)=0;
CogSimWideAdams(IAdamsSelectedWideAdams(:,1)<0.5,1)=0;

%ADAMS WA survival
IAdamsSurvivedWideAdams((IAdamsSelectedWideAdams(:,1)>0.5) & (AgeWideAdams(:,1)<DeathAge),1) = 1;

%Adams respondent
AdamsResp_Pot = BetaAResp1(1) + BetaAResp1(2)*AgeWideAdams(:,1) + BetaAResp1(3)*CogSimWideAdams(:,1) + randn(NSizex,1)>0;
IAdamsRespondentWideAdams(((IAdamsSurvivedWideAdams(:,1)>0.5) & (AdamsResp_Pot==1)),1) = 1;


%ADAMS WB selection
IAdamsSelectedWideAdams((IAdamsRespondentWideAdams(:,1)>0.5) & (CogSimWideAdams(:,1)>-0.1) & (CogSimWideAdams(:,1)<1.1),2) = 1;

% ADAMS WB interview time 
IWTime_Pot = exp(BetaIW_2(1) + BetaIW_2(2)*(PriorWaveWideAdams(:,1)==6) + BetaIW_2(3)*AgeWideAdams(:,1) + BetaIW_2(4)*(PriorWaveWideAdams(:,1)==6).*AgeWideAdams(:,1) + BetaIW_2(5)*CogSimWideAdams(:,1) + BetaIW_2(6)*(PriorWaveWideAdams(:,1)==6).*CogSimWideAdams(:,1) + randn(NSizex,1)*SdIW_2);
AgeWideAdams(IAdamsSelectedWideAdams(:,2),2) = AgeWideAdams(IAdamsSelectedWideAdams(:,2),1) + IWTime_Pot(IAdamsSelectedWideAdams(:,2));

%Adams WB cognition
allage = [AgeWideHRS,AgeWideAdams];
Iprev = zeros(NSizex,NSizet)>0.5;
allage2 = allage;
allage2(allage>=(AgeWideAdams(:,2)*ones(1,NSizet))) = 0;
mallage = max(allage2,[],2)*ones(1,NSizet);
Iprev(allage2==mallage) = 1;
Iprev(IAdamsSelectedWideAdams(:,2)<0.5,:) = 0;

Inext = zeros(NSizex,NSizet)>0.5;
allage2 = allage;
allage2(allage<=(AgeWideAdams(:,2)*ones(1,NSizet))) = 100;
mallage = min(allage2,[],2)*ones(1,NSizet);
Inext(allage2==mallage) = 1;
Inext(IAdamsSelectedWideAdams(:,2)<0.5,:) = 0;

aux = zeros(NSizex,NSizet);
aux(Iprev) = allage(Iprev);
PriorAgeWideAdams(:,2) = max(aux,[],2);
aux = zeros(NSizex,NSizet);
aux(Inext) = allage(Inext);
NextAgeWideAdams(:,2) = max(aux,[],2);

allproxy = [ProxyWideHRS,PriorProxyWideAdams(:,1), zeros(NSizex,3)];
aux = zeros(NSizex,NSizet);
aux(Iprev) = allproxy(Iprev);
PriorProxyWideAdams(:,2) = max(aux,[],2);

allageh = [AgeWideHRS,ones(NSizex,NSizetAdams)*100];
Iprevh = zeros(NSizex,NSizet)>0.5;
allageh2 = allageh;
allageh2(allageh>=(AgeWideAdams(:,2)*ones(1,NSizet))) = 0;
mallageh = max(allageh2,[],2)*ones(1,NSizet);
Iprevh(allageh2==mallageh) = 1;
Iprevh(IAdamsSelectedWideAdams(:,2)<0.5,:) = 0;
allwaves = [WavesWideHRS,zeros(NSizex,NSizetAdams)];
aux = zeros(NSizex,NSizet);
aux(Iprevh) = allwaves(Iprevh);
PriorWaveWideAdams(:,2) = max(aux,[],2);

allsingle = [SingleWideHRS,SingleWideAdams];
aux = -100*ones(NSizex,NSizet);
aux(Iprev) = allsingle(Iprev);
PriorSingleWideAdams(:,2) = max(aux,[],2);
PriorSingleWideAdams(PriorSingleWideAdams(:,2)==-100,2)=0;
aux = -100*ones(NSizex,NSizet);
aux(Inext) = allsingle(Inext);
NextSingleWideAdams(:,2) = max(aux,[],2);
NextSingleWideAdams(NextSingleWideAdams(:,2)==-100,2)=0;

allstroke = [StrokeWideHRS,StrokeWideAdams];
aux = -100*ones(NSizex,NSizet);
aux(Iprev) = allstroke(Iprev);
PriorStrokeWideAdams(:,2) = max(aux,[],2);
PriorStrokeWideAdams(PriorStrokeWideAdams(:,2)==-100,2)=0;
aux = -100*ones(NSizex,NSizet);
aux(Inext) = allstroke(Inext);
NextStrokeWideAdams(:,2) = max(aux,[],2);
NextStrokeWideAdams(NextStrokeWideAdams(:,2)==-100,2)=0;


a0 = PriorAgeWideAdams(:,2);
a1 = AgeWideAdams(:,2);
a2 = NextAgeWideAdams(:,2);

pSingle01t1 = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle10t1 = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle01t  = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a2-a1)));
pSingle10t  = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a2-a1)));

PSinglePosterior = zeros(NSizex,1);
indic = PriorSingleWideAdams(:,2)==0 & NextSingleWideAdams(:,2)==0;
PP1 = pSingle10t(indic).*pSingle01t1(indic);
PP0 = (1-pSingle01t1(indic)).*(1-pSingle01t(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,2)==1 & NextSingleWideAdams(:,2)==0;
PP1 = pSingle10t(indic).*(1-pSingle10t1(indic));
PP0 = (1-pSingle01t(indic)).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,2)==0 & NextSingleWideAdams(:,2)==1;
PP1 = (1-pSingle10t(indic)).*pSingle01t1(indic);
PP0 = pSingle01t(indic).*(1-pSingle01t1(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,2)==1 & NextSingleWideAdams(:,2)==1;
PP1 = (1-pSingle10t(indic)).*(1-pSingle10t1(indic));
PP0 = pSingle01t(indic).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
SingleWideAdams(:,2) = rand(NSizex,1)< PSinglePosterior;

pStroke01t1 = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke10t1 = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke01t  = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a2-a1)));
pStroke10t  = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a2-a1)));

PStrokePosterior = zeros(NSizex,1);
indic = PriorStrokeWideAdams(:,2)==0 & NextStrokeWideAdams(:,2)==0;
PP1 = pStroke10t(indic).*pStroke01t1(indic);
PP0 = (1-pStroke01t1(indic)).*(1-pStroke01t(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,2)==1 & NextStrokeWideAdams(:,2)==0;
PP1 = pStroke10t(indic).*(1-pStroke10t1(indic));
PP0 = (1-pStroke01t(indic)).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,2)==0 & NextStrokeWideAdams(:,2)==1;
PP1 = (1-pStroke10t(indic)).*pStroke01t1(indic);
PP0 = pStroke01t(indic).*(1-pStroke01t1(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,2)==1 & NextStrokeWideAdams(:,2)==1;
PP1 = (1-pStroke10t(indic)).*(1-pStroke10t1(indic));
PP0 = pStroke01t(indic).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
StrokeWideAdams(:,2) = rand(NSizex,1)< PStrokePosterior;


CogResidWideAdams(:,2) = CogU0 + CogU1.*(AgeWideAdams(:,2) - CenterAge) + randn(NSizex,1)*SigmaMs;
CogSimWideAdams(:,2) = BetaCog_cons  + BetaCog_fema*Female + BetaCog_ages(1)*(AgeWideAdams(:,2) - CenterAge) + BetaCog_ages(2)*(AgeWideAdams(:,2) - CenterAge).^2 + BetaCog_ages(3)*(AgeWideAdams(:,2) - CenterAge).^3;
CogSimWideAdams(:,2) = CogSimWideAdams(:,2) + BetaCog_race(1)*(Race==1) + BetaCog_race(2)*(Race==2) + BetaCog_race(3)*(Race==3);
CogSimWideAdams(:,2) = CogSimWideAdams(:,2) + BetaCog_educ(1)*(Educ==1) + BetaCog_educ(2)*(Educ==2) + BetaCog_educ(3)*(Educ==3) + BetaCog_fore(1)*(Forborn==1);
CogSimWideAdams(:,2) = CogSimWideAdams(:,2) + BetaCog_hssc(1)*(Hssc==1) + BetaCog_hssc(2)*(Hssc==2) + BetaCog_hssc(3)*(Hssc==3);
CogSimWideAdams(:,2) = CogSimWideAdams(:,2) + BetaCog_byear*BirthYear + BetaCog_sing*SingleWideAdams(:,2) + BetaCog_strok*StrokeWideAdams(:,2) + CogResidWideAdams(:,2);

Inter = BetaCog_byfema*Female + BetaCog_byages(1)*(AgeWideAdams(:,2) - CenterAge) + BetaCog_byages(2)*(AgeWideAdams(:,2) - CenterAge).^2 + BetaCog_byages(3)*(AgeWideAdams(:,2) - CenterAge).^3;
Inter = Inter + BetaCog_byrace(1)*(Race==1) + BetaCog_byrace(2)*(Race==2) + BetaCog_byrace(3)*(Race==3);
Inter = Inter + BetaCog_byeduc(1)*(Educ==1) + BetaCog_byeduc(2)*(Educ==2) + BetaCog_byeduc(3)*(Educ==3) + BetaCog_byfore(1)*(Forborn==1);
Inter = Inter + BetaCog_byhssc(1)*(Hssc==1) + BetaCog_byhssc(2)*(Hssc==2) + BetaCog_byhssc(3)*(Hssc==3);
Inter = Inter +  BetaCog_bysing*SingleWideAdams(:,2) + BetaCog_bystrok*StrokeWideAdams(:,2);

CogSimWideAdams(:,2) = CogSimWideAdams(:,2) + Inter.*BirthYear;

CogResidWideAdams(IAdamsSelectedWideAdams(:,2)<0.5,2)=0;
CogSimWideAdams(IAdamsSelectedWideAdams(:,2)<0.5,2)=0;

%ADAMS WB survival
IAdamsSurvivedWideAdams((IAdamsSelectedWideAdams(:,2)>0.5) & (AgeWideAdams(:,2)<DeathAge),2) = 1;

%Adams respondent
AdamsResp_Pot = BetaAResp2(1) + BetaAResp2(2)*AgeWideAdams(:,2) + BetaAResp2(3)*CogSimWideAdams(:,2) + randn(NSizex,1)>0;
IAdamsRespondentWideAdams(((IAdamsSurvivedWideAdams(:,2)>0.5) & (AdamsResp_Pot==1)),2) = 1;


%ADAMS WC selection
IAdamsSelectedWideAdams((IAdamsRespondentWideAdams(:,1)>0.5) & (CogSimWideAdams(:,1)>=0),3) = 1;
IAdamsSelectedWideAdams((IAdamsRespondentWideAdams(:,2)>0.5) & (CogSimWideAdams(:,2)<0),3) = 0;
IAdamsSelectedWideAdams((IAdamsSelectedWideAdams(:,2)>0.5)   & (IAdamsSurvivedWideAdams(:,2)<0.5),3) = 0;

% ADAMS WC interview time 
IWTime_Pot = exp(BetaIW_3(1) + BetaIW_3(2)*(PriorWaveWideAdams(:,1)==6) + BetaIW_3(3)*AgeWideAdams(:,1) + BetaIW_3(4)*(PriorWaveWideAdams(:,1)==6).*AgeWideAdams(:,1) + BetaIW_3(5)*CogSimWideAdams(:,1) + BetaIW_3(6)*(PriorWaveWideAdams(:,1)==6).*CogSimWideAdams(:,1) + randn(NSizex,1)*SdIW_3);
AgeWideAdams(IAdamsSelectedWideAdams(:,3),3) = AgeWideAdams(IAdamsSelectedWideAdams(:,3),1) + IWTime_Pot(IAdamsSelectedWideAdams(:,3));

mean(AgeWideAdams(IAdamsSelectedWideAdams(:,3),:));
sum(AgeWideAdams(:,3)<AgeWideAdams(:,2) & IAdamsSelectedWideAdams(:,3));
%Observations with too small age are overwritten
aux = AgeWideAdams(:,3)<AgeWideAdams(:,2) & IAdamsSelectedWideAdams(:,3);
AgeWideAdams(aux,3) = AgeWideAdams(aux,2) + 0.05; 

%Adams WC cognition
allage = [AgeWideHRS,AgeWideAdams];
Iprev = zeros(NSizex,NSizet)>0.5;
allage2 = allage;
allage2(allage>=(AgeWideAdams(:,3)*ones(1,NSizet))) = 0;
mallage = max(allage2,[],2)*ones(1,NSizet);
Iprev(allage2==mallage) = 1;
Iprev(IAdamsSelectedWideAdams(:,3)<0.5,:) = 0;

Inext = zeros(NSizex,NSizet)>0.5;
allage2 = allage;
allage2(allage<=(AgeWideAdams(:,3)*ones(1,NSizet))) = 100;
mallage = min(allage2,[],2)*ones(1,NSizet);
Inext(allage2==mallage) = 1;
Inext(IAdamsSelectedWideAdams(:,3)<0.5,:) = 0;

aux = zeros(NSizex,NSizet);
aux(Iprev) = allage(Iprev);
PriorAgeWideAdams(:,3) = max(aux,[],2);
aux = zeros(NSizex,NSizet);
aux(Inext) = allage(Inext);
NextAgeWideAdams(:,3) = max(aux,[],2);

allproxy = [ProxyWideHRS,PriorProxyWideAdams(:,1:2), zeros(NSizex,2)];
aux = zeros(NSizex,NSizet);
aux(Iprev) = allproxy(Iprev);
PriorProxyWideAdams(:,3) = max(aux,[],2);

allageh = [AgeWideHRS,ones(NSizex,NSizetAdams)*100];
Iprevh = zeros(NSizex,NSizet)>0.5;
allageh2 = allageh;
allageh2(allageh>=(AgeWideAdams(:,3)*ones(1,NSizet))) = 0;
mallageh = max(allageh2,[],2)*ones(1,NSizet);
Iprevh(allageh2==mallageh) = 1;
Iprevh(IAdamsSelectedWideAdams(:,3)<0.5,:) = 0;
allwaves = [WavesWideHRS,zeros(NSizex,NSizetAdams)];
aux = zeros(NSizex,NSizet);
aux(Iprevh) = allwaves(Iprevh);
PriorWaveWideAdams(:,3) = max(aux,[],2);

allsingle = [SingleWideHRS,SingleWideAdams];
aux = -100*ones(NSizex,NSizet);
aux(Iprev) = allsingle(Iprev);
PriorSingleWideAdams(:,3) = max(aux,[],2);
PriorSingleWideAdams(PriorSingleWideAdams(:,3)==-100,3)=0;
aux = -100*ones(NSizex,NSizet);
aux(Inext) = allsingle(Inext);
NextSingleWideAdams(:,3) = max(aux,[],2);
NextSingleWideAdams(NextSingleWideAdams(:,3)==-100,3)=0;

allstroke = [StrokeWideHRS,StrokeWideAdams];
aux = -100*ones(NSizex,NSizet);
aux(Iprev) = allstroke(Iprev);
PriorStrokeWideAdams(:,3) = max(aux,[],2);
PriorStrokeWideAdams(PriorStrokeWideAdams(:,3)==-100,3)=0;
aux = -100*ones(NSizex,NSizet);
aux(Inext) = allstroke(Inext);
NextStrokeWideAdams(:,3) = max(aux,[],2);
NextStrokeWideAdams(NextStrokeWideAdams(:,3)==-100,3)=0;

a0 = PriorAgeWideAdams(:,3);
a1 = AgeWideAdams(:,3);
a2 = NextAgeWideAdams(:,3);

pSingle01t1 = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle10t1 = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle01t  = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a2-a1)));
pSingle10t  = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a2-a1)));

PSinglePosterior = zeros(NSizex,1);
indic = PriorSingleWideAdams(:,3)==0 & NextSingleWideAdams(:,3)==0;
PP1 = pSingle10t(indic).*pSingle01t1(indic);
PP0 = (1-pSingle01t1(indic)).*(1-pSingle01t(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,3)==1 & NextSingleWideAdams(:,3)==0;
PP1 = pSingle10t(indic).*(1-pSingle10t1(indic));
PP0 = (1-pSingle01t(indic)).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,3)==0 & NextSingleWideAdams(:,3)==1;
PP1 = (1-pSingle10t(indic)).*pSingle01t1(indic);
PP0 = pSingle01t(indic).*(1-pSingle01t1(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,3)==1 & NextSingleWideAdams(:,3)==1;
PP1 = (1-pSingle10t(indic)).*(1-pSingle10t1(indic));
PP0 = pSingle01t(indic).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
SingleWideAdams(:,3) = rand(NSizex,1)< PSinglePosterior;

pStroke01t1 = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke10t1 = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke01t  = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a2-a1)));
pStroke10t  = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a2-a1)));

PStrokePosterior = zeros(NSizex,1);
indic = PriorStrokeWideAdams(:,3)==0 & NextStrokeWideAdams(:,3)==0;
PP1 = pStroke10t(indic).*pStroke01t1(indic);
PP0 = (1-pStroke01t1(indic)).*(1-pStroke01t(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,3)==1 & NextStrokeWideAdams(:,3)==0;
PP1 = pStroke10t(indic).*(1-pStroke10t1(indic));
PP0 = (1-pStroke01t(indic)).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,3)==0 & NextStrokeWideAdams(:,3)==1;
PP1 = (1-pStroke10t(indic)).*pStroke01t1(indic);
PP0 = pStroke01t(indic).*(1-pStroke01t1(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,3)==1 & NextStrokeWideAdams(:,3)==1;
PP1 = (1-pStroke10t(indic)).*(1-pStroke10t1(indic));
PP0 = pStroke01t(indic).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
StrokeWideAdams(:,3) = rand(NSizex,1)< PStrokePosterior;


CogResidWideAdams(:,3) = CogU0 + CogU1.*(AgeWideAdams(:,3) - CenterAge) + randn(NSizex,1)*SigmaMs;
CogSimWideAdams(:,3) = BetaCog_cons  + BetaCog_fema*Female + BetaCog_ages(1)*(AgeWideAdams(:,3) - CenterAge) + BetaCog_ages(2)*(AgeWideAdams(:,3) - CenterAge).^2 + BetaCog_ages(3)*(AgeWideAdams(:,3) - CenterAge).^3;
CogSimWideAdams(:,3) = CogSimWideAdams(:,3) + BetaCog_race(1)*(Race==1) + BetaCog_race(2)*(Race==2) + BetaCog_race(3)*(Race==3);
CogSimWideAdams(:,3) = CogSimWideAdams(:,3) + BetaCog_educ(1)*(Educ==1) + BetaCog_educ(2)*(Educ==2) + BetaCog_educ(3)*(Educ==3) + BetaCog_fore(1)*(Forborn==1);
CogSimWideAdams(:,3) = CogSimWideAdams(:,3) + BetaCog_hssc(1)*(Hssc==1) + BetaCog_hssc(2)*(Hssc==2) + BetaCog_hssc(3)*(Hssc==3);
CogSimWideAdams(:,3) = CogSimWideAdams(:,3) + BetaCog_byear*BirthYear + BetaCog_sing*SingleWideAdams(:,3) + BetaCog_strok*StrokeWideAdams(:,3) + CogResidWideAdams(:,3);

Inter = BetaCog_byfema*Female + BetaCog_byages(1)*(AgeWideAdams(:,3) - CenterAge) + BetaCog_byages(2)*(AgeWideAdams(:,3) - CenterAge).^2 + BetaCog_byages(3)*(AgeWideAdams(:,3) - CenterAge).^3;
Inter = Inter + BetaCog_byrace(1)*(Race==1) + BetaCog_byrace(2)*(Race==2) + BetaCog_byrace(3)*(Race==3);
Inter = Inter + BetaCog_byeduc(1)*(Educ==1) + BetaCog_byeduc(2)*(Educ==2) + BetaCog_byeduc(3)*(Educ==3) + BetaCog_byfore(1)*(Forborn==1);
Inter = Inter + BetaCog_byhssc(1)*(Hssc==1) + BetaCog_byhssc(2)*(Hssc==2) + BetaCog_byhssc(3)*(Hssc==3);
Inter = Inter + BetaCog_bysing*SingleWideAdams(:,3) + BetaCog_bystrok*StrokeWideAdams(:,3);

CogSimWideAdams(:,3) = CogSimWideAdams(:,3) + Inter.*BirthYear;

CogResidWideAdams(IAdamsSelectedWideAdams(:,3)<0.5,3)=0;
CogSimWideAdams(IAdamsSelectedWideAdams(:,3)<0.5,3)=0;

%ADAMS WC survival
IAdamsSurvivedWideAdams((IAdamsSelectedWideAdams(:,3)>0.5) & (AgeWideAdams(:,3)<DeathAge),3) = 1;

%Adams WC respondent
AdamsResp_Pot = BetaAResp3(1) + BetaAResp3(2)*AgeWideAdams(:,3) + BetaAResp3(3)*CogSimWideAdams(:,3) + randn(NSizex,1)>0;
IAdamsRespondentWideAdams(((IAdamsSurvivedWideAdams(:,3)>0.5) & (AdamsResp_Pot==1)),3) = 1;


%ADAMS WD selection
IAdamsSelectedWideAdams((IAdamsSelectedWideAdams(:,3)>0.5),4) = 1;
IAdamsSelectedWideAdams((IAdamsRespondentWideAdams(:,3)>0.5) & (CogSimWideAdams(:,3)<0),4) = 0;
IAdamsSelectedWideAdams((IAdamsSurvivedWideAdams(:,3)<0.5),4) = 0;

% ADAMS WD interview time 
IWTime_Pot = exp(BetaIW_4(1) + BetaIW_4(2)*(PriorWaveWideAdams(:,1)==6) + BetaIW_4(3)*AgeWideAdams(:,1) + BetaIW_4(4)*(PriorWaveWideAdams(:,1)==6).*AgeWideAdams(:,1) + BetaIW_4(5)*CogSimWideAdams(:,1) + BetaIW_4(6)*(PriorWaveWideAdams(:,1)==6).*CogSimWideAdams(:,1) + randn(NSizex,1)*SdIW_4);
AgeWideAdams(IAdamsSelectedWideAdams(:,4),4) = AgeWideAdams(IAdamsSelectedWideAdams(:,4),1) + IWTime_Pot(IAdamsSelectedWideAdams(:,4));

mean(AgeWideAdams(IAdamsSelectedWideAdams(:,4),:));
sum(AgeWideAdams(:,4)<AgeWideAdams(:,3) & IAdamsSelectedWideAdams(:,4));
%Observations with too small age are overwritten
aux = AgeWideAdams(:,4)<AgeWideAdams(:,3) & IAdamsSelectedWideAdams(:,4);
AgeWideAdams(aux,4) = AgeWideAdams(aux,3) + 0.05; 


%Adams WD cognition
allage = [AgeWideHRS,AgeWideAdams];
Iprev = zeros(NSizex,NSizet)>0.5;
allage2 = allage;
allage2(allage>=(AgeWideAdams(:,4)*ones(1,NSizet))) = 0;
mallage = max(allage2,[],2)*ones(1,NSizet);
Iprev(allage2==mallage) = 1;
Iprev(IAdamsSelectedWideAdams(:,4)<0.5,:) = 0;

Inext = zeros(NSizex,NSizet)>0.5;
allage2 = allage;
allage2(allage<=(AgeWideAdams(:,4)*ones(1,NSizet))) = 100;
mallage = min(allage2,[],2)*ones(1,NSizet);
Inext(allage2==mallage) = 1;
Inext(IAdamsSelectedWideAdams(:,4)<0.5,:) = 0;

aux = zeros(NSizex,NSizet);
aux(Iprev) = allage(Iprev);
PriorAgeWideAdams(:,4) = max(aux,[],2);
aux = zeros(NSizex,NSizet);
aux(Inext) = allage(Inext);
NextAgeWideAdams(:,4) = max(aux,[],2);

allproxy = [ProxyWideHRS,PriorProxyWideAdams(:,1:3), zeros(NSizex,1)];
aux = zeros(NSizex,NSizet);
aux(Iprev) = allproxy(Iprev);
PriorProxyWideAdams(:,4) = max(aux,[],2);

allageh = [AgeWideHRS,ones(NSizex,NSizetAdams)*100];
Iprevh = zeros(NSizex,NSizet)>0.5;
allageh2 = allageh;
allageh2(allageh>=(AgeWideAdams(:,4)*ones(1,NSizet))) = 0;
mallageh = max(allageh2,[],2)*ones(1,NSizet);
Iprevh(allageh2==mallageh) = 1;
Iprevh(IAdamsSelectedWideAdams(:,4)<0.5,:) = 0;
allwaves = [WavesWideHRS,zeros(NSizex,NSizetAdams)];
aux = zeros(NSizex,NSizet);
aux(Iprevh) = allwaves(Iprevh);
PriorWaveWideAdams(:,4) = max(aux,[],2);

allsingle = [SingleWideHRS,SingleWideAdams];
aux = -100*ones(NSizex,NSizet);
aux(Iprev) = allsingle(Iprev);
PriorSingleWideAdams(:,4) = max(aux,[],2);
PriorSingleWideAdams(PriorSingleWideAdams(:,4)==-100,4)=0;
aux = -100*ones(NSizex,NSizet);
aux(Inext) = allsingle(Inext);
NextSingleWideAdams(:,4) = max(aux,[],2);
NextSingleWideAdams(NextSingleWideAdams(:,4)==-100,4)=0;

allstroke = [StrokeWideHRS,StrokeWideAdams];
aux = -100*ones(NSizex,NSizet);
aux(Iprev) = allstroke(Iprev);
PriorStrokeWideAdams(:,4) = max(aux,[],2);
PriorStrokeWideAdams(PriorStrokeWideAdams(:,4)==-100,4)=0;
aux = -100*ones(NSizex,NSizet);
aux(Inext) = allstroke(Inext);
NextStrokeWideAdams(:,4) = max(aux,[],2);
NextStrokeWideAdams(NextStrokeWideAdams(:,4)==-100,4)=0;

a0 = PriorAgeWideAdams(:,4);
a1 = AgeWideAdams(:,4);
a2 = NextAgeWideAdams(:,4);

pSingle01t1 = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle10t1 = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a1-a0)));
pSingle01t  = PDistSingle(1,3)*(1 - exp(-PDistSingle(1,2)*(a2-a1)));
pSingle10t  = (1-PDistSingle(1,3))*(1 - exp(-PDistSingle(1,2)*(a2-a1)));

PSinglePosterior = zeros(NSizex,1);
indic = PriorSingleWideAdams(:,4)==0 & NextSingleWideAdams(:,4)==0;
PP1 = pSingle10t(indic).*pSingle01t1(indic);
PP0 = (1-pSingle01t1(indic)).*(1-pSingle01t(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,4)==1 & NextSingleWideAdams(:,4)==0;
PP1 = pSingle10t(indic).*(1-pSingle10t1(indic));
PP0 = (1-pSingle01t(indic)).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,4)==0 & NextSingleWideAdams(:,4)==1;
PP1 = (1-pSingle10t(indic)).*pSingle01t1(indic);
PP0 = pSingle01t(indic).*(1-pSingle01t1(indic));
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorSingleWideAdams(:,4)==1 & NextSingleWideAdams(:,4)==1;
PP1 = (1-pSingle10t(indic)).*(1-pSingle10t1(indic));
PP0 = pSingle01t(indic).*pSingle10t1(indic);
PSinglePosterior(indic) = PP1 ./ (PP0 + PP1);
SingleWideAdams(:,4) = rand(NSizex,1)< PSinglePosterior;

pStroke01t1 = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke10t1 = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a1-a0)));
pStroke01t  = PDistStroke(1,3)*(1 - exp(-PDistStroke(1,2)*(a2-a1)));
pStroke10t  = (1-PDistStroke(1,3))*(1 - exp(-PDistStroke(1,2)*(a2-a1)));

PStrokePosterior = zeros(NSizex,1);
indic = PriorStrokeWideAdams(:,4)==0 & NextStrokeWideAdams(:,4)==0;
PP1 = pStroke10t(indic).*pStroke01t1(indic);
PP0 = (1-pStroke01t1(indic)).*(1-pStroke01t(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,4)==1 & NextStrokeWideAdams(:,4)==0;
PP1 = pStroke10t(indic).*(1-pStroke10t1(indic));
PP0 = (1-pStroke01t(indic)).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,4)==0 & NextStrokeWideAdams(:,4)==1;
PP1 = (1-pStroke10t(indic)).*pStroke01t1(indic);
PP0 = pStroke01t(indic).*(1-pStroke01t1(indic));
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
indic = PriorStrokeWideAdams(:,4)==1 & NextStrokeWideAdams(:,4)==1;
PP1 = (1-pStroke10t(indic)).*(1-pStroke10t1(indic));
PP0 = pStroke01t(indic).*pStroke10t1(indic);
PStrokePosterior(indic) = PP1 ./ (PP0 + PP1);
StrokeWideAdams(:,4) = rand(NSizex,1)< PStrokePosterior;


CogResidWideAdams(:,4) = CogU0 + CogU1.*(AgeWideAdams(:,4) - CenterAge) + randn(NSizex,1)*SigmaMs;
CogSimWideAdams(:,4) = BetaCog_cons  + BetaCog_fema*Female + BetaCog_ages(1)*(AgeWideAdams(:,4) - CenterAge) + BetaCog_ages(2)*(AgeWideAdams(:,4) - CenterAge).^2 + BetaCog_ages(3)*(AgeWideAdams(:,4) - CenterAge).^3;
CogSimWideAdams(:,4) = CogSimWideAdams(:,4) + BetaCog_race(1)*(Race==1) + BetaCog_race(2)*(Race==2) + BetaCog_race(3)*(Race==3);
CogSimWideAdams(:,4) = CogSimWideAdams(:,4) + BetaCog_educ(1)*(Educ==1) + BetaCog_educ(2)*(Educ==2) + BetaCog_educ(3)*(Educ==3) + BetaCog_fore(1)*(Forborn==1);
CogSimWideAdams(:,4) = CogSimWideAdams(:,4) + BetaCog_hssc(1)*(Hssc==1) + BetaCog_hssc(2)*(Hssc==2) + BetaCog_hssc(3)*(Hssc==3);
CogSimWideAdams(:,4) = CogSimWideAdams(:,4) + BetaCog_byear*BirthYear + BetaCog_sing*SingleWideAdams(:,4) + BetaCog_strok*StrokeWideAdams(:,4) + CogResidWideAdams(:,4);

Inter = BetaCog_byfema*Female + BetaCog_byages(1)*(AgeWideAdams(:,4) - CenterAge) + BetaCog_byages(2)*(AgeWideAdams(:,4) - CenterAge).^2 + BetaCog_byages(3)*(AgeWideAdams(:,4) - CenterAge).^3;
Inter = Inter + BetaCog_byrace(1)*(Race==1) + BetaCog_byrace(2)*(Race==2) + BetaCog_byrace(3)*(Race==3);
Inter = Inter + BetaCog_byeduc(1)*(Educ==1) + BetaCog_byeduc(2)*(Educ==2) + BetaCog_byeduc(3)*(Educ==3) + BetaCog_byfore(1)*(Forborn==1);
Inter = Inter + BetaCog_byhssc(1)*(Hssc==1) + BetaCog_byhssc(2)*(Hssc==2) + BetaCog_byhssc(3)*(Hssc==3);
Inter = Inter + BetaCog_bysing*SingleWideAdams(:,4) + BetaCog_bystrok*StrokeWideAdams(:,4);
CogSimWideAdams(:,4) = CogSimWideAdams(:,4) + Inter.*BirthYear;

CogResidWideAdams(IAdamsSelectedWideAdams(:,4)<0.5,4)=0;
CogSimWideAdams(IAdamsSelectedWideAdams(:,4)<0.5,4)=0;

%ADAMS WD survival
IAdamsSurvivedWideAdams((IAdamsSelectedWideAdams(:,4)>0.5) & (AgeWideAdams(:,4)<DeathAge),4) = 1;

%Adams WD respondent
AdamsResp_Pot = BetaAResp4(1) + BetaAResp4(2)*AgeWideAdams(:,4) + BetaAResp4(3)*CogSimWideAdams(:,4) + randn(NSizex,1)>0;
IAdamsRespondentWideAdams(((IAdamsSurvivedWideAdams(:,4)>0.5) & (AdamsResp_Pot==1)),4) = 1;

PriorWaveWideAdams(IAdamsSelectedWideAdams<0.5)= 0;


%%% Step 2c: Meshing the HRS and ADAMS waves
% Non-adams ages set to a large value
AgeWideAdams(IAdamsSelectedWideAdams<0.5) = 100;

%Non-HRS also gets a large value
AgeWideHRS(IHRSCoreWideHRS<0.5) = 100;

allage = [AgeWideHRS,AgeWideAdams];
[AgeWide,ISorter] = sort(allage,2);

%Now sorting all the relevant variables
FemaleWide = Female*ones(1,NSizet);
RaceWide   = Race*ones(1,NSizet);
EducWide   = Educ*ones(1,NSizet);
ForeWide   = Forborn*ones(1,NSizet);
HsscWide   = Hssc*ones(1,NSizet);

allproxy  = [ProxyWideHRS, PriorProxyWideAdams]>0.5; 
allfp     = [FirstSelfHRS, zeros(NSizex,NSizetAdams)];
allwaves  = [WavesWideHRS, ones(NSizex,1)*[21,22,23,24]];
allcogsim = [CogSimWideHRS, CogSimWideAdams];
allcogres = [CogResidWideHRS,CogResidWideAdams];
allya     = [YCogAllWideHRS, zeros(NSizex,NSizetAdams)];
allys1    = [YCogSelf1WideHRS, zeros(NSizex,NSizetAdams)];
allys2    = [YCogSelf2WideHRS, zeros(NSizex,NSizetAdams)];
allys3    = [YCogSelf3WideHRS, zeros(NSizex,NSizetAdams)];
allys4    = [YCogSelf4WideHRS, zeros(NSizex,NSizetAdams)];
allyp1    = [YCogProxy1WideHRS, zeros(NSizex,NSizetAdams)];
allyp2    = [YCogProxy2WideHRS, zeros(NSizex,NSizetAdams)];
allas     = [zeros(NSizex,NSizetHRS), IAdamsSelectedWideAdams]>0.5;
allam     = [zeros(NSizex,NSizetHRS), IAdamsSurvivedWideAdams]>0.5;
allar     = [zeros(NSizex,NSizetHRS), IAdamsRespondentWideAdams]>0.5;
allhi     = [IHRSCoreWideHRS, zeros(NSizex,NSizetAdams)]>0.5;
allprw    = [zeros(NSizex,NSizetHRS), PriorWaveWideAdams];
allsingle = [SingleWideHRS,SingleWideAdams];
allstroke = [StrokeWideHRS,StrokeWideAdams];


ProxyWide = zeros(NSizex,NSizet)>0.5;
FirstSelf = zeros(NSizex,NSizet)>0.5;
WavesWide = zeros(NSizex,NSizet);
CogSimWide = zeros(NSizex,NSizet);
CogResidWide = zeros(NSizex,NSizet);
YCogAllWide = zeros(NSizex,NSizet);
YCogSelf1Wide = zeros(NSizex,NSizet);
YCogSelf2Wide = zeros(NSizex,NSizet);
YCogSelf3Wide = zeros(NSizex,NSizet);
YCogSelf4Wide = zeros(NSizex,NSizet);
YCogProxy1Wide = zeros(NSizex,NSizet);
YCogProxy2Wide = zeros(NSizex,NSizet);
IAdamsSelectedWide = zeros(NSizex,NSizet)>0.5;
IAdamsSurvivedWide = zeros(NSizex,NSizet)>0.5;
IAdamsRespondentWide = zeros(NSizex,NSizet)>0.5;
IHRSCoreWide = zeros(NSizex,NSizet)>0.5;
PriorWaveWide = zeros(NSizex,NSizet);
SingleWide = zeros(NSizex,NSizet);
StrokeWide = zeros(NSizex,NSizet);


for i = 1:NSizex
   ProxyWide(i,:) = allproxy(i,ISorter(i,:)); 
   FirstSelf(i,:) = allfp(i,ISorter(i,:)); 
   WavesWide(i,:) = allwaves(i,ISorter(i,:)); 
   
   CogSimWide(i,:)   = allcogsim(i,ISorter(i,:));
   CogResidWide(i,:) = allcogres(i,ISorter(i,:));
   
   YCogAllWide(i,:)  = allya(i,ISorter(i,:));
   YCogSelf1Wide(i,:)  = allys1(i,ISorter(i,:));
   YCogSelf2Wide(i,:)  = allys2(i,ISorter(i,:));
   YCogSelf3Wide(i,:)  = allys3(i,ISorter(i,:));
   YCogSelf4Wide(i,:)  = allys4(i,ISorter(i,:));
   YCogProxy1Wide(i,:) = allyp1(i,ISorter(i,:));
   YCogProxy2Wide(i,:) = allyp2(i,ISorter(i,:));
   
   IAdamsSelectedWide(i,:)   = allas(i,ISorter(i,:));
   IAdamsSurvivedWide(i,:)   = allam(i,ISorter(i,:));
   IAdamsRespondentWide(i,:) = allar(i,ISorter(i,:));
   
   IHRSCoreWide(i,:) = allhi(i,ISorter(i,:));
   
   PriorWaveWide(i,:) = allprw(i,ISorter(i,:));
   
   SingleWide(i,:) = allsingle(i,ISorter(i,:));
   StrokeWide(i,:) = allstroke(i,ISorter(i,:));
end

% Indicators
IHRSAllWide        = IHRSCoreWide | IAdamsSelectedWide; % HRS or ADAMS wave
IProxyAllWide      = ProxyWide>0.5 & IHRSAllWide>0.5;   % Proxy interview
ISelfAllWide       = ProxyWide<0.5 & IHRSAllWide>0.5;   % Self interview
aux  = [zeros(NSizex,1), WavesWide(:,1:NSizet-1)];
aux2 = [zeros(NSizex,2), WavesWide(:,1:NSizet-2)];
IAdamsEligibleWide = ((aux==5)|(aux==6&aux2<20)); % Eligible for selection into ADAMS


%%% Step 2d: Reshaping the variables to Long
% Exogenous variables
XFemaleBalanced  = reshape(FemaleWide',NSize,1);
XRaceBalanced    = reshape(RaceWide',NSize,1);
XEducBalanced    = reshape(EducWide',NSize,1);
XForbornBalanced = reshape(ForeWide',NSize,1);
XHsscBalanced    = reshape(HsscWide',NSize,1);
WavesBalanced    = reshape(WavesWide',NSize,1);
AgeBalanced      = reshape(AgeWide',NSize,1);
XSingleBalanced  = reshape(SingleWide',NSize,1)>0.5;
XStrokeBalanced  = reshape(StrokeWide',NSize,1)>0.5;


%Indicators
IProxyAllBalanced = reshape(IProxyAllWide',NSize,1);
ISelfAllBalanced  = reshape(ISelfAllWide',NSize,1);
IHRSCoreBalanced  = reshape(IHRSCoreWide',NSize,1);
IHRSAllBalanced   = reshape(IHRSAllWide',NSize,1);
IAdamsEligibleBalanced = reshape(IAdamsEligibleWide',NSize,1);
IAdamsSelectedBalanced = reshape(IAdamsSelectedWide',NSize,1);
IAdamsSurvivedBalanced = reshape(IAdamsSurvivedWide',NSize,1);
IAdamsRespondentBalanced = reshape(IAdamsRespondentWide',NSize,1);
PriorWaveBalanced = reshape(PriorWaveWide',NSize,1);

% Making some HRS cognition scores missing
YCogAllWide(IHRSCoreWide<0.5)=-100;
YCogSelf1Wide(IHRSCoreWide<0.5|ISelfAllWide<0.5)=-100;
YCogSelf2Wide(IHRSCoreWide<0.5|ISelfAllWide<0.5)=-100;
YCogSelf3Wide(IHRSCoreWide<0.5|ISelfAllWide<0.5)=-100;
YCogSelf4Wide(IHRSCoreWide<0.5|ISelfAllWide<0.5)=-100;
YCogProxy1Wide(IHRSCoreWide<0.5|IProxyAllWide<0.5)=-100;
YCogProxy2Wide(IHRSCoreWide<0.5|IProxyAllWide<0.5)=-100;

%Other variables
CogSimBalanced     = reshape(CogSimWide',NSize,1);
YCogAllBalanced    = reshape(YCogAllWide',NSize,1);
YCogSelf1Balanced  = reshape(YCogSelf1Wide',NSize,1);
YCogSelf2Balanced  = reshape(YCogSelf2Wide',NSize,1);
YCogSelf3Balanced  = reshape(YCogSelf3Wide',NSize,1);
YCogSelf4Balanced  = reshape(YCogSelf4Wide',NSize,1);
YCogProxy1Balanced = reshape(YCogProxy1Wide',NSize,1);
YCogProxy2Balanced = reshape(YCogProxy2Wide',NSize,1);

%%% Step 2e: Now the rest of the variables
% Other ADAMS Indicator variables 
IAdamsNonRespondentBalanced = (IAdamsSelectedBalanced>0.5) & (IAdamsRespondentBalanced<0.5);
IAdamsSelectedBalancedWA = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==21);
IAdamsSelectedBalancedWB = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==22); 
IAdamsSelectedBalancedWC = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==23); 
IAdamsSelectedBalancedWD = (IAdamsSelectedBalanced>0.5) & (WavesBalanced==24); 
IAdamsSelectedShiftedWA  = [IAdamsSelectedBalancedWA(2:NSize);0]>0.5;

%HRS indicator variables
IProxyCoreBalanced = IProxyAllBalanced;  
IProxyCoreBalanced(IAdamsSelectedBalanced>0.5) = 0; 
ISelfCoreBalanced  = ISelfAllBalanced;  
ISelfCoreBalanced(IAdamsSelectedBalanced>0.5)  = 0;

IProxyCoreForward = [0;IProxyCoreBalanced(1:NSize-1)];
ISelfCoreForward  = [0;ISelfCoreBalanced(1:NSize-1)];

%True cognition
CogSimTrueBalanced   = CogSimBalanced;
DementedTrueBalanced = CogSimBalanced<0;
CindTrueBalanced     = CogSimBalanced>=0&CogSimBalanced<1;
NormalcTrueBalanced  = CogSimBalanced>=1;
CogU0True            = CogU0;
CogU1True            = CogU1;

%Survivors to last HRS wave
DeathAgeTrue = DeathAge;
HRSWave = zeros(NSizex,NSizet);
HRSWave(IHRSCoreWide) = WavesWide(IHRSCoreWide);
MaxWave = max(HRSWave,[],2);
DeathAge(MaxWave==13) = -100;

DeathAgeWide = DeathAge*ones(1,NSizet);
DeathAgeBalanced = reshape(DeathAgeWide',NSize,1);

HRSAge = zeros(NSizex,NSizet);
HRSAge(IHRSAllWide) = AgeWide(IHRSAllWide);
LastAge = max(HRSAge,[],2);
LastAge(MaxWave<13) = -100;
LastAgeWide = LastAge*ones(1,NSizet);

DeadBalanced = DeathAgeBalanced>-0.5;
DeadWide     = reshape(DeadBalanced, NSizet, NSizex)';

% ADAMS diagnosis
DementedBalanced = zeros(NSize,1)>0.5;
DementedBalanced(CogSimBalanced<0) = 1;
DementedBalanced(IAdamsRespondentBalanced<0.5)=0;
CindBalanced = zeros(NSize,1)>0.5;
CindBalanced(CogSimBalanced>=0 & CogSimBalanced<1) = 1;
CindBalanced(IAdamsRespondentBalanced<0.5)=0;
NormalcBalanced  = zeros(NSize,1)>0.5;
NormalcBalanced(CogSimBalanced>=1) = 1;
NormalcBalanced(IAdamsRespondentBalanced<0.5)=0;


% ADAMS selection: Separately for waves 5 & 6 (Only consider W6 if not selected for W5)
Wave5 = WavesBalanced==5&IHRSCoreBalanced>0.5;
Wave6 = WavesBalanced==6&IHRSCoreBalanced>0.5;
Wave5Forward = [0;Wave5(1:NSize-1)]>0.5;
Wave6Forward = [0;Wave6(1:NSize-1)]>0.5;
IProxyAllBalancedW5 = Wave5Forward & IAdamsEligibleBalanced & IProxyCoreForward;
IProxyAllBalancedW6 = Wave6Forward & IAdamsEligibleBalanced & IProxyCoreForward;
ISelfAllBalancedW5  = Wave5Forward & IAdamsEligibleBalanced & ISelfCoreForward;
ISelfAllBalancedW6  = Wave6Forward & IAdamsEligibleBalanced & ISelfCoreForward;

XAdamsSelfBalancedW5   = [ones(NSize,1),YCogSelf1Balanced];
XAdamsProxyBalancedW5  = [ones(NSize,1),YCogProxy1Balanced];
XAdamsSelfBalancedW6   = [ones(NSize,1),YCogSelf1Balanced];
XAdamsProxyBalancedW6  = [ones(NSize,1),YCogProxy1Balanced];

IAdamsEligibleForward = [IAdamsEligibleBalanced(2:NSize);0];

XAdamsSelfBalancedW5  = XAdamsSelfBalancedW5(IAdamsEligibleForward  & WavesBalanced==5 & IProxyAllBalanced==0 & IHRSCoreBalanced==1,:);
XAdamsSelfBalancedW6  = XAdamsSelfBalancedW6(IAdamsEligibleForward  & WavesBalanced==6 & IProxyAllBalanced==0 & IHRSCoreBalanced==1,:);
XAdamsProxyBalancedW5 = XAdamsProxyBalancedW5(IAdamsEligibleForward & WavesBalanced==5 & IProxyAllBalanced==1 & IHRSCoreBalanced==1,:);
XAdamsProxyBalancedW6 = XAdamsProxyBalancedW6(IAdamsEligibleForward & WavesBalanced==6 & IProxyAllBalanced==1 & IHRSCoreBalanced==1,:);

IAdamsSelectedSelfW5  = IAdamsSelectedBalanced(ISelfAllBalancedW5);
IAdamsSelectedSelfW6  = IAdamsSelectedBalanced(ISelfAllBalancedW6);
IAdamsSelectedProxyW5 = IAdamsSelectedBalanced(IProxyAllBalancedW5);
IAdamsSelectedProxyW6 = IAdamsSelectedBalanced(IProxyAllBalancedW6);


% Variables in cognition: constant, proxy, gender, age (cubic), and some
% interactions
% replace age if zero.

%More aggregate wave dummies
Waves2Balanced = WavesBalanced;
Waves2Balanced(IAdamsSelectedBalanced>0.5) = PriorWaveBalanced(IAdamsSelectedBalanced>0.5);
WaveDummies = zeros(NSize,8);
WaveDummies(:,1) = Waves2Balanced==6;
WaveDummies(:,2) = Waves2Balanced==7;
WaveDummies(:,3) = Waves2Balanced==8;
WaveDummies(:,4) = Waves2Balanced==9;
WaveDummies(:,5) = Waves2Balanced==10;
WaveDummies(:,6) = Waves2Balanced==11;
WaveDummies(:,7) = Waves2Balanced==12;
WaveDummies(:,8) = Waves2Balanced>=13;

%%% Variables in ADAMS survival
% Cross-sectional format
DeathAgeX = DeathAgeWide(:,1);
DeathAgeX_min = LastAgeWide(:,1);
DeathAgeX_max = ones(NSizex,1)*10;
DeadX     = DeadWide(:,1);
DeathObservedX = (DeadX | DeathAgeX_max>0 & DeathAgeX_max<10) & (DeathAgeX>0.5 | DeathAgeX_min>0.5);  % People who are know to be dead
DeathMis = DeadX < 0.5 & DeathObservedX>0.5; % People who are known to be dead, but we do not have precise age at death information

% Ages various times before death
NumDeads = sum(DeathObservedX);
DeathAgeGrids = zeros(NumDeads,6);
DeathAgeGrids(:,6) = DeathAgeTrue(DeathObservedX);
DeathAgeGrids(:,5) = DeathAgeGrids(:,6) - 0.05; 
DeathAgeGrids(:,4) = DeathAgeGrids(:,6) - 0.1; 
DeathAgeGrids(:,3) = DeathAgeGrids(:,6) - 0.2; 
DeathAgeGrids(:,2) = DeathAgeGrids(:,6) - 0.3; 
DeathAgeGrids(:,1) = DeathAgeGrids(:,6) - 0.5; 


BaseAgeAdamsWA   = AgeBalanced(IAdamsSelectedShiftedWA);
BaseAgeShiftedWA = zeros(NSize,1);
BaseAgeShiftedWA(IAdamsSelectedShiftedWA) = BaseAgeAdamsWA;

IHRSSelect1Wide = zeros(NSizex,NSizet)>0.5;
IHRSSelect1Wide(:,1) = 1;
IHRSSelect1Balanced = reshape(IHRSSelect1Wide',NSize,1);


% Imputing cognition at the Deathage grid points
CogDeathGrids = zeros(NumDeads,6);
CogU0Dead     = CogU0(DeathObservedX);
CogU1Dead     = CogU1(DeathObservedX);
FemaleDead    = Female(DeathObservedX);
RaceDead      = Race(DeathObservedX);
EducDead      = Educ(DeathObservedX);
ForbornDead   = Forborn(DeathObservedX);
HsscDead      = Hssc(DeathObservedX);
BirthYearDead = BirthYear(DeathObservedX);
SingleGridDead = TimeInvarDeadGrid(SingleWide(DeathObservedX,:), AgeWide(DeathObservedX,:), IHRSAllWide(DeathObservedX,:), DeathAgeGrids, PDistSingle, NumDeads, NSizet);
StrokeGridDead = TimeInvarDeadGrid(StrokeWide(DeathObservedX,:), AgeWide(DeathObservedX,:), IHRSAllWide(DeathObservedX,:), DeathAgeGrids, PDistStroke, NumDeads, NSizet);
for i=1:6
    CogDeathGrids(:,i) = CogU0Dead + CogU1Dead.*(DeathAgeGrids(:,i) - CenterAge) + randn(NumDeads,1)*SigmaMs;
    CogDeathGrids(:,i) = CogDeathGrids(:,i) + BetaCog_cons + BetaCog_fema*FemaleDead + BetaCog_ages(1)*(DeathAgeGrids(:,i) - CenterAge) + BetaCog_ages(2)*(DeathAgeGrids(:,i) - CenterAge).^2 + BetaCog_ages(3)*(DeathAgeGrids(:,i) - CenterAge).^3;
    CogDeathGrids(:,i) = CogDeathGrids(:,i) + BetaCog_race(1)*(RaceDead==1) + BetaCog_race(2)*(RaceDead==2) + BetaCog_race(3)*(RaceDead==3);
    CogDeathGrids(:,i) = CogDeathGrids(:,i) + BetaCog_educ(1)*(EducDead==1) + BetaCog_educ(2)*(EducDead==2) + BetaCog_educ(3)*(EducDead==3) + BetaCog_fore(1)*(ForbornDead==1);
    CogDeathGrids(:,i) = CogDeathGrids(:,i) + BetaCog_hssc(1)*(HsscDead==1) + BetaCog_hssc(2)*(HsscDead==2) + BetaCog_hssc(3)*(HsscDead==3);
    CogDeathGrids(:,i) = CogDeathGrids(:,i) + BetaCog_byear*BirthYearDead + BetaCog_sing*SingleGridDead(:,i) + BetaCog_strok*StrokeGridDead(:,i);
    
    Inter = BetaCog_byfema*FemaleDead + BetaCog_byages(1)*(DeathAgeGrids(:,i) - CenterAge) + BetaCog_byages(2)*(DeathAgeGrids(:,i) - CenterAge).^2 + BetaCog_byages(3)*(DeathAgeGrids(:,i) - CenterAge).^3;
    Inter = Inter + BetaCog_byrace(1)*(RaceDead==1) + BetaCog_byrace(2)*(RaceDead==2) + BetaCog_byrace(3)*(RaceDead==3);
    Inter = Inter + BetaCog_byeduc(1)*(EducDead==1) + BetaCog_byeduc(2)*(EducDead==2) + BetaCog_byeduc(3)*(EducDead==3) + BetaCog_byfore(1)*(ForbornDead==1);
    Inter = Inter + BetaCog_byhssc(1)*(HsscDead==1) + BetaCog_byhssc(2)*(HsscDead==2) + BetaCog_byhssc(3)*(HsscDead==3);
    Inter = Inter + BetaCog_bysing*SingleGridDead(:,i) + BetaCog_bystrok*StrokeGridDead(:,i);

    CogDeathGrids(:,i) = CogDeathGrids(:,i) + Inter.*BirthYearDead;
end

%Variables in ADAMS interview timing
NAdamsWA = size(BaseAgeAdamsWA,1);
W6WA = PriorWaveWideAdams(:,1)==6;
W6WA(IAdamsSelectedWideAdams(:,1)<0.5) = 0;
W6WAWide = W6WA*ones(1,NSizet);
W6WABalanced = reshape(W6WAWide',NSize,1);

%WA
IWTimeWA = zeros(NSize,1);
IWTimeWA(IAdamsSelectedBalancedWA) = log(AgeBalanced(IAdamsSelectedBalancedWA) - BaseAgeShiftedWA(IAdamsSelectedShiftedWA));
XAdamsTimeDemWA = [ones(NAdamsWA,1), W6WABalanced(IAdamsSelectedShiftedWA,1)];
XXAgeA          = AgeBalanced(IAdamsSelectedShiftedWA);
XAdamsTimeAgeWA = [XXAgeA, XXAgeA.*W6WABalanced(IAdamsSelectedShiftedWA,1)];
XAdamsTimeWA = [XAdamsTimeDemWA, XAdamsTimeAgeWA];

%WB
AgeWA = AgeWideAdams(:,1);
AgeWA(IAdamsRespondentWideAdams(:,1)<0.5) = 0;
AgeWAWide = AgeWA*ones(1,NSizet);
AgeWABalanced = reshape(AgeWAWide',NSize,1);

NAdamsWB = sum(IAdamsSelectedBalancedWB);
IWTimeWB = zeros(NSize,1);
IWTimeWB(IAdamsSelectedBalancedWB) = log(AgeBalanced(IAdamsSelectedBalancedWB) - AgeWABalanced(IAdamsSelectedBalancedWB));
XAdamsTimeDemWB = [ones(NAdamsWB,1), W6WABalanced(IAdamsSelectedBalancedWB)];
XXAgeB          = AgeWABalanced(IAdamsSelectedBalancedWB);
XAdamsTimeAgeWB = [XXAgeB, XXAgeB.*W6WABalanced(IAdamsSelectedBalancedWB,1)];
XAdamsTimeWB = [XAdamsTimeDemWB, XAdamsTimeAgeWB];

%WC
NAdamsWC = sum(IAdamsSelectedBalancedWC);
IWTimeWC = zeros(NSize,1);
IWTimeWC(IAdamsSelectedBalancedWC) = log(AgeBalanced(IAdamsSelectedBalancedWC) - AgeWABalanced(IAdamsSelectedBalancedWC));
XAdamsTimeDemWC = [ones(NAdamsWC,1), W6WABalanced(IAdamsSelectedBalancedWC)];
XXAgeC          = AgeWABalanced(IAdamsSelectedBalancedWC);
XAdamsTimeAgeWC = [XXAgeC, XXAgeC.*W6WABalanced(IAdamsSelectedBalancedWC,1)];
XAdamsTimeWC = [XAdamsTimeDemWC, XAdamsTimeAgeWC];

%WD
NAdamsWD = sum(IAdamsSelectedBalancedWD);
IWTimeWD = zeros(NSize,1);
IWTimeWD(IAdamsSelectedBalancedWD) = log(AgeBalanced(IAdamsSelectedBalancedWD) - AgeWABalanced(IAdamsSelectedBalancedWD));
XAdamsTimeDemWD = [ones(NAdamsWD,1), W6WABalanced(IAdamsSelectedBalancedWD)];
XXAgeD          = AgeWABalanced(IAdamsSelectedBalancedWD);
XAdamsTimeAgeWD = [XXAgeD, XXAgeD.*W6WABalanced(IAdamsSelectedBalancedWD,1)];
XAdamsTimeWD = [XAdamsTimeDemWD, XAdamsTimeAgeWD];


AgePrevious = [0; AgeBalanced(1:NSize-1)];
AgeNext     = [AgeBalanced(2:NSize); 0];
AgeNext(IHRSAllBalanced<0.5) = 100;
AgeBalanced_Min = ones(NSize,1)*(-100);
AgeBalanced_Min((IAdamsSelectedBalanced>0.5)&(IAdamsSurvivedBalanced<0.5))   = DeathAgeBalanced((IAdamsSelectedBalanced>0.5)&(IAdamsSurvivedBalanced<0.5));
AgeBalanced_Min((IAdamsSurvivedBalanced>0.5)&(IAdamsRespondentBalanced<0.5)) = AgePrevious((IAdamsSurvivedBalanced>0.5)&(IAdamsRespondentBalanced<0.5));
AgeBalanced_Max = ones(NSize,1)*(-100);
AgeBalanced_Max((IAdamsSelectedBalanced>0.5)&(IAdamsSurvivedBalanced<0.5))   = 100;

aux1 = AgeNext((IAdamsSurvivedBalanced>0.5)&(IAdamsRespondentBalanced<0.5));
aux2 = DeathAgeBalanced((IAdamsSurvivedBalanced>0.5)&(IAdamsRespondentBalanced<0.5));
aux2(aux2==-100) = 50;
aux3 = 10*ones(sum((IAdamsSurvivedBalanced>0.5)&(IAdamsRespondentBalanced<0.5)), 1);
AgeBalanced_Max((IAdamsSurvivedBalanced>0.5)&(IAdamsRespondentBalanced<0.5)) = min([aux1, aux2, aux3], [], 2);

%check if the mins and maxes are consistnet longitudinally
aux  = [(AgeBalanced_Max(1:NSize-1)>AgeBalanced_Min(2:NSize) & AgeBalanced_Max(1:NSize-1)>-100) & AgeBalanced_Min(2:NSize)>-100;0]>0.5;
aux2 = [(AgeBalanced_Max(1:NSize-1)+AgeBalanced_Min(2:NSize))/2;0];
%tabulate(aux2(aux));
AgeBalanced_Max(aux)=aux2(aux);
AgeBalanced_Min([0;aux(1:NSize-1)]>0.5)=aux2(aux);


%Variables in ADAMS response
NAdamsSurvWA = sum(IAdamsSurvivedBalanced & WavesBalanced==21);
NAdamsSurvWB = sum(IAdamsSurvivedBalanced & WavesBalanced==22);
NAdamsSurvWC = sum(IAdamsSurvivedBalanced & WavesBalanced==23);
NAdamsSurvWD = sum(IAdamsSurvivedBalanced & WavesBalanced==24);
IAdamsSurvivedBalancedWA = IAdamsSurvivedBalanced & WavesBalanced==21;
IAdamsSurvivedBalancedWB = IAdamsSurvivedBalanced & WavesBalanced==22;
IAdamsSurvivedBalancedWC = IAdamsSurvivedBalanced & WavesBalanced==23;
IAdamsSurvivedBalancedWD = IAdamsSurvivedBalanced & WavesBalanced==24;
XAdamsRespDemWA = ones(NAdamsSurvWA,1);
XAdamsRespDemWB = ones(NAdamsSurvWB,1);
XAdamsRespDemWC = ones(NAdamsSurvWC,1);
XAdamsRespDemWD = ones(NAdamsSurvWD,1);
XAdamsRespAgeWA = AgeBalanced(IAdamsSurvivedBalancedWA,:);
XAdamsRespAgeWB = AgeBalanced(IAdamsSurvivedBalancedWB,:);
XAdamsRespAgeWC = AgeBalanced(IAdamsSurvivedBalancedWC,:);
XAdamsRespAgeWD = AgeBalanced(IAdamsSurvivedBalancedWD,:);

% Wave-by-wave change in age (or since age 65 in period 1)
DAgeWide      = zeros(NSizex,NSizet);
DAgeWide(:,1) = AgeWide(:,1);
for i=2:NSizet
    DAgeWide(:,i) = AgeWide(:,i) - AgeWide(:,i-1);
end
DAgeBalanced = reshape(DAgeWide',NSize,1);

% Age is excatly 65 (to model missing mental status)
Age65Balanced = AgeBalanced<0.1;

%Birth year
BirthYearWide = BirthYear*ones(1,NSizet);
XBirthYearBalanced = reshape(BirthYearWide',NSize,1);

% Covariates in the HRS outcome variables: gender, age, and whether first
% self interview
FirstSelfBalanced = reshape(FirstSelf',NSize,1);

%Missing cognition variables
XDemBalanced = ones(NSize,12);
XDemBalanced(:,2) = XFemaleBalanced;
XDemBalanced(:,3) = XRaceBalanced==1;
XDemBalanced(:,4) = XRaceBalanced==2;
XDemBalanced(:,5) = XRaceBalanced==3;
XDemBalanced(:,6) = XEducBalanced==1;
XDemBalanced(:,7) = XEducBalanced==2;
XDemBalanced(:,8) = XEducBalanced==3;
XDemBalanced(:,9) = XForbornBalanced;
XDemBalanced(:,10) = XHsscBalanced==1;
XDemBalanced(:,11) = XHsscBalanced==2;
XDemBalanced(:,12) = XHsscBalanced==3;
XDemBalanced(:,13) = XSingleBalanced;
XDemBalanced(:,14) = XStrokeBalanced;

MisYAllBalanced    = IHRSCoreBalanced & (XDemBalanced*BetaMisAll_dem' + WaveDummies*BetaMisAll_wave' +  BetaMisAll_age*(AgeBalanced - CenterAge) + BetaMisAll_cog*CogSimBalanced + (WaveDummies*BetaMisAll_wavecog').*CogSimBalanced + randn(NSize,1) > 0);
MisYSelf1Balanced  = IHRSCoreBalanced & ISelfAllBalanced & (XDemBalanced*BetaMisSelf1_dem' + WaveDummies*BetaMisSelf1_wave' + BetaMisSelf1_age*(AgeBalanced - CenterAge) + BetaMisSelf1_oth*FirstSelfBalanced + BetaMisSelf1_cog*CogSimBalanced + (WaveDummies*BetaMisSelf1_wavecog').*CogSimBalanced + randn(NSize,1) > 0);
MisYSelf2Balanced  = IHRSCoreBalanced & ISelfAllBalanced & (XDemBalanced*BetaMisSelf2_dem' + WaveDummies*BetaMisSelf2_wave' + BetaMisSelf2_age*(AgeBalanced - CenterAge) + BetaMisSelf2_oth(1)*FirstSelfBalanced  + BetaMisSelf2_oth(2)*YCogSelf1Balanced + BetaMisSelf2_oth(3)*MisYSelf1Balanced + BetaMisSelf2_cog*CogSimBalanced + (WaveDummies*BetaMisSelf2_wavecog').*CogSimBalanced + randn(NSize,1) > 0);
MisYSelf3Balanced  = IHRSCoreBalanced & ISelfAllBalanced & (XDemBalanced*BetaMisSelf3_dem' + WaveDummies*BetaMisSelf3_wave' + BetaMisSelf3_age*(AgeBalanced - CenterAge) + BetaMisSelf3_oth*FirstSelfBalanced + BetaMisSelf3_cog*CogSimBalanced + (WaveDummies*BetaMisSelf3_wavecog').*CogSimBalanced + randn(NSize,1) > 0);
MisYSelf4Balanced  = IHRSCoreBalanced & ISelfAllBalanced & (XDemBalanced*BetaMisSelf4_dem' + WaveDummies*BetaMisSelf4_wave' + BetaMisSelf4_age*(AgeBalanced - CenterAge) + BetaMisSelf4_oth(1)*FirstSelfBalanced + BetaMisSelf4_oth(2)*Age65Balanced + BetaMisSelf4_cog*CogSimBalanced + (WaveDummies*BetaMisSelf4_wavecog').*CogSimBalanced + randn(NSize,1) > 0);
MisYProxy1Balanced = IHRSCoreBalanced & IProxyAllBalanced & (rand(NSize,1) < BetaMisProxy1(1));
MisYProxy2Balanced = IHRSCoreBalanced & IProxyAllBalanced & (XDemBalanced*BetaMisProxy2_dem' + WaveDummies*BetaMisProxy2_wave' +  BetaMisProxy2_age*(AgeBalanced - CenterAge) + BetaMisProxy2_cog*CogSimBalanced + (WaveDummies*BetaMisProxy2_wavecog').*CogSimBalanced + randn(NSize,1) > 0);

%Missing covariates
MisXRace    = rand(NSizex,1)<PrRaceMis;
MisXEduc    = rand(NSizex,1)<PrEducMis;
MisXForborn = rand(NSizex,1)<PrForeMis;
MisXHssc    = rand(NSizex,1)<PrHsscMis;
MisXRaceWide    = MisXRace*ones(1,NSizet);
MisXEducWide    = MisXEduc*ones(1,NSizet);
MisXForbornWide = MisXForborn*ones(1,NSizet);
MisXHsscWide    = MisXHssc*ones(1,NSizet);
MisXRaceBalanced    = reshape(MisXRaceWide',NSize,1);
MisXEducBalanced    = reshape(MisXEducWide',NSize,1);
MisXForbornBalanced = reshape(MisXForbornWide',NSize,1);
MisXHsscBalanced    = reshape(MisXHsscWide',NSize,1);
MisXSingleBalanced  = rand(NSize,1)<PrSingleMis;
MisXStrokeBalanced  = rand(NSize,1)<PrStrokeMis;


% Saving the true coefficients
TrueYAll       = [BetaCogAll_dem'   ; BetaCogAll_age'   ; BetaCogAll_cog'   ; NaN; SdCogAll];
TrueYProxy1    = [BetaCogProxy1_dem'; BetaCogProxy1_age'; BetaCogProxy1_cog'; NaN; SdCogProxy1];
TrueYProxy2    = [BetaCogProxy2_dem'; BetaCogProxy2_age'; BetaCogProxy2_cog'; NaN; SdCogProxy2];
TrueYSelf1     = [BetaCogSelf1_dem' ; BetaCogSelf1_age' ; BetaCogSelf1_oth' ; BetaCogSelf1_cog'; NaN; SdCogSelf1];
TrueYSelf2     = [BetaCogSelf2_dem' ; BetaCogSelf2_age' ; BetaCogSelf2_oth' ; BetaCogSelf2_cog'; NaN; SdCogSelf2];
TrueYSelf3     = [BetaCogSelf3_dem' ; BetaCogSelf3_age' ; BetaCogSelf3_oth' ; BetaCogSelf3_cog'; NaN; SdCogSelf3];
TrueYSelf4     = [BetaCogSelf4_dem' ; BetaCogSelf4_age' ; BetaCogSelf4_oth' ; BetaCogSelf4_cog'; NaN; SdCogSelf4];

TrueYAllMis    = [BetaMisAll_dem'   ; BetaMisAll_wave'   ; BetaMisAll_age'   ;BetaMisAll_cog'    ; BetaMisAll_wavecog'];
TrueYProxy2Mis = [BetaMisProxy2_dem'; BetaMisProxy2_wave'; BetaMisProxy2_age'; BetaMisProxy2_cog'; BetaMisProxy2_wavecog'];
TrueYSelf1Mis  = [BetaMisSelf1_dem' ; BetaMisSelf1_wave' ; BetaMisSelf1_age' ;BetaMisSelf1_oth'  ; BetaMisSelf1_cog'; BetaMisSelf1_wavecog'];
TrueYSelf2Mis  = [BetaMisSelf2_dem' ; BetaMisSelf2_wave' ; BetaMisSelf2_age' ;BetaMisSelf2_oth'  ; BetaMisSelf2_cog'; BetaMisSelf2_wavecog'];
TrueYSelf3Mis  = [BetaMisSelf3_dem' ; BetaMisSelf3_wave' ; BetaMisSelf3_age' ;BetaMisSelf3_oth'  ; BetaMisSelf3_cog'; BetaMisSelf3_wavecog'];
TrueYSelf4Mis  = [BetaMisSelf4_dem' ; BetaMisSelf4_wave' ; BetaMisSelf4_age' ;BetaMisSelf4_oth'  ; BetaMisSelf4_cog'; BetaMisSelf4_wavecog'];

TrueProxySel   = [BetaIProxy_cons; BetaIProxy_fema; BetaIProxy_race'; BetaIProxy_educ'; BetaIProxy_fore; BetaIProxy_hssc'; BetaIProxy_sing'; BetaIProxy_strok'; zeros(4,1); ones(4,1)*BetaIProxy_wave; BetaIProxy_ages'; BetaIProxy_cog; zeros(4,1); ones(4,1)*BetaIProxy_wavecog];
TrueCog        = [BetaCog_cons; BetaCog_fema; BetaCog_race'; BetaCog_educ'; BetaCog_fore; BetaCog_hssc'; BetaCog_sing'; BetaCog_strok'; BetaCog_byear; BetaCog_byfema; BetaCog_byrace'; BetaCog_byeduc'; BetaCog_byfore; BetaCog_byhssc'; BetaCog_bysing'; BetaCog_bystrok'; BetaCog_ages'; BetaCog_byages'; NaN; SigmaUs'; CorrUs'; SigmaMs];
TrueIAdams     = [BetaIAdamsProxyW5'; NaN; BetaIAdamsProxyW6'; NaN; BetaIAdamsSelfW5'; NaN; BetaIAdamsSelfW6'];
TrueAdamsTime  = [BetaIW_1'; NaN; SdIW_1; NaN; BetaIW_2'; NaN; SdIW_2 ; NaN; BetaIW_3'; NaN; SdIW_3; NaN; BetaIW_4'; NaN; SdIW_4];
TrueSurv       = [GammaShape_cons; GammaShape_fema; GammaShape_race'; GammaShape_educ'; GammaShape_fore; GammaShape_hssc'; GammaShape_byear; GammaShape_byfema; GammaShape_byrace';GammaShape_byeduc';GammaShape_byfore;GammaShape_byhssc'; GammaShape_cog'; NaN; GammaScale];
TrueAdamsResp  = [BetaAResp1'; NaN; BetaAResp2'; NaN; BetaAResp3'; NaN; BetaAResp4'];

TruePRace    = PrRaceDist';
TruePEduc    = PrEducDist';
TruePForborn = PrForeDist';
TruePHssc    = PrHsscDist';
TrueDSingle  = PDistSingle';
TrueDStroke  = PDistStroke';

%The weights
WeightsBalanced = ones(NSize,1);

%True prevalence
AgeGroups = -ones(NSize,1);
AgeGroups(AgeBalanced>=0&AgeBalanced<1) = 0;
AgeGroups(AgeBalanced>=1&AgeBalanced<2) = 1;
AgeGroups(AgeBalanced>=2&AgeBalanced<50) = 2;

DimPrevGroupsCompare = 12; % Number of groups to compare to the literature
IndPrevsCompare = zeros(NSize,DimPrevGroupsCompare)>0.5;
IndPrevsCompare(:,1)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6;
IndPrevsCompare(:,2)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & XFemaleBalanced==0;
IndPrevsCompare(:,3)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & XFemaleBalanced==1;
IndPrevsCompare(:,4)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & AgeBalanced<1.5;
IndPrevsCompare(:,5)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & AgeBalanced<1.5 & XFemaleBalanced==0;
IndPrevsCompare(:,6)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=0.6 & AgeBalanced<1.5 & XFemaleBalanced==1;
IndPrevsCompare(:,7)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=1.5 & AgeBalanced<2.5;
IndPrevsCompare(:,8)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=1.5 & AgeBalanced<2.5 & XFemaleBalanced==0;
IndPrevsCompare(:,9)  = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=1.5 & AgeBalanced<2.5 & XFemaleBalanced==1;
IndPrevsCompare(:,10) = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=2.5;
IndPrevsCompare(:,11) = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=2.5 & XFemaleBalanced==0;
IndPrevsCompare(:,12) = IHRSCoreBalanced==1 & WavesBalanced==6 & AgeBalanced>=2.5 & XFemaleBalanced==1;

[IndPrevsGender , DimPrevGroupsGender]   = IndPrevsInitG1(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, NSize);                   % Indicators for all waves and gender 
[IndPrevsAge    , DimPrevGroupsAge]      = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, AgeGroups       , NSize); % Indicators for all waves, gender, and age groups
[IndPrevsRace   , DimPrevGroupsRace]     = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XRaceBalanced   , NSize); % Indicators for all waves, gender, and race
[IndPrevsForborn, DimPrevGroupsForborn]  = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XForbornBalanced, NSize); % Indicators for all waves, gender, and foreign born status
[IndPrevsEduc   , DimPrevGroupsEduc]     = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XEducBalanced   , NSize); % Indicators for all waves, gender, and education
[IndPrevsHssc   , DimPrevGroupsHssc]     = IndPrevsInitG2(IHRSCoreBalanced, WavesBalanced, XFemaleBalanced, XHsscBalanced   , NSize); % Indicators for all waves, gender, and wealth

WeightedIndsCompare = WeightIndInit(IndPrevsCompare, WeightsBalanced, DimPrevGroupsCompare, NSize); % Normalized survey weights
WeightedIndsGender  = WeightIndInit(IndPrevsGender , WeightsBalanced, DimPrevGroupsGender , NSize); % Normalized survey weights
WeightedIndsAge     = WeightIndInit(IndPrevsAge    , WeightsBalanced, DimPrevGroupsAge    , NSize); % Normalized survey weights
WeightedIndsRace    = WeightIndInit(IndPrevsRace   , WeightsBalanced, DimPrevGroupsRace   , NSize); % Normalized survey weights
WeightedIndsForborn = WeightIndInit(IndPrevsForborn, WeightsBalanced, DimPrevGroupsForborn, NSize); % Normalized survey weights
WeightedIndsEduc    = WeightIndInit(IndPrevsEduc   , WeightsBalanced, DimPrevGroupsEduc   , NSize); % Normalized survey weights
WeightedIndsHssc    = WeightIndInit(IndPrevsHssc   , WeightsBalanced, DimPrevGroupsHssc   , NSize); % Normalized survey weights

TruePrevGroupsCompare = PrevEst(DementedTrueBalanced, WeightedIndsCompare, IndPrevsCompare, DimPrevGroupsCompare);
TruePrevGroupsGender  = PrevEst(DementedTrueBalanced, WeightedIndsGender , IndPrevsGender , DimPrevGroupsGender);
TruePrevGroupsAge     = PrevEst(DementedTrueBalanced, WeightedIndsAge    , IndPrevsAge    , DimPrevGroupsAge);
TruePrevGroupsRace    = PrevEst(DementedTrueBalanced, WeightedIndsRace   , IndPrevsRace   , DimPrevGroupsRace);
TruePrevGroupsForborn = PrevEst(DementedTrueBalanced, WeightedIndsForborn, IndPrevsForborn, DimPrevGroupsForborn);
TruePrevGroupsEduc    = PrevEst(DementedTrueBalanced, WeightedIndsEduc   , IndPrevsEduc   , DimPrevGroupsEduc);
TruePrevGroupsHssc    = PrevEst(DementedTrueBalanced, WeightedIndsHssc   , IndPrevsHssc   , DimPrevGroupsHssc);

% Dementia prevalence at the Deathage grid points
IndPrevsDead = [ones(NumDeads,1)>0.5, FemaleDead==0, FemaleDead==1, RaceDead==0, RaceDead==1, RaceDead==2, RaceDead==3, EducDead==0, EducDead==1, EducDead==2, EducDead==3, ForbornDead==0, ForbornDead==1, HsscDead==0, HsscDead==1, HsscDead==2, HsscDead==3];
DimPrevGroupsDead = size(IndPrevsDead,2);
WeightsWide = reshape(WeightsBalanced,NSizet,NSizex)';
LastWeight = zeros(NSizex,1);
for j=1:NSizet
    LastWeight(IHRSCoreWide(:,j)) = WeightsWide(IHRSCoreWide(:,j));
end
LastWeightDead = LastWeight(DeathObservedX,1);
WeightedIndsDead = WeightIndInit(IndPrevsDead, LastWeightDead, DimPrevGroupsDead, NumDeads); % Normalized survey weights

DementedTrueDead = CogDeathGrids<0;
TruePrevGroupsDead = PrevEst(DementedTrueDead(:,1), WeightedIndsDead, IndPrevsDead, DimPrevGroupsDead);
for j=2:6
    TruePrevGroupsDead = [TruePrevGroupsDead; PrevEst(DementedTrueDead(:,j), WeightedIndsDead, IndPrevsDead, DimPrevGroupsDead)];
end

% Storing all data in a structure
Data.NSize    = NSize;
Data.NSizet   = NSizet;
Data.NSizex   = NSizex;

Data.WavesBalanced = WavesBalanced;
Data.WaveDummies   = WaveDummies;
Data.W6WAWide      = W6WAWide;
Data.W6WABalanced  = W6WABalanced;

Data.AgeBalanced     = AgeBalanced;
Data.Age65Balanced   = Age65Balanced;
Data.DAgeWide        = DAgeWide ;
Data.DAgeBalanced    = DAgeBalanced;
Data.AgeWABalanced   = AgeWABalanced;
Data.DeathAgeX       = DeathAgeX;
Data.DeathAgeX_min   = DeathAgeX_min;
Data.DeathAgeX_max   = DeathAgeX_max;
Data.DeadX           = DeadX;
Data.AgeBalanced_Min = AgeBalanced_Min;
Data.AgeBalanced_Max = AgeBalanced_Max;

Data.DeathObservedX = DeathObservedX;
Data.DeathMis       = DeathMis;
Data.NumDeads       = NumDeads;
Data.DeathAgeGrids  = DeathAgeGrids;

Data.XRaceBalanced    = XRaceBalanced;
Data.XEducBalanced    = XEducBalanced;
Data.XForbornBalanced = XForbornBalanced;
Data.XHsscBalanced    = XHsscBalanced;
Data.XSingleBalanced  = XSingleBalanced;
Data.XFemaleBalanced  = XFemaleBalanced;
Data.XStrokeBalanced  = XStrokeBalanced;
Data.FirstSelfBalanced = FirstSelfBalanced;
Data.WeightsBalanced  = WeightsBalanced;
Data.XBirthYearBalanced = XBirthYearBalanced;

Data.MisXRaceBalanced    = MisXRaceBalanced;
Data.MisXEducBalanced    = MisXEducBalanced;
Data.MisXForbornBalanced = MisXForbornBalanced;
Data.MisXHsscBalanced    = MisXHsscBalanced;
Data.MisXSingleBalanced  = MisXSingleBalanced;
Data.MisXStrokeBalanced  = MisXStrokeBalanced;

Data.XAdamsTimeWA = XAdamsTimeWA;
Data.XAdamsTimeWB = XAdamsTimeWB;
Data.XAdamsTimeWC = XAdamsTimeWC;
Data.XAdamsTimeWD = XAdamsTimeWD;
Data.XAdamsRespDemWA = XAdamsRespDemWA;
Data.XAdamsRespDemWB = XAdamsRespDemWB;
Data.XAdamsRespDemWC = XAdamsRespDemWC;
Data.XAdamsRespDemWD = XAdamsRespDemWD;
Data.XAdamsRespAgeWA = XAdamsRespAgeWA;
Data.XAdamsRespAgeWB = XAdamsRespAgeWB;
Data.XAdamsRespAgeWC = XAdamsRespAgeWC;
Data.XAdamsRespAgeWD = XAdamsRespAgeWD;

Data.DementedBalanced = DementedBalanced;
Data.CindBalanced     = CindBalanced;
Data.NormalcBalanced  = NormalcBalanced;

Data.YCogAllBalanced   = YCogAllBalanced ;
Data.YCogSelf1Balanced  = YCogSelf1Balanced ;
Data.YCogSelf2Balanced  = YCogSelf2Balanced ;
Data.YCogSelf3Balanced  = YCogSelf3Balanced ;
Data.YCogSelf4Balanced  = YCogSelf4Balanced ;
Data.YCogProxy1Balanced = YCogProxy1Balanced;
Data.YCogProxy2Balanced = YCogProxy2Balanced;

Data.MisYAllBalanced    = MisYAllBalanced;
Data.MisYSelf1Balanced  = MisYSelf1Balanced;
Data.MisYSelf2Balanced  = MisYSelf2Balanced;
Data.MisYSelf3Balanced  = MisYSelf3Balanced;
Data.MisYSelf4Balanced  = MisYSelf4Balanced;
Data.MisYProxy1Balanced = MisYProxy1Balanced;
Data.MisYProxy2Balanced = MisYProxy2Balanced;

Data.IProxyAllBalanced  = IProxyAllBalanced;
Data.IHRSAllBalanced    = IHRSAllBalanced;
Data.IProxyCoreBalanced = IProxyCoreBalanced;
Data.ISelfCoreBalanced  = ISelfCoreBalanced;
Data.IHRSCoreBalanced   = IHRSCoreBalanced;
Data.IHRSSelect1Balanced = IHRSSelect1Balanced;

Data.IAdamsSurvivedBalanced   = IAdamsSurvivedBalanced;
Data.IAdamsRespondentBalanced = IAdamsRespondentBalanced;
Data.IAdamsNonRespondentBalanced = IAdamsNonRespondentBalanced;
Data.IAdamsSelectedBalanced   = IAdamsSelectedBalanced;
Data.IAdamsSelectedShiftedWA  = IAdamsSelectedShiftedWA;

Data.IProxyAllBalancedW5 = IProxyAllBalancedW5;
Data.IProxyAllBalancedW6 = IProxyAllBalancedW6;
Data.ISelfAllBalancedW5  = ISelfAllBalancedW5;
Data.ISelfAllBalancedW6  = ISelfAllBalancedW6;

Data.XAdamsSelfBalancedW5  = XAdamsSelfBalancedW5;
Data.XAdamsSelfBalancedW6  = XAdamsSelfBalancedW6;
Data.XAdamsProxyBalancedW5 = XAdamsProxyBalancedW5;
Data.XAdamsProxyBalancedW6 = XAdamsProxyBalancedW6;

Data.IAdamsSelectedSelfW5  = IAdamsSelectedSelfW5;
Data.IAdamsSelectedSelfW6  = IAdamsSelectedSelfW6;
Data.IAdamsSelectedProxyW5 = IAdamsSelectedProxyW5;
Data.IAdamsSelectedProxyW6 = IAdamsSelectedProxyW6;

Data.IWTimeWA = IWTimeWA;
Data.IWTimeWB = IWTimeWB;
Data.IWTimeWC = IWTimeWC;
Data.IWTimeWD = IWTimeWD;

Data.CogSimTrueBalanced    = CogSimTrueBalanced;
Data.DementedTrueBalanced  = DementedTrueBalanced;
Data.CindTrueBalanced      = CindTrueBalanced;
Data.NormalcTrueBalanced   = NormalcTrueBalanced;
Data.CogU0True             = CogU0True;
Data.CogU1True             = CogU1True;
Data.TruePrevGroupsCompare = TruePrevGroupsCompare; 
Data.TruePrevGroupsGender  = TruePrevGroupsGender; 
Data.TruePrevGroupsAge     = TruePrevGroupsAge; 
Data.TruePrevGroupsRace    = TruePrevGroupsRace; 
Data.TruePrevGroupsForborn = TruePrevGroupsForborn; 
Data.TruePrevGroupsEduc    = TruePrevGroupsEduc; 
Data.TruePrevGroupsHssc    = TruePrevGroupsHssc; 
Data.TruePrevGroupsDead    = TruePrevGroupsDead;

Data.TrueYProxy1    = TrueYProxy1;
Data.TrueYProxy2    = TrueYProxy2;
Data.TrueYSelf1     = TrueYSelf1;
Data.TrueYSelf2     = TrueYSelf2;
Data.TrueYSelf3     = TrueYSelf3;
Data.TrueYSelf4     = TrueYSelf4;
Data.TrueYAll       = TrueYAll;
Data.TrueYProxy2Mis = TrueYProxy2Mis;
Data.TrueYSelf1Mis  = TrueYSelf1Mis;
Data.TrueYSelf2Mis  = TrueYSelf2Mis;
Data.TrueYSelf3Mis  = TrueYSelf3Mis;
Data.TrueYSelf4Mis  = TrueYSelf4Mis;
Data.TrueYAllMis    = TrueYAllMis;
Data.TrueProxySel   = TrueProxySel;
Data.TrueCog        = TrueCog;
Data.TrueIAdams     = TrueIAdams;
Data.TrueAdamsTime  = TrueAdamsTime;
Data.TrueSurv       = TrueSurv;
Data.TrueAdamsResp  = TrueAdamsResp;
Data.TruePRace      = TruePRace;
Data.TruePEduc      = TruePEduc;
Data.TruePForborn   = TruePForborn;
Data.TruePHssc      = TruePHssc;
Data.TrueDSingle    = TrueDSingle;
Data.TrueDStroke    = TrueDStroke;

fprintf('done ***\n');
end

function y = VariableFill(b,x)
    Dim = size(b,2);
    y = b(1)*x(:,:,1);
    for i=2:Dim
        y = y + b(i)*x(:,:,i);
    end
end

function [IndPrevs, DimTot] = IndPrevsInitG1(Ind, WavesBalanced, G1, NSize)
    MinW  = min(WavesBalanced(Ind));
    MaxW  = max(WavesBalanced(Ind));
    SizeW = MaxW - MinW + 1;
    
    MinG1  = min(G1(Ind));
    MaxG1  = max(G1(Ind));
    SizeG1 = MaxG1 - MinG1 + 1;
    
    DimTot = SizeW * (SizeG1 + 1);
    
    IndPrevs = zeros(NSize,DimTot)>0.5;
    for i=1:SizeW
        IndPrevs(:,i)    = Ind==1 & WavesBalanced==4+i;
        for j=MinG1:MaxG1
            IndPrevs(:,SizeW*(j-MinG1+1)+i)  = Ind==1 & WavesBalanced==4+i & G1==j;
        end
    end
end

function [IndPrevs, DimTot] = IndPrevsInitG2(Ind, WavesBalanced, G1, G2, NSize)
    MinW  = min(WavesBalanced(Ind));
    MaxW  = max(WavesBalanced(Ind));
    SizeW = MaxW - MinW + 1;
    
    MinG1  = min(G1(Ind&G1>-1));
    MaxG1  = max(G1(Ind));
    SizeG1 = MaxG1 - MinG1 + 1;
    
    MinG2  = min(G2(Ind&G2>-1));
    MaxG2  = max(G2(Ind));
    SizeG2 = MaxG2 - MinG2 + 1;
    
    DimTot = SizeW * SizeG1 * SizeG2;
    IndPrevs = zeros(NSize,DimTot)>0.5;
    for i=1:9
        for j=MinG1:MaxG1
            for k=MinG2:MaxG2
                IndPrevs(:,SizeW*((j-MinG1)*(SizeG2) + (k-MinG2)) + i)    = Ind==1 & WavesBalanced==4+i & G1==j & G2==k;
            end
        end
    end
end

function WeightedInds = WeightIndInit(IndPrevs, WeightsBalanced, DimPrevGroups, NSize)
    WeightedInds = zeros(NSize,DimPrevGroups);
    for i=1:DimPrevGroups
        WeightedInds(:,i) = IndPrevs(:,i).*WeightsBalanced;
        WeightedInds(:,i) = WeightedInds(:,i) / mean(WeightedInds(IndPrevs(:,i),i));
    end
end

function PrevGroups = PrevEst(DementedBalanced, WeightedInds, IndPrevs, DimPrevGroups)
    PrevGroups = zeros(DimPrevGroups,1);
    for j=1:DimPrevGroups
        Aux = DementedBalanced.*WeightedInds(:,j);
        PrevGroups(j,1) = mean(Aux(IndPrevs(:,j)));
    end
end

function XGridDead = TimeInvarDeadGrid(XWide, AgeWide, IHrsWide, DeathAgeGrids, PDistX, NumDeads, NSizet)
    XGridDead = zeros(NumDeads,6);
    
    %%% Last column (at death)
    PPosterior = zeros(NumDeads,1);
    
    Iprev = zeros(NumDeads,NSizet)>0.5;
    AgeWide2 = AgeWide;
    AgeWide2(IHrsWide<0.5) = 0;
    MaxAgeWide2 = max(AgeWide2,[],2)*ones(1,NSizet);
    Iprev(AgeWide2==MaxAgeWide2) = 1;
    
    AgeWide3 = -ones(NumDeads,NSizet);
    AgeWide3(Iprev) = AgeWide(Iprev);
    X2 = -ones(NumDeads,NSizet);
    X2(Iprev) = XWide(Iprev);
    
    a0 = max(AgeWide3,[],2);
    x0 = max(X2,[],2);
    
    p01t1  = PDistX(1,3)*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,6)-a0)));
    p10t1  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,6)-a0)));
    
    indic = x0==0;
    PP1 = p01t1(indic);
    PP0 = (1-p01t1(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = x0==1;
    PP1 = (1-p10t1(indic));
    PP0 = p10t1(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    
    XGridDead(:,6) = rand(NumDeads,1)< PPosterior;
    
    %%% First column
    PPosterior = zeros(NumDeads,1);
    
    % Case with no prior values available
    p01t  = PDistX(1,3)*(1 - exp(-PDistX(1,2)*(AgeWide(:,1)-DeathAgeGrids(:,1))));
    p10t  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(AgeWide(:,1)-DeathAgeGrids(:,1))));
    
    indic = AgeWide(:,1)>DeathAgeGrids(:,1) & XWide(:,1)==0;
    PP1 = p10t(indic);
    PP0 = (1-p01t(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)>DeathAgeGrids(:,1) & XWide(:,1)==1;
    PP1 = (1-p10t(indic));
    PP0 = p01t(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    
    %Case with proper prior value
    Iprev = zeros(NumDeads,NSizet)>0.5;
    AgeWide2 = AgeWide;
    AgeWide2(IHrsWide<0.5 | AgeWide>DeathAgeGrids(:,1)*ones(1,NSizet)) = 0;
    MaxAgeWide2 = max(AgeWide2,[],2)*ones(1,NSizet);
    Iprev(AgeWide2==MaxAgeWide2) = 1;
    
    AgeWide3 = -ones(NumDeads,NSizet);
    AgeWide3(Iprev) = AgeWide(Iprev);
    X2 = -ones(NumDeads,NSizet);
    X2(Iprev) = XWide(Iprev);
    
    a0 = max(AgeWide3,[],2);
    x0 = max(X2,[],2);
    
    Inext = zeros(NumDeads,NSizet+1)>0.5;
    allage  = [AgeWide, DeathAgeGrids(:,6)];
    allx     = [XWide, XGridDead(:,6)];
    AgeWide2 = allage;
    AgeWide2(allage<=(DeathAgeGrids(:,1)*ones(1,NSizet+1))) = 100;
    mallage = min(AgeWide2,[],2)*ones(1,NSizet+1);
    Inext(AgeWide2==mallage) = 1;
    
    AgeWide3 = -ones(NumDeads,NSizet+1);
    AgeWide3(Inext) = allage(Inext);
    X2 = -ones(NumDeads,NSizet+1);
    X2(Inext) = allx(Inext);
    
    a2 = max(AgeWide3,[],2);
    x2 = max(X2,[],2);
    
    p01t1 = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,1)-a0)));
    p10t1 = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,1)-a0)));
    p01t  = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,1))));
    p10t  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,1))));
    
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==0 & x2==0;
    PP1 = p01t1(indic) .* p10t(indic);
    PP0 = (1-p01t1(indic)) .* (1-p01t(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==0 & x2==1;
    PP1 = p01t1(indic) .* (1 - p10t(indic));
    PP0 = (1-p01t1(indic)) .* p01t(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==1 & x2==0;
    PP1 = (1-p10t1(indic)) .* p10t(indic);
    PP0 = p10t1(indic) .* (1-p01t(indic));
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    indic = AgeWide(:,1)<=DeathAgeGrids(:,1) & x0==1 & x2==1;
    PP1 = (1-p10t1(indic)) .* (1-p10t(indic));
    PP0 = p10t1(indic) .* p01t(indic);
    PPosterior(indic) = PP1 ./ (PP0 + PP1);
    
    XGridDead(:,1) = rand(NumDeads,1)< PPosterior;
    
    
    %%% Middle columns
    for j=2:5
        PPosterior = zeros(NumDeads,1);
        
        Iprev = zeros(NumDeads,NSizet+j-1)>0.5;
        allage  = [AgeWide, DeathAgeGrids(:,1:j-1)];
        allx     = [XWide, XGridDead(:,1:j-1)];
        IHrsExt = [IHrsWide, ones(NumDeads,j-1)]>0.5;
        AgeWide2 = allage;
        AgeWide2(IHrsExt<0.5 | allage>DeathAgeGrids(:,j)*ones(1,NSizet+j-1)) = 0;
        MaxAgeWide2 = max(AgeWide2,[],2)*ones(1,NSizet+j-1);
        Iprev(AgeWide2==MaxAgeWide2) = 1;

        AgeWide3 = -ones(NumDeads,NSizet+j-1);
        AgeWide3(Iprev) = allage(Iprev);
        X2 = -ones(NumDeads,NSizet+j-1);
        X2(Iprev) = allx(Iprev);

        a0 = max(AgeWide3,[],2);
        x0 = max(X2,[],2);

        Inext = zeros(NumDeads,NSizet+1)>0.5;
        allage  = [AgeWide, DeathAgeGrids(:,6)];
        allx     = [XWide, XGridDead(:,6)];
        AgeWide2 = allage;
        AgeWide2(allage<=(DeathAgeGrids(:,j)*ones(1,NSizet+1))) = 100;
        mallage = min(AgeWide2,[],2)*ones(1,NSizet+1);
        Inext(AgeWide2==mallage) = 1;

        AgeWide3 = -ones(NumDeads,NSizet+1);
        AgeWide3(Inext) = allage(Inext);
        X2 = -ones(NumDeads,NSizet+1);
        X2(Inext) = allx(Inext);

        a2 = max(AgeWide3,[],2);
        x2 = max(X2,[],2);

        p01t1 = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,j)-a0)));
        p10t1 = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(DeathAgeGrids(:,j)-a0)));
        p01t  = PDistX(1,3)    *(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,j))));
        p10t  = (1-PDistX(1,3))*(1 - exp(-PDistX(1,2)*(a2-DeathAgeGrids(:,j))));

        indic = x0==0 & x2==0;
        PP1 = p01t1(indic) .* p10t(indic);
        PP0 = (1-p01t1(indic)) .* (1-p01t(indic));
        PPosterior(indic) = PP1 ./ (PP0 + PP1);
        indic = x0==0 & x2==1;
        PP1 = p01t1(indic) .* (1 - p10t(indic));
        PP0 = (1-p01t1(indic)) .* p01t(indic);
        PPosterior(indic) = PP1 ./ (PP0 + PP1);
        indic = x0==1 & x2==0;
        PP1 = (1-p10t1(indic)) .* p10t(indic);
        PP0 = p10t1(indic) .* (1-p01t(indic));
        PPosterior(indic) = PP1 ./ (PP0 + PP1);
        indic = x0==1 & x2==1;
        PP1 = (1-p10t1(indic)) .* (1-p10t(indic));
        PP0 = p10t1(indic) .* p01t(indic);
        PPosterior(indic) = PP1 ./ (PP0 + PP1);

        XGridDead(:,j) = rand(NumDeads,1)< PPosterior;
    end
end